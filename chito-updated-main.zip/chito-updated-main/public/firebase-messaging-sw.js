// Scripts for firebase and firebase messaging
// eslint-disable-next-line no-undef
importScripts("https://www.gstatic.com/firebasejs/8.2.0/firebase-app.js");
// eslint-disable-next-line no-undef
importScripts("https://www.gstatic.com/firebasejs/8.2.0/firebase-messaging.js");

// Initialize the Firebase app in the service worker by passing the generated config
const firebaseConfig = {
  apiKey: "AIzaSyCZo2Riu8Bd79sIZSA0E6limaDnljcWwNU",
  authDomain: "logistics-fcm-de9c2.firebaseapp.com",
  projectId: "logistics-fcm-de9c2",
  storageBucket: "logistics-fcm-de9c2.appspot.com",
  messagingSenderId: "401756752976",
  appId: "1:401756752976:web:43af4f4000157cb0c55555",
  measurementId: "G-J7448EC5JK"
};


// eslint-disable-next-line no-undef
firebase.initializeApp(firebaseConfig);

// Retrieve firebase messaging
// eslint-disable-next-line no-undef
const messaging = firebase.messaging();

messaging.onBackgroundMessage(function (payload) {
  

  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: "/logo192.png",
  };

  // eslint-disable-next-line no-restricted-globals
  return self.registration.showNotification(
    notificationTitle,
    notificationOptions
  );
});
