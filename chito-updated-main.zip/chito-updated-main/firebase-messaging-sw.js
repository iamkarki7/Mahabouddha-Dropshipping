// Scripts for firebase and firebase messaging
// eslint-disable-next-line no-undef
importScripts("https://www.gstatic.com/firebasejs/9.8.4/firebase-app.js");
// eslint-disable-next-line no-undef
importScripts("https://www.gstatic.com/firebasejs/9.8.4/firebase-analytics.js");

// Initialize the Firebase app in the service worker by passing the generated config
const firebaseConfig = {
  apiKey: "AIzaSyDA6cAZnD_FVYmoH03c6Clo7iLfNOcPtuI",
  authDomain: "logistic-fcm.firebaseapp.com",
  projectId: "logistic-fcm",
  storageBucket: "logistic-fcm.appspot.com",
  messagingSenderId: "992165098132",
  appId: "1:992165098132:web:d550b655cb7ad677127a81",
  measurementId: "G-ZBJD3H9Q8G"
};

// eslint-disable-next-line no-undef
firebase.initializeApp(firebaseConfig);

// Retrieve firebase messaging
// eslint-disable-next-line no-undef
const messaging = firebase.messaging();

messaging.onBackgroundMessage(function (payload) {
  
  

  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body
  };

  // eslint-disable-next-line no-restricted-globals
  return self.registration.showNotification(
    notificationTitle,
    notificationOptions
  );
});