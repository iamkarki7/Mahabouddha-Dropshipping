export const changePaginationButton = (defaultValue, next) =>{
    
    
    if(defaultValue/10 < next*5)
    {
        next = parseInt(defaultValue/50);
    }
    if(next==0)
    {
        next=1;
    }
    defaultValue = defaultValue/10;
   
    if (defaultValue>=5){
        if(next>1)
        {
            var arr = {'array': ['Prev',5*(next-1)+1, 5*(next-1)+2, 5*(next-1)+3, 5*(next-1)+4, 5*(next-1)+5, 'Next'],
                        'defaultValue':5*(next-1)+1,
                        'next': next}
        }
        else{
            var arr = {'array': [5*(next-1)+1, 5*(next-1)+2, 5*(next-1)+3, 5*(next-1)+4, 5*(next-1)+5, 'Next'],
                        'defaultValue':5*(next-1)+1,
                        'next': next}
        }
        return arr;
        
    }
    else{
        var array = []
        for(var i=1; i<=parseInt(defaultValue)+1; i++)
        {
            array.push(i);
        }
        
        return {'array': array,
                'defaultValue':1,
                'next': next}
    }
}