import orientation from './orientation';
import doIntersect from './doIntersect';
import onSegment from './onSegment';
function isInside(polygon, n, p)
{
    class point{
        constructor(lat, long) {
            this.lat = lat;
            this.long = long;
        }
    }
    if (n < 3)
    {
        return false;
    }
    var extreme = new point(10000, p.long);

    var count = 0, i = 0;
    do
    {
        var next = (i + 1) % n;
        if (doIntersect(polygon[i], polygon[next], p, extreme))
        {
            if (orientation(polygon[i], p, polygon[next]) === 0)
            {
                return onSegment(polygon[i], p,
                                polygon[next]);
            }
            count++;
        }
        i = next;
    } while (i !== 0);
    return (count % 2 === 1); 
}
export default isInside;