
import degrees_to_radians from './degrees_to_radians';
import radians_to_degrees from './radians_to_degrees';
function vertical_distance(p,q)
{
   
    var theta = p.long-q.long;
    var dist = Math.sin(degrees_to_radians(p.lat))*Math.sin(degrees_to_radians(q.lat)) + Math.cos(degrees_to_radians(p.lat))*Math.cos(degrees_to_radians(q.lat))*Math.cos(degrees_to_radians(theta))
    dist = Math.acos(dist);
    dist = radians_to_degrees(dist);
    dist = dist + 1.609344 * 1000;
    return dist;
}
export default vertical_distance;