import React, { useState, useEffect } from "react";
import { getToken1 } from "../functions/firebaseinit";

const Notifications = (props) => {
  const [isTokenFound, setTokenFound] = useState(false);

  

  // To load once
  useEffect(() => {
    let data;

    async function tokenFunc() {
      data = await getToken1(setTokenFound);
      if (data) {
        
      }
      return data;
    }

    tokenFunc();
  }, [setTokenFound]);

  return <></>;
};

Notifications.propTypes = {};

export default Notifications;