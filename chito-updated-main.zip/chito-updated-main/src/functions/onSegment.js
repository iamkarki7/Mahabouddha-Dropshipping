function onSegment(p,q,r )
{
  if(p.lat<=Math.max(p.lat,r.lat) && q.lat>=Math.min(p.lat,r.lat)&& q.long <= Math.max(p.long, r.long) && q.long >= Math.min(p.long, r.long))
  {
    return true;
  }
  else{
    return false;
  }
}
export default onSegment;