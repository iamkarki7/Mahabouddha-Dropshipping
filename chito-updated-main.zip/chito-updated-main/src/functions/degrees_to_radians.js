function degrees_to_radians(degrees)
{
    var pi = Math.PI;
    return degrees * (pi/180);
}
export default degrees_to_radians