import React from "react";
import PropTypes from "prop-types";

const ReactNotificationComponent = ({ title, body }) => {
  let hideNotif = title === "";

  function Display() {
    return (
      <div>
        <h4>{title}</h4>
        <p>{body}</p>
      </div>
    );
  }

  return (
<h1>Hello</h1>
  );
};

ReactNotificationComponent.defaultProps = {
  title: "This is title",
  body: "Some body",
};

ReactNotificationComponent.propTypes = {
  title: PropTypes.string,
  body: PropTypes.string,
};

export default ReactNotificationComponent;