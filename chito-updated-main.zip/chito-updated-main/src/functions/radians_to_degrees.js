function radians_to_degrees(radians)
{
    var pi = Math.PI;
    return radians * (180/pi);
}

export default radians_to_degrees;