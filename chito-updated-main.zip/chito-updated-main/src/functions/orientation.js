function orientation( p,q,r)
{
    var val = (q.long - p.long) * (r.lat - q.lat) -(q.lat - p.lat) * (r.long - q.long);
 
    if (val === 0) 
    {return 0;}
    else{
    return (val > 0)? 1: 2; }
}
export default orientation