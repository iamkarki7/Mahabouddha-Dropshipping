var state = ['Select Province','Province 1','Province 2','Bagmati','Gandaki','Lumbini','Karnali','Sudur Paschim'];

export default state;