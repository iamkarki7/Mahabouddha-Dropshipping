function dateconversion(date){
    var date1 = JSON.stringify(date);
    var mydate = ""
    for(var i=1;i<=10;i++)
    {
     mydate  = mydate + date1[i];
    }
    return mydate;


}
export default dateconversion;