var district = {'Province 1':['Select District','Jhapa','Illam','Panchthar','Taplejung','Sankhuwasabha','Terhathum','Bhojpur','Khotang','Dhankuta','Morang','Solukhumbu','Udayapur','Okhaldhunga','Sunsari'],
'Province 2':['Select District','Parsa','Bara','Rautahat','Sarlahi','Siraha','Dhanusha','Saptari','Mahottari'],
'Bagmati':['Select District','Sindhuli','Ramechhap','Dolakha','Bhaktapur','Dhading','Kathmandu','Kavrepalanchok','Lalitpur','Nuwakot','Rasuwa','Sindhupalchok','Chitwan','Makwanpur'],
'Gandaki':['Select District','Baglung','Gorkha','Kaski','Lamjung','Manang','Mustang','Myagdi','Nawalpur','Parbat','Syangja','Tanahun'],
'Lumbini':['Select District','Arghakhanchi','Banke','Bardiya','Dang','Gulmi','Kapilvastu','Parasi','Palpa','Pyuthan','Rolpa','Rukum','Rupandehi'],
'Karnali':['Select District','Western Rukum','Salyan','Dolpa','Humla','Jumla','Kalikot','Mugu','Surkhet','Dailekh','Jajarkot'],
'Sudur Paschim':['Select District','Bajhang','Bajura','Doti','Achham','Kailali','Kanchanpur','Dadeldhura','Baitadi','Darchula']}

export default district;