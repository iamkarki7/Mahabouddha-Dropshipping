import firebase from "firebase/compat/app";
import "firebase/compat/messaging";

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCZo2Riu8Bd79sIZSA0E6limaDnljcWwNU",
  authDomain: "logistics-fcm-de9c2.firebaseapp.com",
  projectId: "logistics-fcm-de9c2",
  storageBucket: "logistics-fcm-de9c2.appspot.com",
  messagingSenderId: "401756752976",
  appId: "1:401756752976:web:43af4f4000157cb0c55555",
  measurementId: "G-J7448EC5JK"
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

const publicKey = "BEwucl5c4MYaWd01620IhGO8zxo8mBCrEiSzfuLCnjPKYXbS8DP415lOgDdyCwjav2qpgaybPbJsQ7T6n4Klrdc";

export const getToken1 = async () => {
  let currentToken = "";

  try {
    currentToken = await messaging.getToken({ vapidKey: publicKey });
    return currentToken;
  } catch (error) {
    
  }

  return currentToken;
};

export const onMessageListener = () =>
  new Promise((resolve) => {
    messaging.onMessage((payload) => {
      resolve(payload);
    });
  });