import logo from './logo.svg';
import './App.css';
import Router from './router/routes';
import './static/css/style.css';
import './static/css/responsive.css';

function App() {


  return (
    <div className="App">
      <Router/>
    </div>
  );
}

export default App;
