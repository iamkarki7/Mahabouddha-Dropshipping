import React from 'react';
import Adminnotification_page from './pages/adminnotificationpage';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';

const Admin_notification = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <Adminnotification_page/>
            </div>
        </div>
    )
}
export default Admin_notification;