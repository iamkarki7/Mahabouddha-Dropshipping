import React from 'react';
import Header from './component/header';
import Admin_sidebar from './component/sidebar';
import View_page from './pages/viewadminpage';

const View_admin = ()=>{
    return(
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0">
                <Admin_sidebar/>
            </div>
            <div className="col-lg  p-0">
                <Header/>
                <View_page/>
            </div>
        </div>
    )
}
export default View_admin;