import React from 'react';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';
import Rider_Pathpage from './pages/riderspathpage';

const Rider_path = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <Rider_Pathpage/>
            </div>
        </div>
    )
}
export default Rider_path;