import React from 'react';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';
import Rider_informationpage from './pages/riderinformationpage';

const Rider_information = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <Rider_informationpage/>
            </div>
        </div>
    )
}
export default Rider_information;