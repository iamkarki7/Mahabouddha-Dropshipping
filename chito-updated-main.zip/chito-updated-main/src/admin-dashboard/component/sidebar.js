import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../../static/image/logo.png';

const Admin_sidebar = ()=>{
    return(
        <div className="dash-board-color height-of-sidebar sticky-top dashboard-sidebar-fix">
            <div className="col-12 text-center py-4 px-2 border-bottom border-2">
                {/* <h1 className="fa fa-user-circle text-white fa-3x"></h1>
                <p className="text-center text-white fw-bolder mt-2">
                    Xito Logistic
                </p> */}
                <img src ={Logo} className="w-100" alt="logo" />
            </div>
            <div className="pt-4 px-2">
                <Link to="/admin/dashboard" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 dash-active text-decoration side-bar"><i className="fa fa-qrcode fs-5 text-center p-1 px-4"></i><br/>Dashboard</Link>
                {/* <Link to="/today/order" className="text-white text-start side-padding text-decoration-none fs-17 d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square fs-5 text-center p-1 px-4"></i>Today's Order</Link> */}
                <Link to="/new/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-shopping-cart fs-5 text-center p-1 px-4"></i><br/>New Order</Link>
                {/* <Link to="/pending/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-plus-square fs-5 text-center p-1 px-4"></i>Pending Orders</Link>
                <Link to="/completed/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-plus-square fs-5 text-center p-1 px-4"></i>Completed Orders</Link> */}
                <Link to="/admin/all/tickets" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-ticket fs-5 p-1 px-4"></i><br/>All Tickets</Link>
                <Link to="/rider/information" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-motorcycle fs-5 text-center p-1 px-4"></i><br/>Rider Detail</Link>
                <Link to="/admin/rider/path" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-map fs-5 text-center p-1 px-4"></i><br/>Rider Route</Link>
                <Link to="/user/information" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-user fs-5 text-center p-1 px-4"></i><br/>User Detail</Link>
                <Link to="/admin/location-price" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-user fs-5 text-center p-1 px-4"></i><br/>Location Price</Link>
                <Link to="/admin/products" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-product-hunt fs-5 text-center p-1 px-4"></i><br/>Products</Link>
                <Link to="/admin/categories" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-plus fs-5 text-center p-1 px-4"></i><br/>Categories</Link>
                <Link to="/admin/pricing-criterias" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-user fs-5 text-center p-1 px-4"></i><br/>Price Criteria</Link>
            </div>
        </div>

    )
}
export default Admin_sidebar;