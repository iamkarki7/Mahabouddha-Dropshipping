import React,{useEffect,useState} from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Cookies from 'js-cookie';
import Tippy from '@tippy.js/react';
import 'tippy.js/dist/tippy.css';

const Post = ({ posts, loading })=>{
    const [status, setStatus] = useState([]);
    const [riders,setRiders] = useState([]);
    const [myriders,setmyriders] = useState([]);
    

    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/status/`)
        .then((res)=>{
           
            setStatus(res.data);
        })

    },[])
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/user/?is_driver=true`)
        .then((res)=>{
           
     
            var arr = []
            for(var i=0;i<res.data.length;i++)
            {
         
                arr.push(res.data[i])
                
            }
         
    
            setRiders(arr);
        })
    },[])
    
    if (loading) {
        return <h2>Loading...</h2>;
      }
    function setCancel(e,id)
    {
       
        if(e)
        {
            if (window.confirm(`Would you like to confirm this ${e} request?`)) {
                for(var i=0;i<status.length;i++){
                if(e==status[i].status_name)
                {
                    var status_id = parseInt(status[i].id);
                }
                }
                axios.patch(`https://api.mahaboudhawholesale.com/order/orders/${parseInt(id)}/`,{'status':status_id,'updated_by':parseInt(Cookies.get('id'))},{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                .then(res=>{
                   window.location.reload(true);
                 
                })
            }
                // window.location.reload(true);
              
                  
              } else {
                var txt = "You pressed Cancel!";
              }
        }
    const onMyriders = async (e, id) =>{
        let driver = e.target[e.target.selectedIndex].value
        driver = driver.split(":");
        setmyriders(id);
        const {data} = await axios.patch(`https://api.mahaboudhawholesale.com/order/orders/${parseInt(id)}/`,
                                         {'rider_name': parseInt(driver[0])},
                                         {headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})

    }
    return(
        <>
            {posts.map(key=>(
                        <tr className="data-information">
                        <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                        <td className="fs-13 text-dark">{key.customer_name}</td>
                        <td className="fs-13 text-dark">{key.customer_mobile}</td>
                        <td className="fs-13 text-dark">{key.created_date}</td>

                        {key.status.status_name == "Pending"?<td className="fs-13 text-dark">
                            <select className='border-0 new-border px-2 py-1' defaultValue = {key.rider_name.id+":"+key.rider_name.first_name+" "+key.rider_name.last_name} onChange={(e)=>onMyriders(e, key.id)}>
                            <option value={null} className="text-dark" >Select Rider</option>
                            {
                                    riders.map(rider=>(
                                    <option  value={rider.id+":"+rider.first_name+" "+rider.last_name} className="text-dark">{rider.id+":"+rider.first_name+" "+rider.last_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select>
                        </td>:null}
                        {key.status.status_name == "Pending" ?<td className="fs-13 text-dark">
                            <select className='border-0 new-border px-2 py-1' defaultValue = "Pending" onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} className="text-dark" >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  value={state.status_name} className="text-dark">{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select>
                        </td>:null}
                        {key.status.status_name == "Approved" ?<td className="fs-13 text-dark">
                            <select className='border-0 new-border px-2 py-1' defaultValue = "Approved" onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} className="text-dark" >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  value={state.status_name} className="text-dark">{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select>
                        </td>:null}
                        {key.status.status_name == "Hold" ?<td className="fs-13 text-dark">
                            <select className='border-0 new-border px-2 py-1' defaultValue = "Hold" onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} className="text-dark" >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  value={state.status_name} className="text-dark">{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select>
                        </td>:null}
                        {key.status.status_name == "Checked In" ?<td className="fs-13 text-dark">
                            <select className='border-0 new-border px-2 py-1' defaultValue = "Checked In" onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} className="text-dark" >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  value={state.status_name} className="text-dark">{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select>
                        </td>:null}
                        {key.status.status_name == "Delievered" ?<td className="fs-13 text-success">
                        {key.status.status_name}
                        </td>:null}
                        {key.status.status_name == "Cancelled" ?<td className="fs-13 text-danger">
                        {key.status.status_name}
                        </td>:null}
                        <td className="text-dark fs-13">
                        {key.status.status_name == "Pending"?
                        <Tippy content="Update"><Link className="text-decoration-none text-info header-background px-2 py-1 rounded me-2" to={`/order/update/${key.OrderNumber}`}><i className="fa fa-edit text-white"></i></Link></Tippy>:null}
                        <Tippy content="View"><Link to={`/admin/view/my/data/${key.OrderNumber}`} className='text-decoration-none back-color text-white ms-2 px-2 py-1 rounded'><i className="fa fa-eye text-white"></i></Link></Tippy>   
                            
                        </td>
                    </tr>
                        ))}
        </>
    )
}

export default Post;