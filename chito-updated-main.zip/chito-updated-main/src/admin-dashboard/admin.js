import React from 'react';
import Admin_page from './pages/adminpage';

const Admin = ()=>{
    return(
        <>
        <Admin_page/>
        </>
    )
}
export default Admin;