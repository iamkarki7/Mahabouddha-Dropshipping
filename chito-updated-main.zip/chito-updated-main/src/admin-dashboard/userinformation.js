import React from 'react';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';
import User_informationpage from './pages/userinformationpage';

const User_information = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <User_informationpage/>
            </div>
        </div>
    )
}
export default User_information;