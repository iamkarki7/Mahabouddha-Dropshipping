import React,{useRef,useState} from "react";
import { Link } from "react-router-dom";
import ReactToPrint from "react-to-print";
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import axios from "axios";
import Cookies from "js-cookie";

const Admin_allticket=  ()=>{
    let componentRef = useRef();
    const [status,setStatus] = useState("Active");
    

    const onTicketStatus = (e) => setStatus(e.target[e.target.selectedIndex].value)

    //exporting data to xls excel sheet
    
        //end of xls sheet
    return(
        <div className="p-3 pt-4 dash-new-color">
            {/* <div className="text-start mt-3">
                <Link to="/payment/request" className="text-decoration-none back-color fs-16 text-white ms-2 px-4 py-2 font-weight-bold ">Payment Request</Link>
            </div> */}
            <div className="bg-white mt-5 rounded p-3 col-12 new-overflow">
                <div className="row m-0">
                    <div className="col p-0">
                    <div className="d-flex">
                        <button className="header-background btn-sm text-white border-0 px-3 py-2"><i className="fa fa-download me-2"></i>Export</button>
                        <ReactToPrint
                            trigger={() => <button className="header-background btn-sm text-white border-0 px-3 py-2 ms-3"><i className="fa fa-print me-2"></i>Print</button>}
                            content={() => componentRef}
                        />
                </div>
                </div>
                <div className="col-2 p-0">
                        <div className="form-group">
                        <select className="form-control fs-13 fw-bolder text-dark  form-height" onChange={onTicketStatus}>
                            {/* <option value={null}>Please Select Type</option> */}
                            <option value="Active">Active</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                </div>
                    </div>
                <ComponentToPrint status={status} ref={(el) => (componentRef = el)} />
            </div>
        </div>
    )
}

class ComponentToPrint extends React.Component {
    state = {
        cod: [],
        my_status: "",
        my_amount: 0,
        id: 0,
        ticket_status:this.props.status,

      }
 
    

    componentDidMount() {
       
        axios.get(`https://api.mahaboudhawholesale.com/order/codtransfer/?active=true`)
        .then(res=>{
            // 
            const cod = res.data;
            this.setState({ cod });
          })
          

          axios.get(`https://api.mahaboudhawholesale.com/order/orders/?sellerId=4&status=5`)
        .then(res=>{
            
            // const cod = res.data;
            // this.setState({ cod });
          })
           
      }
      componentDidUpdate(prevProps, prevState) {
        
        
        if(prevState.ticket_status != this.props.status)
        {
        if(this.props.status == "Active")
        {
            axios.get(`https://api.mahaboudhawholesale.com/order/codtransfer/?active=true`)
            .then(res=>{
                // 
                
                const cod = res.data;
                const ticket_status = "Active"
                this.setState({ticket_status})
                this.setState({ cod });

                
              })
        }
        else if(this.props.status == "Completed")
        {
            axios.get(`https://api.mahaboudhawholesale.com/order/codtransfer/?active=false`)
            .then(res=>{
                
                const cod = res.data;
                const ticket_status = "Completed"
                this.setState({ticket_status})
                this.setState({ cod });
                
              })

        }
        else{
            axios.get(`https://api.mahaboudhawholesale.com/order/codtransfer/`)
            .then(res=>{
                
                const cod = res.data;
                const ticket_status = "Null";
                this.setState({ticket_status});
                this.setState({ cod });
                
              })
        }
    }

    }
      change = event =>{
          
          var a = event.target.value;
          var array = a.split(",");
          var my_amount = 0;
          if (array[1] == 'null')
          {
            my_amount = 0;
          }
          else{
            my_amount = parseInt(array[1]);
          }
          const my_status = array[0];
          const id = parseInt(array[2]);
          this.setState({my_status});
          this.setState({my_amount});
          this.setState({id});


      }
    onReturnPrice = event =>{
        
        var my_amount = event.target.value
        this.setState({my_amount})
    }
    onChangeStatus = event =>{
        
        var my_status = event.target[event.target.selectedIndex].value;
        this.setState({my_status})
    }
    mySave = (e,id) =>{
        
        
        var data = {'return_amount':this.state.my_amount,'status':this.state.my_status,'updated_by':Cookies.get('id')}
        axios.patch(`https://api.mahaboudhawholesale.com/order/codtransfer/${id}/`,data,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
        .then(res=>{
            // 
            // const cod = res.data;
            // this.setState({ cod });
            if(res.data){
                window.location.reload(true);
            }else{
                
            }
          })
    }
             
    
 
    render() {
      return (
        <div>
          <table class="table text-start mt-3">
                    <thead className="border-bottom">
                        <tr>
                            <th scope="col" className="fs-14 fm-11">Ticket Type</th>
                            <th scope="col" className="fs-14 fm-11">Amount</th>
                            <th scope="col" className="fs-14 fm-11">Account Number</th>
                            <th scope="col" className="fs-14 fm-11">Bank Name</th>
                            <th scope="col" className="fs-14 fm-11">Account Holder Name</th>
                            <th scope="col" className="fs-14 fm-11">Bank Branch</th>
                            <th scope="col" className="fs-14 fm-11">Status</th>
                            <th scope="col" className="fs-14 fm-11">Message</th>
                            <th scope="col" className="fs-14 fm-11">Ticket Time</th>
                            <th scope = "col" className = "fs-14 fm-11">Seller</th>
                            <th scope = "col" className = "fs-14 fm-11">Remark</th>
                        </tr>
                    </thead>
                    <tbody>
                   { this.state.cod
            .map(co =>
                
                        <tr className="data-information">
                            <td scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>{co.ticket_type}</td>
                            <td className="fs-13 text-dark">NPR. {co.total_amount}</td>
                            <td className="fs-13 text-dark">{co.account_no}</td>
                            <td className="fs-13 text-dark">{co.bank_name}</td>
                            <td className="fs-13 text-dark">{co.account_holder_name}</td>
                            <td className=" fs-13 text-dark">{co.bank_branch}</td>
                            {
                                this.props.status == "Completed" ?
                                <td className=" fs-13 text-success"><span className="border border-success px-2 py-1 rounded fs-11">{co.status}</span></td>:<td className=" fs-13 text-info"><span className="border border-info px-2 py-1 rounded fs-11">{co.status}</span></td>

                            }
                            <td className=" fs-13 text-dark">{co.message}</td>
                            <td className="fs-13 text-dark">{co.ticket_time}</td>
                            <td className="fs-13 text-dark">{co.seller_id.first_name+" "+co.seller_id.last_name}</td>
                           {this.state.ticket_status == "Active"?<td className="fs-13 text-dark"><button className="back-color border-0 text-white ms-2 px-2 py-1 rounded" onClick={this.change} value ={co.status + "," +co.return_amount+","+co.id} type="button" data-bs-toggle="modal" data-bs-target="#TicketModal">Edit</button></td>:<></>} 
                        </tr>
    )}
                    </tbody>
                </table>
                <div className="modal fade" id="TicketModal" tabindex="-1" aria-labelledby="TicketModalLabel" aria-hidden="true">
                            <div className="modal-dialog">
                                <div className="modal-content">
                                    <div className="modal-body text-start">
                                        <div className="text-end">
                                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div className="col-11 m-auto p-3 py-4">
                                            <form>
                                                <div className="form-group">
                                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Return Amount: <sup className="star"> *</sup></h1>
                                                    <input className="form-control1" defaultValue={this.state.my_amount} onChange={this.onReturnPrice} name="price" placeholder="Enter return amount"  />
                                                </div>
                                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Status: <sup className="star"> *</sup></h1>
                                                <div className="form-group">
                                                    <select className="form-control1" onChange={this.onChangeStatus}>
                                                        <option value={null}>Sort By</option>
                                                        <option value="Pending">Pending</option>
                                                        <option value="Cancelled">Cancelled</option>
                                                        <option value="Delievered">Delivered</option>
                                                        {/* <option value="Remaining">Remaining</option> */}
                                                    </select>
                                                </div>
                                                <div className="mt-3">
                                                    <button className="btn btn-success btn-sm px-4" onClick={(e)=>{this.mySave(e,this.state.id)}} >Save</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
        </div>
      );
    }
  }
export default Admin_allticket;