import React from 'react';

const Today_orderpage = ()=>{
    return(
        <div className="p-3 pt-4">
        <div className="row m-0">
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
        </div>
        <div className="row m-0 mt-3">
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
        </div>
        <div className="row m-0 mt-3">
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
            <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                <p className="pb-0 notification-text1">Total Orders</p>
                <h1 className="text-color dash-margin">83</h1>
            </div>
        </div>
    </div>
    )
}
export default Today_orderpage;