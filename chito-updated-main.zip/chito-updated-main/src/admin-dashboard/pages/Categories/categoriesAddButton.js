import React from "react";
import Controls from "../../../components/forms/controls/Controls";

const CategoriesAddButton = () =>{

    return(
        <>
            <Controls.Button
             text={"Add Categories"}/>

        </>
    )
}

export default CategoriesAddButton;
