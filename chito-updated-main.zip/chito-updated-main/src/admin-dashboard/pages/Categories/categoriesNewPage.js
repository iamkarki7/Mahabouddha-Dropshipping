import React, { useState } from 'react'

import Admin_sidebar from '../../component/sidebar'
import Admin_header from '../../component/header'

import Controls from '../../../components/forms/controls/Controls'
import { useForm1 } from '../../../components/forms/useForm'
import GoogleAutoCompleteComponent from '../../../components/google/googleAutoComplete'
import axios from 'axios'
import { BASE_URL } from '../../../constants/baseURL'
import { AUTHORIZATION_JSON } from '../../../constants/baseURL'
import { useAddCategorieMutation } from '../../../services/slices/CategorySlice/categoriesSlice'
import { Typography } from '@mui/material'
import { useHistory } from 'react-router-dom'


const CategoriesAdd = () => {
    return (
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar />
            </div>
            <div className="col p-0">
                <Admin_header />
                <CategoriesAddPage />
            </div>
        </div>
    )
}

const CategoriesAddPage = () => {
    const [initialFValues, setInitialFValues] = useState({
        category_name: '',
    });

    const { values, handleImageUpload, handleInputChange, handleChangeGoogle } = useForm1(
        initialFValues,
        true,
        false,
        false
    );
    const [SuccessMessege, setSuccesMessege] = useState(null);
    const [ErrorMessege, setErrorMessege] = useState(null);

    const [addCategories] = useAddCategorieMutation();
    const history = useHistory();

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append("category_name", values.category_name);
        addCategories(formData)
            .then((res) => {
                if (res.data) {
                    setSuccesMessege('Catergory successfully added.')
                    setTimeout(() => {
                        history.push('/admin/categories')
                    }, [3000])
                } else {
                    if (res.error) {
                        setErrorMessege(res.error.data.err ? res.error.data.err : res.error.data)
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    } else {
                        setErrorMessege('Problem while adding data.')
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    }
                }
            })
            .catch((err) => {
                setErrorMessege('Some error occur while adding data.')
                setTimeout(() => {
                    setErrorMessege(null)
                }, [3000])
            })
    };


    return (
        <>
            <div className="table-design-background" style={{ padding: "1rem" }}>
                <Typography className="dashboard-home-page-text">
                    Add Categories List
                </Typography>
                <div className="row m-0 mt-4">
                    <div className="col-4 p-0 ">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Category Name:</h1>
                            <Controls.Input
                                onChange={handleInputChange}
                                name="category_name"
                                value={values.category_name} />

                        </div>
                    </div>
                    <div className="col-2 p-0 ">
                        <div className="form-group" style={{ marginTop: "28px" }}>
                            <Controls.Button
                                text={"Submit"}
                                onClick={handleSubmit} />

                        </div>
                    </div>
                </div>
                {ErrorMessege === null ?
                    null :
                    <div className="bg-danger p-3 text-white rounded validate-message">
                        <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessege} </strong>
                    </div>
                }
                {SuccessMessege === null ?
                    null :
                    <div className="bg-success p-3 text-white rounded validate-message">
                        <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessege} </strong>
                    </div>
                }
            </div>
        </>
    )
}

export default CategoriesAdd;