import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Admin_sidebar from "../../component/sidebar";
import Admin_header from "../../component/header";
import { Grid, Typography } from "@mui/material";
import BasicTable from "../../../components/tables/BasicTable";
import {
  useGetCategorieByIdQuery,
  useGetCategoriesPaginationQuery,
  useDeleteCategorieMutation,
  useUpdateCategorieMutation
} from "../../../services/slices/CategorySlice/categoriesSlice";
import CategoriesAddButton from "./categoriesAddButton";
import { Box } from "@mui/material";
import { getPaginationPagesCount } from "../../../components/forms/utils/getPaginationPagesCount";

const DashboardCategories = () => {
  return (
    <Grid container className="dashboard-full-background">
      <Grid item xs={1} spacing={4}>
        <Admin_sidebar />
      </Grid>
      <Grid item xs={11}>
        <Admin_header />
        <DashboardCategoriesPages />
      </Grid>
    </Grid>
  );
};

const DashboardCategoriesPages = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [headers, setHeaders] = useState([]);
  const [tableData, setTableData] = useState([]);
  const { data, isLoading, isSuccess, isError, error } =
    useGetCategoriesPaginationQuery(currentPage);

  const [deleteBlog] = useDeleteCategorieMutation();

  const deleteConfirm = (e, id) => {
    e.preventDefault();

    deleteBlog({ id });
  };


  let content;
  useEffect(() => {
    if (isLoading) {
      content = <p>"Loading..."</p>;
    } else if (isSuccess) {
      setHeaders(["Category Name"]);
      let tableDatas = [];
      data?.results?.forEach((key) => {
        tableDatas.push({
          "Category Name": key.category_name,
          id: key.id,
        });
      });
      setTableData(tableDatas);
      setTotalPages(getPaginationPagesCount(data.count, 10));
    }
  }, [isLoading, isSuccess, data])
  return (
    <>
      <Box className="table-design-background">
        <Grid container>
          <Grid item xs={10}>
            <Typography className="dashboard-home-page-text" style={{ marginLeft: '20px' }}>
              Categories List
            </Typography>
          </Grid>
          <Grid item xs={2}>
            <Box style={{ padding: '10px', textAlign: 'right', marginRight: '15px' }}>
              <Link to="/admin/new/categories" style={{ textDecoration: 'none', }}>
                <CategoriesAddButton />
              </Link>
            </Box>
          </Grid>
        </Grid>
        <Box style={{ padding: "1.5rem", }}>
          <BasicTable
            headers={headers}
            data={tableData}
            isDelete={true}
            deleteColor={"#f50057"}
            isEdit={true}
            editColor={"#3f51b5"}
            addColor={""}
            tableName={"categories"}
            deleteConfirm={deleteConfirm}
            setCurrentPage={setCurrentPage}
            setTotalPages={setTotalPages}
            totalPages={totalPages}
          />
        </Box>
      </Box>
    </>
  );
};
export default DashboardCategories;

