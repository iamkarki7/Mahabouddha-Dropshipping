import axios from 'axios';
import Cookies from 'js-cookie';
import React, { createContext, useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { useEffect } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { ExportToExcel } from '../../user-dashboard/components/excelsheet';
import * as FileSaver from "file-saver";
import Tippy from '@tippy.js/react';
import 'tippy.js/dist/tippy.css';
import { changePaginationButton } from '../../functions/paginationButton';


const Neworder_page = () => {
    const [pendingOrder, setPendingOrder] = useState([]);
    const [searchOrder, setSearchOrder] = useState([]);
    const [changeTime, setChangeTime] = useState([]);
    const [status, setStatus] = useState([]);
    const [pageID, setPageId] = useState(1);
    const [dataNo, setDataNo] = useState(-1);
    const [nextValue, setNextValue] = useState(1)
    const [buttonNo, setButtonNo] = useState([]);
    const [Search, setSearch] = useState("");


    useEffect(() => {
        if (dataNo != -1) {
            const buttonNo = changePaginationButton(dataNo, nextValue);
            setButtonNo(buttonNo.array);
            setNextValue(buttonNo.next);
            setPageId(buttonNo.defaultValue);
        }
    }, [nextValue, dataNo])

    const onButtonValue = (e, id) => {
        if (id === "Next") {
            setNextValue(nextValue + 1);
        }
        if (id === "Prev") {
            setNextValue(nextValue - 1);
        }
        setPageId(parseInt(id));
    }


    var id = Cookies.get('id');
    id = parseInt(id);
    var d = new Date();



    var today_fulldate = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()

    var last_year = new Date(new Date().setFullYear(new Date().getFullYear() - 1))
    var last_year_fulldate = last_year.getFullYear() + "-" + (last_year.getMonth() + 1) + "-" + last_year.getDate()
    var last_semiannual = new Date(new Date().setMonth(new Date().getMonth() - 6))
    var last_semiannual_fulldate = last_semiannual.getFullYear() + "-" + (last_semiannual.getMonth() + 1) + "-" + last_semiannual.getDate()
    var last_quarter = new Date(new Date().setMonth(new Date().getMonth() - 3))
    var last_quarter_fulldate = last_quarter.getFullYear() + "-" + (last_quarter.getMonth() + 1) + "-" + last_quarter.getDate()
    var last_month = new Date(new Date().setMonth(new Date().getMonth() - 1))
    var last_month_fulldate = last_month.getFullYear() + "-" + (last_month.getMonth() + 1) + "-" + last_month.getDate()
    var last_week = new Date(new Date().setDate(new Date().getDate() - 7))
    var last_week_fulldate = last_week.getFullYear() + "-" + (last_week.getMonth() + 1) + "-" + last_week.getDate()
    var tomorrow = new Date(new Date().setDate(new Date().getDate() + 1))
    var tomorrow_fulldate = tomorrow.getFullYear() + "-" + (tomorrow.getMonth() + 1) + "-" + tomorrow.getDate()

    var firstdate = "1960-01-01"

    const onChange_Time = (e) => {

        if (e.target.value == "Custom") {
            setNewSwitch(true);
        }
        else {
            setNewSwitch(false)
        }
        setChangeTime(e.target.value);
        if (e.target.value == "Delivery Type") {
            setNewSwitch1(true);
        }
        else {
            setNewSwitch1(false);
        }
        if (e.target.value == "By Payment") {
            setNewSwitch2(true);
        }
        else {
            setNewSwitch2(false);
        }
    }
    var first_date = firstdate
    var last_date = tomorrow_fulldate;


    if (changeTime == "") {
        first_date = firstdate;
    }
    else if (changeTime == "yearly") {
        first_date = last_year_fulldate;
    }
    else if (changeTime == 'hYearly') {
        first_date = last_semiannual_fulldate;
    }
    else if (changeTime == "quarterly") {
        first_date = last_quarter_fulldate;
    }
    else if (changeTime == "monthly") {
        first_date = last_month_fulldate;
    }
    else if (changeTime == "weekly") {
        first_date = last_week_fulldate;
    }
    else if (changeTime == "daily") {

        first_date = today_fulldate;
        last_date = tomorrow_fulldate;
    }
    else {
        first_date = firstdate
    }
    const [riders, setRiders] = useState([]);
    const [myriders, setmyriders] = useState([]);
    const [NewSwitch, setNewSwitch] = useState(false);

    var rider_id = ""
    for (var i = 0; i < myriders.length; i++) {
        if (myriders[i] == ":") {
            break;
        }
        rider_id = rider_id + myriders[i]

    }
    var myorder_id = ""
    var current_value = 0
    for (var i = 0; i < myriders.length - 1; i++) {
        if (myriders[i] == ",") {
            current_value = 1
        }
        if (current_value == 1) {
            myorder_id = myorder_id + myriders[i + 1];
        }
    }


    useEffect(() => {
        axios.patch(`https://api.mahaboudhawholesale.com/order/orders/${myorder_id}/`, { rider_name: rider_id, 'updated_by': parseInt(Cookies.get('id')) }, { headers: { Authorization: Cookies.get('access_token') ? 'JWT ' + Cookies.get('access_token') : null, 'Content-Type': 'application/json' } })
            .then((res) => {

            })
    }, [rider_id, myorder_id])
    const [StatusValue, setStatusValue] = useState(1);



    //pagination for admin

    useEffect(() => {
        axios.get(`https://api.mahaboudhawholesale.com/user/user/?is_driver=true`)
            .then((res) => {


                var arr = []
                for (var i = 0; i < res.data.length; i++) {
                    arr.push(res.data[i])
                }


                setRiders(arr);
            })
    }, [])


    useEffect(() => {
        axios.get(`https://api.mahaboudhawholesale.com/order/status/`)
            .then((res) => {


                setStatus(res.data);
            })

    }, [])

    useEffect(() => {
        if (Search.length < 3) {
            console.log("first")
            axios.get(`https://api.mahaboudhawholesale.com/order/orders-page/?page=${pageID}&status=${StatusValue}&created_date__gte=${first_date}&created_date__lte=${last_date}`)
                .then((res) => {

                    setDataNo(parseInt(res.data.count));

                    var data = res.data.results;
                    var array = []

                    for (var i = 0; i < data.length; i++) {

                        var date = new Date(data[i].created_date);
                        date = date.toLocaleString();
                        data[i].created_date = date;
                    }
                    array.push(data);
                    setPendingOrder(data);
                })
        }
    }, [id, first_date, last_date, pageID, StatusValue])

    useEffect(() => {
        if (Search.length >= 3) {
            axios.post(`https://api.mahaboudhawholesale.com/order/orders/search/`, { search: Search })
                .then((res) => {
                    console.log("second")
                    var data = res.data
                    var array = [];
                    for (var i = 0; i < data.length; i++) {

                        var date = new Date(data[i].created_date);
                        date = date.toLocaleString();
                        data[i].created_date = date;
                    }

                    array.push(data);

                    setSearchOrder(data);

                })
        }
    }, [Search])

    function setCancel(e, id) {
        if (e) {
            if (window.confirm(`Would you like to confirm this ${e} request?`)) {
                for (var i = 0; i < status.length; i++) {
                    if (e == status[i].status_name) {
                        var status_id = parseInt(status[i].id);
                    }
                }


                axios.patch(`https://api.mahaboudhawholesale.com/order/orders/${id}/`, { 'status': status_id, 'updated_by': parseInt(Cookies.get('id')) }, { headers: { Authorization: Cookies.get('access_token') ? 'JWT ' + Cookies.get('access_token') : null, 'Content-Type': 'application/json' } })
                    .then(res => {
                        setStatus(status_id)
                        window.location.reload(true);
                    })
            }
            // window.location.reload(true);


        } else {
            var txt = "You pressed Cancel!";
        }
    }
    function myPdf(a, b, c, d) {


        axios.post(`https://api.mahaboudhawholesale.com/order/docs/`, { 'start_date': a, 'end_date': b, 'document_type': c, 'user_id': d })
            .then((res) => {
                axios.get(`https://api.mahaboudhawholesale.com/order/dump/`,
                    { headers: { 'Content-Type': "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }, responseType: "arraybuffer" }
                )
                    .then((response) => {
                        (response.data)
                            (typeof (response.data))
                        var blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                        FileSaver.saveAs(blob, 'fixi.xlsx');
                    })
            })

    }
    function myXls(a, b, c, d) {

    }
    //exporting data to excel sheet
    const fileName = 'allorderdata';
    const fileName1 = 'pending_order';
    const fileName2 = 'approved_order';
    const fileName3 = 'hold_order';
    const fileName4 = 'checked_in_order';
    const fileName5 = 'delivered_order';
    const fileName6 = 'cancelled_order';
    // here enter filename for your excel file


    //custom select option value from date

    const [Newshow, setNewshow] = useState(false);
    const [NewDoc, setNewDoc] = useState(false);

    const [xceldata, setxcelData] = React.useState([])
    const xcelfileName = "myfile"; // here enter filename for your excel file
    const [mydriver, setmydriver] = useState([]);
    const [NewSwitch1, setNewSwitch1] = useState(false);
    const [NewSwitch2, setNewSwitch2] = useState(false);

    //exporting data to excel sheet
    const [ExcelData, setExcelData] = useState([]);

    useEffect(() => {
        const ExcelNewData = () => {
            axios.get(`https://api.mahaboudhawholesale.com/order/orders/`)
                .then((res) => {
                    setExcelData(res.data);
                })
                .catch((err) => {

                })
        }
        ExcelNewData();
    }, [])
    //end of excel sheet


    React.useEffect(() => {
        const fetchData = () => {
            axios.get('https://api.mahaboudhawholesale.com/order/dump/').then(r => setxcelData(r.data))
        }
        fetchData()
    }, [])

    //date picker filter
    const [Formdate, setFormdate] = useState(new Date());
    const [Todate, setTodate] = useState(new Date());

    const onFormdate = date => setFormdate(date);
    const onTodate = date => setTodate(date);

    const [ShowExport, setShowExport] = useState(false);
    const onMyriders = async (e, id) => {
        let driver = e.target[e.target.selectedIndex].value
        driver = driver.split(":");
        setmyriders(id);
        const { data } = await axios.patch(`https://api.mahaboudhawholesale.com/order/orders/${parseInt(id)}/`,
            { 'rider_name': parseInt(driver[0]) },
            { headers: { Authorization: Cookies.get('access_token') ? 'JWT ' + Cookies.get('access_token') : null, 'Content-Type': 'application/json' } })

    }
    const [ExportedData, setExportedData] = useState([]);


    useEffect(() => {
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?status=${StatusValue}`)
            .then((res) => {

                setExportedData(res.data);
            })
            .catch((err) => {

            })
    }, [StatusValue])




    return (
        <div className="mt-3 p-2">
            <div className="p-3 pt-4 bg-white mb-5 pb-5 rounded">
                <div className="row m-0">
                    <div className="col-lg-2 p-0 text-start me-lg-4">
                        <p className="form-text text-dark">Export Data </p>
                        <button onClick={(e) => setShowExport(true)} className="btn btn-white rounded-0 border-dark btm-sm py-1 fs-14 fm-11 fw-bolder download-information w-100"><i className="fa fa-download"></i> Export File</button>
                        {/* <ExportToExcel onClick={(e)=>setShowExport(true)} apiData={ExcelData} fileName={file_Name} /> */}
                        {
                            ShowExport === true ?
                                <div className='position-absolute bg-white p-3 export-data py-3 shadow-sm mt-2'>
                                    <i className='fa fa-close position-absolute text-danger' style={{ top: '0rem', right: '0rem' }} onClick={(e) => setShowExport(false)}></i>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName1} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Pending Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName2} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Approved Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName3} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Hold Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName4} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Checked In Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName5} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Delivered Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName6} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Cancelled Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExcelData} fileName={fileName} /> <span className='ms-2 fw-bolder fs-11 pt-2'>All Order</span></div>
                                </div> : null
                        }
                    </div>
                    <div className="col-lg-3 p-0">
                        <div className="row m-0 mt-lg-0 mt-3">
                            <div className="col-lg col-6 p-0 ms-lg-3 text-start">
                                <p className="form-text text-dark">By Status </p>
                                <select className="form-control1" onChange={onChange_Time}>
                                    <option value={null}>Sort By</option>
                                    <option value="yearly">Yearly</option>
                                    <option value="hYearly">Half Yearly</option>
                                    <option value="quarterly">Quarterly</option>
                                    <option value="monthly">Monthly</option>
                                    <option value="weekly">Weekly</option>
                                    <option value="daily">Daily</option>
                                    <option>Delivery Type</option>
                                    <option>By Payment</option>
                                    <option>Custom</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-3 p-0">
                        <div className="row m-0 mt-lg-0 mt-3">
                            <div className="col-lg col-6 p-0 ms-lg-3 text-start">
                                <p className="form-text text-dark">Search </p>
                                <input type="text" id="search" name="search" onChange={(e) => setSearch(e.target.value)} />
                            </div>
                        </div>
                    </div>
                    {
                        NewSwitch1 === true ?
                            <div className="col p-0 ms-lg-4 ms-md-2">
                                <div className="">
                                    <div className="row m-0 text-start">
                                        <div className="col-lg col-6 p-0 mt-lg-0 mt-3">
                                            <p className="form-text text-dark">Delivery Type</p>
                                            <div className="d-flex">
                                                <select className='form-control1'>
                                                    <option value={null}>Select delivery type</option>
                                                    <option value={1}>Normal</option>
                                                    <option value={2}>Express</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-lg col p-0 ms-lg-4 ms-lg-2 mt-lg-0 mt-3">
                                            {/* <p className="form-text text-dark">To </p>
                                    <div className="d-flex">
                                        <DatePicker selected={Todate} onChange={onTodate} className="form-control1 form-width"/>
                                    </div> */}
                                        </div>
                                    </div>
                                </div>
                            </div> : null
                    }
                    {
                        NewSwitch2 === true ?
                            <div className="col p-0 ms-lg-4 ms-md-2">
                                <div className="">
                                    <div className="row m-0 text-start">
                                        <div className="col-lg col-6 p-0 mt-lg-0 mt-3">
                                            <p className="form-text text-dark">Payment Type</p>
                                            <div className="d-flex">
                                                <select className='form-control1'>
                                                    <option value={null}>Select payment type</option>
                                                    <option value={false}>Pending</option>
                                                    <option value={true}>Completed</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-lg col p-0 ms-lg-4 ms-lg-2 mt-lg-0 mt-3">
                                            {/* <p className="form-text text-dark">To </p>
                                    <div className="d-flex">
                                        <DatePicker selected={Todate} onChange={onTodate} className="form-control1 form-width"/>
                                    </div> */}
                                        </div>
                                    </div>
                                </div>
                            </div> : null
                    }
                    {
                        NewSwitch === true ?
                            <div className="col p-0 ms-lg-4 ms-md-2">
                                <div className="">
                                    <div className="row m-0 text-start">
                                        <div className="col-lg col-6 p-0 mt-lg-0 mt-3">
                                            <p className="form-text text-dark">From </p>
                                            <div className="d-flex">
                                                <DatePicker selected={Formdate} onChange={onFormdate} className="form-control1 form-width" />
                                            </div>
                                        </div>
                                        <div className="col-lg col p-0 ms-lg-4 ms-lg-2 mt-lg-0 mt-3">
                                            <p className="form-text text-dark">To </p>
                                            <div className="d-flex">
                                                <DatePicker selected={Todate} onChange={onTodate} className="form-control1 form-width" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> : null
                    }
                </div>
            </div>
            <div className="p-3 pt-4 bg-white">
                <ul className="nav nav-tabs" id="myTab" role="tablist">
                    <li className="nav-item" role="presentation">
                        <button className="nav-link active form-text2" id="Pending_tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab" aria-controls="pending" aria-selected="true" onClick={() => setStatusValue('1')}>Pending Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2" id="Approved_tab" data-bs-toggle="tab" data-bs-target="#approved" type="button" role="tab" aria-controls="approved" aria-selected="false" onClick={() => setStatusValue('2')}>Approved Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2" id="Hold_tab" data-bs-toggle="tab" data-bs-target="#hold" type="button" role="tab" aria-controls="hold" aria-selected="false" onClick={() => setStatusValue('3')}>Hold Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2" id="Checked_in_tab" data-bs-toggle="tab" data-bs-target="#checked" type="button" role="tab" aria-controls="checked" aria-selected="false" onClick={() => setStatusValue('4')}>Checked In Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2" id="Delivered_order_tab" data-bs-toggle="tab" data-bs-target="#delivered" type="button" role="tab" aria-controls="delivered" aria-selected="false" onClick={() => setStatusValue('5')}>Delivered Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2" id="Cancelled_tab" data-bs-toggle="tab" data-bs-target="#cancelled" type="button" role="tab" aria-controls="cancelled" aria-selected="false" onClick={() => setStatusValue('6')}>Cancelled Order</button>
                    </li>
                </ul>
                <div className="tab-content" id="myTabContent">
                    <div className="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="Pending_tab">
                        <table className="table border-0 mt-4 text-start">
                            <thead className='border-bottom'>
                                <tr className="bg-white">
                                    <th scope="col " className="fs-14">Order Number</th>
                                    <th scope="col " className="fs-14">Customer Name</th>
                                    <th scope="col" className="fs-14">Customer Mobile</th>
                                    <th scope="col" className="fs-14">Seller Name</th>
                                    <th scope="col" className="fs-14">Seller Mobile</th>
                                    <th scope="col" className="fs-14">Created Date</th>
                                    <th scope="col" className="fs-14">Rider</th>
                                    <th scope="col" className="fs-14">Status</th>
                                    <th scope="col" className="fs-14">Details</th>
                                </tr>
                            </thead>
                            {
                                StatusValue ?
                                    <tbody>
                                        {Search.length < 3 ?
                                            <>
                                                {pendingOrder.map(key => (

                                                    <tr className="data-information">
                                                        <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                                                        <td className="fs-13 text-dark">{key.customer_name}</td>
                                                        <td className="fs-13 text-dark">{key.customer_mobile}</td>
                                                        <td className="fs-13 text-dark">{key.sellerId.first_name} {key.sellerId.last_name}</td>
                                                        <td className="fs-13 text-dark">{key.sellerId.contactno}</td>
                                                        <td className="fs-13 text-dark">{key.created_date}</td>

                                                        {key.status.status_name == "Pending" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue={key.rider_name.id + ":" + key.rider_name.first_name + " " + key.rider_name.last_name} onChange={(e) => onMyriders(e, key.id)}>
                                                                <option value={null} className="text-dark" >Select Rider</option>
                                                                {
                                                                    riders.map(rider => (
                                                                        <option value={rider.id + ":" + rider.first_name + " " + rider.last_name} className="text-dark">{rider.id + ":" + rider.first_name + " " + rider.last_name}</option>
                                                                    ))
                                                                }
                                                            </select>
                                                        </td> : <td className="fs-13 text-dark">{key.rider_name.id + ":" + key.rider_name.first_name + " " + key.rider_name.last_name}</td>}
                                                        {key.status.status_name == "Pending" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue="Pending" onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                                {
                                                                    Array.isArray(status) && status.length > 0 ? (
                                                                        status.map((state) => (
                                                                            <option key={state.status_name} value={state.status_name} className="text-dark">
                                                                                {state.status_name}
                                                                            </option>
                                                                        ))
                                                                    ) : (
                                                                        <option value={null} className="text-dark">
                                                                            Select Status
                                                                        </option>
                                                                    )
                                                                }
                                                            </select>
                                                        </td> : null}
                                                        {key.status.status_name == "Approved" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue="Approved" onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                                <option value={null} className="text-dark" >Select Status</option>
                                                                {
                                                                    Array.isArray(status) && status.length > 0 ? (
                                                                        status.map((state) => (
                                                                            <option key={state.status_name} value={state.status_name} className="text-dark">
                                                                                {state.status_name}
                                                                            </option>
                                                                        ))
                                                                    ) : (
                                                                        <option value={null} className="text-dark">
                                                                            Select Status
                                                                        </option>
                                                                    )
                                                                }
                                                            </select>
                                                        </td> : null}
                                                        {key.status.status_name == "Hold" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue="Hold" onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                                <option value={null} className="text-dark" >Select Status</option>
                                                                {
                                                                    Array.isArray(status) && status.length > 0 ? (
                                                                        status.map((state) => (
                                                                            <option key={state.status_name} value={state.status_name} className="text-dark">
                                                                                {state.status_name}
                                                                            </option>
                                                                        ))
                                                                    ) : (
                                                                        <option value={null} className="text-dark">
                                                                            Select Status
                                                                        </option>
                                                                    )
                                                                }
                                                            </select>
                                                        </td> : null}
                                                        {key.status.status_name == "Checked In" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue="Checked In" onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                                <option value={null} className="text-dark" >Select Status</option>
                                                                {
                                                                    Array.isArray(status) && status.length > 0 ? (
                                                                        status.map((state) => (
                                                                            <option key={state.status_name} value={state.status_name} className="text-dark">
                                                                                {state.status_name}
                                                                            </option>
                                                                        ))
                                                                    ) : (
                                                                        <option value={null} className="text-dark">
                                                                            Select Status
                                                                        </option>
                                                                    )
                                                                }
                                                            </select>
                                                        </td> : null}
                                                        {key.status.status_name == "Delievered" ? <td className="fs-13 text-success">
                                                            {key.status.status_name}
                                                        </td> : null}
                                                        {key.status.status_name == "Cancelled" ? <td className="fs-13 text-danger">
                                                            {key.status.status_name}
                                                        </td> : null}
                                                        <td className="text-dark fs-13">
                                                            {key.status.status_name == "Pending" ?
                                                                <Tippy content="Update"><Link className="text-decoration-none text-info header-background px-2 py-1 rounded me-2" to={`/order/update/${key.OrderNumber}`}><i className="fa fa-edit text-white"></i></Link></Tippy> : null}
                                                            <Tippy content="View"><Link to={`/admin/view/my/data/${key.OrderNumber}`} className='text-decoration-none back-color text-white ms-2 px-2 py-1 rounded'><i className="fa fa-eye text-white"></i></Link></Tippy>

                                                        </td>
                                                    </tr>
                                                ))}
                                            </> :
                                            <>
                                                {searchOrder.map(key => (

                                                    <tr className="data-information">
                                                        <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                                                        <td className="fs-13 text-dark">{key.customer_name}</td>
                                                        <td className="fs-13 text-dark">{key.customer_mobile}</td>
                                                        <td className="fs-13 text-dark">{key.sellerId.first_name} {key.sellerId.last_name}</td>
                                                        <td className="fs-13 text-dark">{key.sellerId.contactno}</td>
                                                        <td className="fs-13 text-dark">{key.created_date}</td>

                                                        {key.status.status_name == "Pending" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue={key.rider_name.id + ":" + key.rider_name.first_name + " " + key.rider_name.last_name} onChange={(e) => onMyriders(e, key.id)}>
                                                                <option value={null} className="text-dark" >Select Rider</option>
                                                                {
                                                                    riders && riders.map(rider => (
                                                                        <option value={rider.id + ":" + rider.first_name + " " + rider.last_name} className="text-dark">{rider.id + ":" + rider.first_name + " " + rider.last_name}</option>
                                                                    ))
                                                                }
                                                            </select>
                                                        </td> : <td className="fs-13 text-dark">{key.rider_name.id + ":" + key.rider_name.first_name + " " + key.rider_name.last_name}</td>}
                                                        {key?.status?.status_name == "Pending" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue="Pending" onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                                {
                                                                    Array.isArray(status) && status.length > 0 ? (
                                                                        status.map((state) => (
                                                                            <option key={state.status_name} value={state.status_name} className="text-dark">
                                                                                {state.status_name}
                                                                            </option>
                                                                        ))
                                                                    ) : (
                                                                        <option value={null} className="text-dark">
                                                                            Select Status
                                                                        </option>
                                                                    )
                                                                }
                                                            </select>
                                                        </td> : null}
                                                        {key?.status?.status_name == "Approved" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue="Approved" onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                                {
                                                                    Array.isArray(status) && status.length > 0 ? (
                                                                        status.map((state) => (
                                                                            <option key={state.status_name} value={state.status_name} className="text-dark">
                                                                                {state.status_name}
                                                                            </option>
                                                                        ))
                                                                    ) : (
                                                                        <option value={null} className="text-dark">
                                                                            Select Status
                                                                        </option>
                                                                    )
                                                                }
                                                            </select>
                                                        </td> : null}
                                                        {key?.status?.status_name == "Hold" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue="Hold" onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                                {
                                                                    Array.isArray(status) && status.length > 0 ? (
                                                                        status.map((state) => (
                                                                            <option key={state.status_name} value={state.status_name} className="text-dark">
                                                                                {state.status_name}
                                                                            </option>
                                                                        ))
                                                                    ) : (
                                                                        <option value={null} className="text-dark">
                                                                            Select Status
                                                                        </option>
                                                                    )
                                                                }
                                                            </select>
                                                        </td> : null}
                                                        {key?.status?.status_name == "Checked In" ? <td className="fs-13 text-dark">
                                                            <select className='border-0 new-border px-2 py-1' defaultValue="Checked In" onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                                {
                                                                    Array.isArray(status) && status.length > 0 ? (
                                                                        status.map((state) => (
                                                                            <option key={state.status_name} value={state.status_name} className="text-dark">
                                                                                {state.status_name}
                                                                            </option>
                                                                        ))
                                                                    ) : (
                                                                        <option value={null} className="text-dark">
                                                                            Select Status
                                                                        </option>
                                                                    )
                                                                }
                                                            </select>
                                                        </td> : null}
                                                        {key?.status?.status_name == "Delievered" ? <td className="fs-13 text-success">
                                                            {key.status.status_name}
                                                        </td> : null}
                                                        {key?.status?.status_name == "Cancelled" ? <td className="fs-13 text-danger">
                                                            {key.status.status_name}
                                                        </td> : null}
                                                        <td className="text-dark fs-13">
                                                            {key?.status?.status_name == "Pending" ?
                                                                <Tippy content="Update"><Link className="text-decoration-none text-info header-background px-2 py-1 rounded me-2" to={`/order/update/${key.OrderNumber}`}><i className="fa fa-edit text-white"></i></Link></Tippy> : null}
                                                            <Tippy content="View"><Link to={`/admin/view/my/data/${key.OrderNumber}`} className='text-decoration-none back-color text-white ms-2 px-2 py-1 rounded'><i className="fa fa-eye text-white"></i></Link></Tippy>

                                                        </td>
                                                    </tr>
                                                ))}
                                            </>}
                                    </tbody> : null
                            }
                            {buttonNo.map((key) => (
                                <button onClick={(e) => onButtonValue(e, key)} className="new-pagination-button">{key}</button>
                            ))}

                        </table>
                    </div>
                </div>
            </div>
        </div>

    )
}
export default Neworder_page;

