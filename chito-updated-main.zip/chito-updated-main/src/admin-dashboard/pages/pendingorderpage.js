import React from 'react';

const Pending_orderpage = ()=>{
    return(
        <div className="px-3">
            <div className="bg-white shadow-sm p-4 mt-4" style={{overflowX:'auto'}}>
                <div className="">          
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Order No.</th>
                                <th>Order Id</th>
                                <th>Status</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>123</td>
                                <td>354</td>
                                <td>Not Delivered</td>
                                <td><button className="btn btn-info text-white btn-sm me-2"><i className="fa fa-eye"></i></button><button className="btn btn-danger btn-sm"><i className="fa fa-trash"></i></button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}
export default Pending_orderpage;