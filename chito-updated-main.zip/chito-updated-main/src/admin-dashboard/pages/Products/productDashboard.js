import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Admin_sidebar from "../../component/sidebar";
import Admin_header from "../../component/header";
import { Grid, Typography } from "@mui/material";
import BasicTable from "../../../components/tables/BasicTable";
import {
  useGetProductsPaginationQuery,
  useUpdateProductMutation,
  useDeleteProductMutation,
  useSearchProductMutation
} from "../../../services/slices/ProductSlice/productSlice";
import ProductAddButton from "./productAddButton";
import { Box } from "@mui/material";
import { getPaginationPagesCount } from "../../../components/forms/utils/getPaginationPagesCount";
import Controls from '../../../components/forms/controls/Controls'



const DashboardProducts = () => {
  return (
    <Grid container className="dashboard-full-background">
      <Grid item xs={1} spacing={4}>
        <Admin_sidebar />
      </Grid>
      <Grid item xs={11}>
        <Admin_header />
        <DashboardProductsPages />
      </Grid>
    </Grid>
  );
};

const DashboardProductsPages = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [headers, setHeaders] = useState([]);
  const [tableData, setTableData] = useState([]);
  const { data, isLoading, isSuccess, isError, error } =
    useGetProductsPaginationQuery(currentPage)

  const [deleteProduct] = useDeleteProductMutation();
  const [searchProducts] = useSearchProductMutation();
  const [original, setOriginal] = useState(false);

  const onSearch = (e) =>{
    
    searchProducts({'search': e})
    .then((res)=>{
      if(res.data.length>0)
      {
        let tableDatas = [];
        res.data.forEach((key) => {
          tableDatas.push({
            "Product Name": key.product_name,
            "Categories": key.categories.category_name,
            "Product Image": key.product_image,
            "Product Price": key.product_price,
            id: key.id,
          });
        });
        setTableData(tableDatas);
        setOriginal(true);
      }
      else{
        
        setOriginal(false);
      }
    })
  }

  const deleteConfirm = (e, id) => {
    e.preventDefault();

    deleteProduct({ id });
  };

  let content;
  useEffect(() => {
    
    if (isLoading) {
      content = <p>"Loading..."</p>;
    } else if (isSuccess) {
      if(!original)
      {
        setHeaders(["Product Name", "Categories", "Product Price", "Product Image"]);
        let tableDatas = [];
        data.results.forEach((key) => {
          tableDatas.push({
            "Product Name": key.product_name,
            "Categories": key.categories.category_name,
            "Product Image": key.product_image,
            "Product Price": key.product_price,
            id: key.id,
          });
        });
        setTableData(tableDatas);
        setTotalPages(getPaginationPagesCount(data.count, 100));
      }
    }
  }, [isLoading, isSuccess, data, original])
  return (
    <>
      <Box className="table-design-background">
        <Grid container>
          <Grid item xs={5}>
            <Typography className="dashboard-home-page-text" style={{ marginLeft: '20px' }}>
              Products List
            </Typography>
          </Grid>
          <Grid item xs={5}>
            <Controls.Search
              onChange={onSearch}
              name="searchProduct"
              label="Search Product"/>
          </Grid>
          <Grid item xs={2}>
            <Box style={{ padding: '10px', textAlign: 'right', marginRight: '15px' }}>
              <Link to="/admin/new/products" style={{ textDecoration: 'none' }}>
                <ProductAddButton />
              </Link>
            </Box>
          </Grid>
        </Grid>
        <Box style={{ padding: "1.5rem" }}>
          <BasicTable
            headers={headers}
            data={tableData}
            isDelete={true}
            deleteColor={"#f50057"}
            isEdit={true}
            editColor={"#3f51b5"}
            addColor={""}
            tableName={"products"}
            deleteConfirm={deleteConfirm}
            setCurrentPage={setCurrentPage}
            setTotalPages={setTotalPages}
            totalPages={totalPages}
            cdn={true}
          />
        </Box>
      </Box>
    </>
  );
};
export default DashboardProducts;

