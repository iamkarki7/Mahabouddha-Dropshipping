import React, { useEffect, useState } from 'react'

import Admin_sidebar from '../../component/sidebar'
import Admin_header from '../../component/header'

import Controls from '../../../components/forms/controls/Controls'
import { useForm1 } from '../../../components/forms/useForm'
import { useAddProductMutation } from '../../../services/slices/ProductSlice/productSlice'
import { useGetCategoriesQuery } from '../../../services/slices/CategorySlice/categoriesSlice'
import BlobToFile from '../../../components/forms/utils/blobToFile'
import { Box } from '@mui/system'
import { Grid, Typography } from '@mui/material'
import { useHistory } from 'react-router-dom';


const ProductAdd = () => {
    return (
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar />
            </div>
            <div className="col p-0">
                <Admin_header />
                <ProductAddPage />
            </div>
        </div>
    )
}

const ProductAddPage = () => {
    const [File, setFile] = useState([]);
    const [category, setCategory] = useState([]);

    const categories = useGetCategoriesQuery();



    useEffect(() => {
        let categoryList = []
        categories?.data?.ids?.map((key) => {
            categoryList.push(
                { id: key, title: categories.data.entities[key].category_name }
            )
        })
        setCategory(categoryList);
    }, [categories])

    const [initialFValues, setInitialFValues] = useState({
        categories: "",
        product_name: "",
        product_description: "",
        product_image: [],
        product_price: 0.0
    });
    const { values, handleImageUpload, handleInputChange, handleChangeGoogle } = useForm1(
        initialFValues,
        true,
        false,
        false
    );

    useEffect(() => {
        handleImageUpload("product_image", File);
    }, [File]);
    const [SuccessMessege, setSuccesMessege] = useState(null);
    const [ErrorMessege, setErrorMessege] = useState(null);


    const [addProducts] = useAddProductMutation();

    const history = useHistory();



    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        var file = BlobToFile(values.product_image, "product");
        if (file.length !== 0) {
            formData.append("product_image", file, "product.jpg");
        }

        formData.append("product_name", values.product_name);
        formData.append("categories", values.categories);
        formData.append("product_description", values.product_description);
        formData.append("product_price", values.product_price);
        addProducts(formData)
            .then((res) => {
                if (res.data) {
                    setSuccesMessege('Product successfully added.')
                    setTimeout(() => {
                        history.push('/admin/products')
                    }, [3000])
                } else {
                    if (res.error) {
                        setErrorMessege(res.error.data.err ? res.error.data.err : res.error.data)
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    } else {
                        setErrorMessege('Problem while adding data.')
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    }
                }
            })
            .catch((err) => {
                setErrorMessege('Some error occur while adding data.')
                setTimeout(() => {
                    setErrorMessege(null)
                }, [3000])
            })
    };


    return (
        <>
            <Box className="table-design-background">
                <Typography className="dashboard-home-page-text" style={{ marginLeft: '20px' }}>
                    Update Product
                </Typography>
                <Box style={{ padding: "1rem", paddingTop: '1rem' }}>
                    <Grid container spacing={3}>
                        <Grid item xs={4}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Product Name:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="product_name"
                                    value={values.product_name} />
                            </div>
                        </Grid>
                        <Grid item xs={4}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Product Description:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="product_description"
                                    value={values.product_description} />

                            </div>
                        </Grid>
                        {/* <Grid item xs={4}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Product Price:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="product_price"
                                    value={values.product_price} />

                            </div>
                        </Grid> */}
                        <Grid item xs={4}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Product Price:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="product_price"
                                    value={values.product_price} />

                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Categories:</h1>
                                <Controls.SearchAutoComplete
                                    onChange={handleInputChange}
                                    name="categories"
                                    value={values.categories}
                                    label={"Categories"}
                                    options={category} />

                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Product Image:</h1>
                                <Controls.Image setFile={setFile} aspectRatio={471 / 430} />

                            </div>
                        </Grid>
                        <Grid item xs={2}>
                            <div className="form-group">
                                <Controls.Button
                                    text={"Submit"}
                                    onClick={handleSubmit} />

                            </div>
                        </Grid>
                    </Grid>
                    {ErrorMessege === null ?
                        null :
                        <div className="bg-danger p-3 text-white rounded validate-message">
                            <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessege} </strong>
                        </div>
                    }
                    {SuccessMessege === null ?
                        null :
                        <div className="bg-success p-3 text-white rounded validate-message">
                            <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessege} </strong>
                        </div>
                    }
                </Box>
            </Box>
        </>
    )
}

export default ProductAdd;