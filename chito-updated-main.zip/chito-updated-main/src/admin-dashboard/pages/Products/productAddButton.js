import React from "react";
import Controls from "../../../components/forms/controls/Controls";

const ProductAddButton = () =>{

    return(
        <>
            <Controls.Button
             text={"Add Products"}/>

        </>
    )
}

export default ProductAddButton;
