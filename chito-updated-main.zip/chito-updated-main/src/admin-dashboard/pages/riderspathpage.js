import axios from 'axios';
import React,{useState,useEffect} from 'react';
import Cookies from 'js-cookie';
import { Link } from 'react-router-dom';
import  { MultiSelect } from "react-multi-select-component";

const Rider_Pathpage = ()=>{
    const [changePath,setchangePath] = useState([]);
    const [inputList, setInputList] = useState([{}]);
    const [PathCode,setPathCode] = useState([]);
    const [Path,setPath] = useState([]);
    const [Driver,setDriver] = useState([]);
    const [RiderChange,setRiderChange]=useState([]);
    const [DriverId,setdriverId] = useState([]);
    const [PathId,setPathId]=useState([]);
 
    var DriverArray = []
    for(var i=0;i<Driver.length;i++)
    {
        DriverArray.push({'label':Driver[i],'value':Driver[i]})
    }


    const handleInputChange = (e, index) => {
        const { name, value } = e.target;
        const list = [...inputList];
        list[index][name] = value;
        setInputList(list);
      };
     
      // handle click event of the Remove button
      const handleRemoveClick = index => {
        const list = [...inputList];
        list.splice(index, 1);
        setInputList(list);
      };
      // handle click event of the Add button
      const handleAddClick = () => {
        setInputList([...inputList, { place: "",}]);
      };
      const onchangePath = (e)=> setchangePath(e.target.value);
      const onPathCode =(e)=>setPathCode(e.target.value);
      const onRiderChange = (e)=>setdriverId(e.target.value);

      useEffect(()=>{
          axios.get(`https://api.mahaboudhawholesale.com/path/pathinfo/`)
          .then((res)=>{
              setPath(res.data)
          })
      },[])

      useEffect(()=>{
          axios.get(`https://api.mahaboudhawholesale.com/user/rider-information/`)
          .then((res)=>{
              var arr = []
                for(var i=0;i<res.data.length;i++)
                {
             
                    arr.push(res.data[i].driver_id.first_name + " "+res.data[i].driver_id.last_name+" "+res.data[i].driver_id.contactno)
                }
                setDriver(arr);
          })

      },[])
      function onDriverId(a,b){
          setPathId(b);
          a.preventDefault();
     
          axios.get(`https://api.mahaboudhawholesale.com/path/pathdriver/?route_code=${b}`)
          .then((res)=>{
           
              if((res.data.length==1 && res.data[0]['route_driver']=="1") || res.data.length==0)
              {
               
                  setRiderChange([{'label':" ",'value':" "}])
              
              }
              else{
                  var array =[]
                  for(var i=0;i<res.data.length;i++)
                  {
                  axios.get(`https://api.mahaboudhawholesale.com/user/rider-information/?driver_id=${res.data[i].route_driver}`)
                  .then((res)=>{
                  
                      array.push({'label':res.data[0].driver_id.first_name+" "+res.data[0].driver_id.last_name+" "+res.data[0].driver_id.contactno,'value':res.data[0].driver_id.first_name+" "+res.data[0].driver_id.last_name+" "+res.data[0].driver_id.contactno})
                      setRiderChange(array);
                  })

                  }
            
                  
              }
          
  
              
          })
      }

      function createPath(path,input,e)
      {
          e.preventDefault();
       
            axios.post(`https://api.mahaboudhawholesale.com/path/pathinfo/`,{'path_name':path,'route_code':PathCode},{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
            .then((res)=>{
               
           

                for(var i=0;i<input.length;i++)
                {
                    axios.post(`https://api.mahaboudhawholesale.com/path/pathplace/`,{'route_code':res.data.id,'route_place':input[i]['place']},{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                    .then((res)=>{
                    
                    })
                }
            })
          
      }
      function saveDriver(a,b)
      {
        
          a.preventDefault();
        
          axios.get(`https://api.mahaboudhawholesale.com/path/pathdriver/?route_code=${PathId}`)
          .then((res)=>{
              for(var i=0;i<res.data.length;i++)
              {
                  axios.delete(`https://api.mahaboudhawholesale.com/path/pathdriver/${res.data[i].id}/`,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                  .then((res)=>{
                     
                  })
              }
          })
          if(b.length==0)
          {
              window.alert("Please select your driver")
          }
          else{
              for(var i=0;i<b.length;i++)
              {
                
              var c =b[i]['label'].split(" ")
         
              axios.get(`https://api.mahaboudhawholesale.com/user/user/?first_name=${c[0]}&last_name=${c[1]}&contactno=${c[2]}`)
              .then((res)=>{
                 
                  if(res.data.length==0)
                  {
                   
                  }
                  else{
                  axios.post(`https://api.mahaboudhawholesale.com/path/pathdriver/`,{'route_code':PathId,'route_driver':res.data[0]['id']},{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                  .then((res)=>{
                     
                  })
                }
          
              })
            }
          }
      }
    return(
        <div className="p-3 pt-4">
            <div className="bg-white p-3 pt-4 rounded">
                <form>
                    <div className="row m-0">
                        <div className="col p-0">
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Path Name:</h1>
                                <input type="text" className="form-control1" onChange={onchangePath} placeholder=" Enter Path Name :" />
                            </div>
                        </div>
                        <div className="col p-0 ms-4">
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Path Code:</h1>
                                <input type="text" className="form-control1" onChange={onPathCode} placeholder=" Enter path code :" />
                            </div>
                        </div>
                    </div>
                    {inputList.map((x, i) => {
                    return (
                        <div className="row m-0 mt-4">
                            <div className="col p-0 me-4">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark form-text text-dark">Place {i+1}:</h1>
                                <input type="text" className="form-control1" name="place" defaultValue={x.place} placeholder="Enter Place" onChange={e => handleInputChange(e, i)} />
                            </div>
                            <div className="col p-0"></div>
                            <div className="btn-box text-start mt-4">
                                {inputList.length !== 1 && <button
                                    className="btn btn-danger btn-sm me-2"
                                    onClick={() => handleRemoveClick(i)}>Remove Place</button>}
                                {inputList.length - 1 === i && <button className="btn back-color btn-sm text-white" onClick={handleAddClick}><i className="fa fa-plus me-2"></i>Add Place</button>}
                            </div>
                        </div>
                        );
                    })}
                    <div className="text-start mt-4">
                        <button onClick={(e)=>createPath(changePath,inputList,e)} className="btn btn-info text-white px-3">Create Path</button>
                    </div>
                </form>
            </div>
            <div className="tab-pane fade show active bg-white px-3" id="pending" role="tabpanel" aria-labelledby="Pending_tab">
                        <table className="table border-0 mt-5 text-start">
                    <thead className='border-bottom'>
                        <tr className="bg-white">
                            <th scope="col " className="fs-14">Route Code</th>
                            <th scope="col " className="fs-14">Route Name</th>
                            <th scope="col" className="fs-14">Details</th>
                            <th scope="col" className="fs-14">Assign Rider</th>
                        </tr>
                    </thead>
                    <tbody>
                    {Path.map((key)=>(
                        
                        <tr className="data-information">
              
                        <td className="fs-12"><i className='fa fa-circle me-2 text-color'></i>{key.route_code}</td>
                        <td className="fs-12">{key.path_name}</td>
                      
                        <td className="fs-12">
                            <Link className="text-decoration-none header-background text-white ms-2 px-2 py-1 rounded me-2" to={`/my/path/update/${key.route_code}`} ><i className="fa fa-edit text-white"></i></Link>
                            <Link className="text-decoration-none back-color text-white ms-2 px-2 py-1 rounded me-2"  to="#"><i className="fa fa-eye text-white"></i></Link>
                        </td>

                        <td className="fs-12 ms-5 ps-4" onClick={(e)=>onDriverId(e,key.id)}><i className="fa fa-motorcycle fs-5 text-dark" type="button" data-bs-toggle="modal" data-bs-target="#RiderModal"></i></td>
                        
                    
                   
                    </tr>
                     ))}
                        <div className="modal fade" id="RiderModal" tabindex="-1" aria-labelledby="RiderModalLabel" aria-hidden="true">
                            <div className="modal-dialog">
                                <div className="modal-content">
                                    <div className="modal-body text-start">
                                        <div className="text-end">
                                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div className="col-11 m-auto p-3 py-4">
                                            <form>
                                                <div className="form-group">
                                                    <p>Selected Driver:{DriverId}</p>
                                               
                                                    <MultiSelect
                    options={DriverArray}
            value={RiderChange}
        onChange={setRiderChange}
        labelledBy="Select"
      />
                                                </div>
                                                <div className="mt-3">
                                                    <button className="btn btn-success btn-sm px-4" onClick={(e)=>{saveDriver(e,RiderChange)}}>Save</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </tbody>
            </table>
                    </div>
        </div>
        
    )
}
export default Rider_Pathpage;