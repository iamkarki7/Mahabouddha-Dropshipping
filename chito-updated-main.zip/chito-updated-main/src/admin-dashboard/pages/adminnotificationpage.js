import React from 'react';

const Adminnotification_page = ()=>{
    return(
        <div className="p-4">
        <div className="bg-white p-4 ">
            <div>
                <h1 className="text-dark fs-5 fw-bold text-start pb-3 border-bottom">All Notifications</h1>
            </div>
            <div className="px-3 py-2 pt-3 notification-hover">
                <div className="row m-0">
                    <div className="col p-0">
                        <div className="row m-0">
                            <div className="col-3 p-0 text-start">
                                <span className="back-color px-2 fs-13 py-1 text-white fw-bolder rounded">Approved Order</span>
                            </div>
                            <div className="col p-0">
                                <p>Your Order Has Been Approved by the Admin</p>
                            </div>
                        </div>
                    </div>
                    <div className="col p-0 text-end">
                        <p className="fs-13 notification-text">3 Weeks ago</p>
                    </div>
                </div>
            </div>
            <div className="px-3 py-2 pt-3 notification-hover">
                <div className="row m-0">
                    <div className="col p-0">
                        <div className="row m-0">
                            <div className="col-3 p-0 text-start">
                                <span className="back-color px-2 fs-13 py-1 text-white fw-bolder rounded">Approved Order</span>
                            </div>
                            <div className="col p-0">
                                <p>Your Order Has Been Approved by the Admin</p>
                            </div>
                        </div>
                    </div>
                    <div className="col p-0 text-end">
                        <p className="fs-13 notification-text">3 Weeks ago</p>
                    </div>
                </div>
            </div>
            <div className="px-3 py-2 pt-3 notification-hover">
                <div className="row m-0">
                    <div className="col p-0">
                        <div className="row m-0">
                            <div className="col-3 p-0 text-start">
                                <span className="back-color px-2 fs-13 py-1 text-white fw-bolder rounded">Approved Order</span>
                            </div>
                            <div className="col p-0">
                                <p>Your Order Has Been Approved by the Admin</p>
                            </div>
                        </div>
                    </div>
                    <div className="col p-0 text-end">
                        <p className="fs-13 notification-text">3 Weeks ago</p>
                    </div>
                </div>
            </div>
            <div className="px-3 py-2 pt-3 notification-hover">
                <div className="row m-0">
                    <div className="col p-0">
                        <div className="row m-0">
                            <div className="col-3 p-0 text-start">
                                <span className="back-color px-2 fs-13 py-1 text-white fw-bolder rounded">Approved Order</span>
                            </div>
                            <div className="col p-0">
                                <p>Your Order Has Been Approved by the Admin</p>
                            </div>
                        </div>
                    </div>
                    <div className="col p-0 text-end">
                        <p className="fs-13  notification-text">3 Weeks ago</p>
                    </div>
                </div>
            </div>
            <div className="px-3 py-2 pt-3 notification-hover">
                <div className="row m-0">
                    <div className="col p-0">
                        <div className="row m-0">
                            <div className="col-3 p-0 text-start">
                                <span className="back-color px-2 fs-13 py-1 text-white fw-bolder rounded">Approved Order</span>
                            </div>
                            <div className="col p-0">
                                <p>Your Order Has Been Approved by the Admin</p>
                            </div>
                        </div>
                    </div>
                    <div className="col p-0 text-end">
                        <p className="fs-13 notification-text">3 Weeks ago</p>
                    </div>
                </div>
            </div>
            <div className="px-3 py-2 pt-3 notification-hover">
                <div className="row m-0">
                    <div className="col p-0">
                        <div className="row m-0">
                            <div className="col-3 p-0 text-start">
                                <span className="back-color px-2 fs-13 py-1 text-white fw-bolder rounded">Approved Order</span>
                            </div>
                            <div className="col p-0">
                                <p>Your Order Has Been Approved by the Admin</p>
                            </div>
                        </div>
                    </div>
                    <div className="col p-0 text-end">
                        <p className="fs-13 notification-text">3 Weeks ago</p>
                    </div>
                </div>
            </div>
            <div className="px-3 py-2 pt-3 notification-hover">
                <div className="row m-0">
                    <div className="col p-0">
                        <div className="row m-0">
                            <div className="col-3 p-0 text-start">
                                <span className="bg-success px-2 fs-13 py-1 text-white fw-bolder rounded">Delivered</span>
                            </div>
                            <div className="col p-0">
                                <p>Your Order Has Been Approved by the Admin</p>
                            </div>
                        </div>
                    </div>
                    <div className="col p-0 text-end">
                        <p className="fs-13 notification-text">3 Weeks ago</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    )
}
export default Adminnotification_page;