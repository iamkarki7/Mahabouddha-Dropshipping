import React, { useState, useEffect } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Box, Grid, Typography } from "@mui/material";
import Admin_sidebar from "../../component/sidebar";
import Admin_header from "../../component/header";
import Controls from "../../../components/forms/controls/Controls";
import { useForm1, Form } from "../../../components/forms/useForm";

import {
  useGetLocationsQuery,
  useGetLocationByIdQuery,
  useAddLocationMutation,
  useDeleteLocationMutation,
  useUpdateLocationMutation
} from "../../../services/slices/LocationSlice/locationSlice";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import {
//   faCog,
//   faBell,
//   faSignInAlt,
//   faExclamationTriangle,
//   faCheckCircle,
// } from "@fortawesome/free-solid-svg-icons";
import { faCheckCircle, faExclamationTriangle } from "@fortawesome/free-solid-svg-icons";
import GoogleAutoCompleteComponent from "../../../components/google/googleAutoComplete";

const LocationEditPage = () => {
  return (
    <Grid container className="dashboard-full-background">
      <Grid item xs={1} spacing={4}>
        <Admin_sidebar />
      </Grid>
      <Grid item xs={11}>
        <Admin_header />
        <EditLocationPages />
      </Grid>
    </Grid>
  );
};

const EditLocationPages = () => {
  const { id } = useParams();
  const Locations = useGetLocationByIdQuery(id);
  const [updateBlog, setUpdateBlog] = useState([]);
  const [initialFValues, setInitialFValues] = useState({
    price: '',
    address1: '',
    adminArea1Long: '',
    adminArea1Short: '',
    countryLon: '',
    countryShort: '',
    locality: '',
    postalCode: '',
    address1: '',
    latitude: 0.0,
    longitude: 0.0,
  });
  const [SuccessMessege, setSuccesMessege] = useState(null);
  const [ErrorMessege, setErrorMessege] = useState(null);

  useEffect(() => {
    if (Locations.data) {
      setInitialFValues({
        price: Locations.data.price,
        address1: Locations.data.address1,
        adminArea1Long: Locations.data.adminArea1Long,
        adminArea1Short: Locations.data.adminArea1Short,
        countryLon: Locations.data.countryLon,
        countryShort: Locations.data.countryShort,
        locality: Locations.data.locality,
        postalCode: Locations.data.postalCode,
        address1: Locations.data.address1,
        latitude: Locations.data.latitude,
        longitude: Locations.data.longitude,
      });
    }
  }, [Locations.data]);

  const { values, handleInputChange, handleChangeGoogle } = useForm1(
    initialFValues,
    true,
    false,
    true
  );

  const [editLocation] = useUpdateLocationMutation();

  const history = useHistory();


  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData();
    if (values.price)
      formData.append("price", values.price);
    if (values.address1)
      formData.append("address1", values.address1);
    if (values.adminArea1Long)
      formData.append("adminArea1Long", values.adminArea1Long);
    if (values.adminArea1Short)
      formData.append("adminArea1Short", values.adminArea1Short);
    if (values.countryLon)
      formData.append("countryLon", values.countryLon);
    if (values.countryShort)
      formData.append("countryShort", values.countryShort);
    if (values.locality)
      formData.append("locality", values.locality);
    if (values.postalCode)
      formData.append("postalCode", values.postalCode);
    if (values.address1)
      formData.append("address1", values.address1);
    if (values.latitude)
      formData.append("latitude", values.latitude);
    if (values.longitude)
      formData.append("longitude", values.longitude);
    formData.append("id", id);
    editLocation(formData)
      .then((res) => {
        if (res.data) {
          setSuccesMessege('Location successfully updated.')
          setTimeout(() => {
            history.push('/admin/location-price')
          }, [3000])
        } else {
          if (res.error) {
            setErrorMessege(res.error.data.err ? res.error.data.err : res.error.data)
            setTimeout(() => {
              setErrorMessege(null)
            }, [3000])
          } else {
            setErrorMessege('Problem while update data.')
            setTimeout(() => {
              setErrorMessege(null)
            }, [3000])
          }
        }
      })
      .catch((err) => {
        setErrorMessege('Some error occur while updating data.')
        setTimeout(() => {
          setErrorMessege(null)
        }, [3000])
      })
  };

  return (
    <Box className="table-design-background">
      <Typography className="dashboard-home-page-text" style={{ marginLeft: '20px' }}>
        Update Location Price
      </Typography>
      <Box style={{ padding: "1.5rem" }}>
        <Form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={6}>
              <Controls.Input
                name="price"
                label="Price"
                value={values.price}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item xs={6}>
              <GoogleAutoCompleteComponent
                valueList={['address1', 'adminArea1Long', 'adminArea1Short', 'countryLon', 'countryShort', 'locality',
                  'postalCode', 'latitude', 'longitude']}
                value={values.address1}
                onChange={handleChangeGoogle} />
            </Grid>
            <Grid item xs={2} style={{ marginTop: "0px" }}>
              <Controls.Button
                type="submit"
                text="Submit"
                backgroundColor="#1b284b"
                onClick={handleSubmit}
              />
            </Grid>
          </Grid>
        </Form>
        {ErrorMessege === null ?
          null :
          <div className="bg-danger p-3 text-white rounded validate-message">
            <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessege} </strong>
          </div>
        }
        {SuccessMessege === null ?
          null :
          <div className="bg-success p-3 text-white rounded validate-message">
            <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessege} </strong>
          </div>
        }
      </Box>
    </Box>
  );
};

export default LocationEditPage;
