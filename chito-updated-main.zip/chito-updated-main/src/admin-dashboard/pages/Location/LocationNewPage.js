import React, { useState } from 'react'

import Admin_sidebar from '../../component/sidebar'
import Admin_header from '../../component/header'

import Controls from '../../../components/forms/controls/Controls'
import { useForm1 } from '../../../components/forms/useForm'
import GoogleAutoCompleteComponent from '../../../components/google/googleAutoComplete'
import axios from 'axios'
import { BASE_URL } from '../../../constants/baseURL'
import { AUTHORIZATION_JSON } from '../../../constants/baseURL'
import { Grid, Typography } from '@mui/material';
import { useHistory } from 'react-router-dom';


const LocationPricePage = () => {
    return (
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar />
            </div>
            <div className="col p-0">
                <Admin_header />
                <LocationPrice />
            </div>
        </div>
    )
}

const LocationPrice = () => {
    const [initialFValues, setInitialFValues] = useState({
        price: '',
        address1: '',
        adminArea1Long: '',
        adminArea1Short: '',
        countryLon: '',
        countryShort: '',
        locality: '',
        postalCode: '',
        address1: '',
        latitude: 0.0,
        longitude: 0.0,
    });

    const { values, handleImageUpload, handleInputChange, handleChangeGoogle } = useForm1(
        initialFValues,
        true,
        false,
        false
    );
    const history = useHistory()
    const [SuccessMessege, setSuccesMessege] = useState(null);
    const [ErrorMessege, setErrorMessege] = useState(null);


    const handleSubmit = (e) => {
        axios.post(`${BASE_URL}/path/location-price/`, values, AUTHORIZATION_JSON)
            .then((res) => {
                if (res.data) {
                    setSuccesMessege('Location successfully added.')
                    setTimeout(() => {
                        history.push('/admin/location-price')
                    }, [3000])
                } else {
                    if (res.error) {
                        setErrorMessege(res.error.data.err ? res.error.data.err : res.error.data)
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    } else {
                        setErrorMessege('Problem while adding data.')
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    }
                }
            })
            .catch((err) => {
                setErrorMessege('Some error occur while adding data.')
                setTimeout(() => {
                    setErrorMessege(null)
                }, [3000])
            })
    }


    return (
        <>
            <div className="table-design-background" style={{ padding: "1rem" }}>
                <Typography className="dashboard-home-page-text">
                    Add Location Price
                </Typography>
                <div style={{ marginTop: '1rem' }}>
                    <Grid container spacing={3}>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Location:</h1>
                                <GoogleAutoCompleteComponent
                                    valueList={['address1', 'adminArea1Long', 'adminArea1Short', 'countryLon', 'countryShort', 'locality',
                                        'postalCode', 'latitude', 'longitude']}
                                    value={values.address1}
                                    onChange={handleChangeGoogle} />
                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Price:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="price"
                                    value={values.price} />

                            </div>
                        </Grid>
                        <Grid item xs={2}>
                            <div className="form-group">
                                <Controls.Button
                                    text={"Submit"}
                                    onClick={handleSubmit} />

                            </div>
                        </Grid>
                    </Grid>
                    {ErrorMessege === null ?
                        null :
                        <div className="bg-danger p-3 text-white rounded validate-message">
                            <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessege} </strong>
                        </div>
                    }
                    {SuccessMessege === null ?
                        null :
                        <div className="bg-success p-3 text-white rounded validate-message">
                            <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessege} </strong>
                        </div>
                    }
                </div>
            </div>
        </>
    )
}

export default LocationPricePage