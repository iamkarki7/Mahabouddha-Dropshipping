import React from "react";
import Controls from "../../../components/forms/controls/Controls";

const LocationAddButton = () =>{

    return(
        <>
            <Controls.Button
             text={"Add Location"}/>

        </>
    )
}

export default LocationAddButton;
