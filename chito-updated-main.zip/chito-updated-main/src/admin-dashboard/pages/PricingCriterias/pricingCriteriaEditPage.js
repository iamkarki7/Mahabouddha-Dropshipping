import React, { useState, useEffect } from 'react'
import { useHistory, useParams } from 'react-router-dom'
import Admin_sidebar from '../../component/sidebar'
import Admin_header from '../../component/header'

import Controls from '../../../components/forms/controls/Controls'
import { useForm1 } from '../../../components/forms/useForm'
import {
    useAddPricingCriteriaMutation,
    useGetPricingCriteriaByIdQuery,
    useGetPricingCriteriasQuery,
    useUpdatePricingCriteriaMutation
} from '../../../services/slices/PricingCriteria/pricingCriteriaSlice'
import { Grid, Typography } from '@mui/material'


const PricingCriteriaEdit = () => {
    return (
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar />
            </div>
            <div className="col p-0">
                <Admin_header />
                <PricingCriteriaEditPage />
            </div>
        </div>
    )
}

const PricingCriteriaEditPage = () => {
    const { id } = useParams();
    const PricingCriteria = useGetPricingCriteriaByIdQuery(id);
    const [initialFValues, setInitialFValues] = useState({
        price_start: '',
        price_end: '',
        service_price: '',
        package_price: ''
    });

    useEffect(() => {
        if (PricingCriteria.data) {
            setInitialFValues({
                price_start: PricingCriteria.data.price_start,
                price_end: PricingCriteria.data.price_end,
                service_price: PricingCriteria.data.service_price,
                package_price: PricingCriteria.data.package_price
            });
        }
    }, [PricingCriteria.data]);

    const { values, handleImageUpload, handleInputChange, handleChangeGoogle } = useForm1(
        initialFValues,
        true,
        false,
        true
    );
    const history = useHistory();
    const [SuccessMessege, setSuccesMessege] = useState(null);
    const [ErrorMessege, setErrorMessege] = useState(null);

    const [updatePricingCriteria] = useUpdatePricingCriteriaMutation();;

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        if (values.price_start) {
            formData.append("price_start", values.price_start);
        }
        if (values.price_end) {
            formData.append("price_end", values.price_end);
        }
        if (values.service_price) {
            formData.append("service_price", values.service_price);
        }
        if (values.package_price) {
            formData.append("package_price", values.package_price);
        }
        formData.append("id", id);
        updatePricingCriteria(formData)
            .then((res) => {
                if (res.data) {
                    setSuccesMessege('Pricing criteria successfully updated.')
                    setTimeout(() => {
                        history.push('/admin/pricing-criterias')
                    }, [3000])
                } else {
                    if (res.error) {
                        setErrorMessege(res.error.data.err ? res.error.data.err : res.error.data)
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    } else {
                        setErrorMessege('Problem while updated data.')
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    }
                }
            })
            .catch((err) => {
                setErrorMessege('Some error occur while updated data.')
                setTimeout(() => {
                    setErrorMessege(null)
                }, [3000])
            })
    };

    return (
        <>
            <div className="table-design-background" style={{ padding: "1rem" }}>
                <Typography className="dashboard-home-page-text">
                    Update Price Criteria
                </Typography>
                <div style={{ marginTop: '1rem' }}>
                    <Grid container spacing={3}>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Pricing Start Range:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="price_start"
                                    value={values.price_start} />

                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Pricing End Range:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="price_end"
                                    value={values.price_end} />

                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Service Price:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="service_price"
                                    value={values.service_price} />

                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Package Price:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="package_price"
                                    value={values.package_price} />

                            </div>
                        </Grid>
                        <Grid item xs={2}>
                            <div className="form-group">
                                <Controls.Button
                                    text={"Submit"}
                                    onClick={handleSubmit} />

                            </div>
                        </Grid>
                    </Grid>
                </div>
                {ErrorMessege === null ?
                    null :
                    <div className="bg-danger p-3 text-white rounded validate-message">
                        <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessege} </strong>
                    </div>
                }
                {SuccessMessege === null ?
                    null :
                    <div className="bg-success p-3 text-white rounded validate-message">
                        <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessege} </strong>
                    </div>
                }
            </div>
        </>
    )
}

export default PricingCriteriaEdit;