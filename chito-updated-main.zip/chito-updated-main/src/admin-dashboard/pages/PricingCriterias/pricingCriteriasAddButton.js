import React from "react";
import Controls from "../../../components/forms/controls/Controls";

const PricingCriteriaAddButton = () =>{

    return(
        <>
            <Controls.Button
             text={"Add Pricing Criteria"}/>

        </>
    )
}

export default PricingCriteriaAddButton;
