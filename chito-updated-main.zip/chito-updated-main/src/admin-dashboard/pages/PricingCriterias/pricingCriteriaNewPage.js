import React, { useState } from 'react'

import Admin_sidebar from '../../component/sidebar'
import Admin_header from '../../component/header'

import Controls from '../../../components/forms/controls/Controls'
import { useForm1 } from '../../../components/forms/useForm'
import { useAddPricingCriteriaMutation } from '../../../services/slices/PricingCriteria/pricingCriteriaSlice'
import { Grid, Typography } from '@mui/material'
import { useHistory } from 'react-router-dom'


const PricingCriteriaAdd = () => {
    return (
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar />
            </div>
            <div className="col p-0">
                <Admin_header />
                <PricingCriteriaAddPage />
            </div>
        </div>
    )
}

const PricingCriteriaAddPage = () => {
    const [initialFValues, setInitialFValues] = useState({
        price_start: '',
        price_end: '',
        service_price: '',
        package_price: ''
    });

    const { values, handleImageUpload, handleInputChange, handleChangeGoogle } = useForm1(
        initialFValues,
        true,
        false,
        false
    );
    const [SuccessMessege, setSuccesMessege] = useState(null);
    const [ErrorMessege, setErrorMessege] = useState(null);

    const history = useHistory();

    const [addPricingCriteria] = useAddPricingCriteriaMutation();

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append("price_start", values.price_start);
        formData.append("price_end", values.price_end);
        formData.append("service_price", values.service_price);
        formData.append("package_price", values.package_price)
        addPricingCriteria(formData)
            .then((res) => {
                if (res.data) {
                    setSuccesMessege('Pricing criteria successfully added.')
                    setTimeout(() => {
                        history.push('/admin/pricing-criterias')
                    }, [3000])
                } else {
                    if (res.error) {
                        setErrorMessege(res.error.data.err ? res.error.data.err : res.error.data)
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    } else {
                        setErrorMessege('Problem while adding data.')
                        setTimeout(() => {
                            setErrorMessege(null)
                        }, [3000])
                    }
                }
            })
            .catch((err) => {
                setErrorMessege('Some error occur while adding data.')
                setTimeout(() => {
                    setErrorMessege(null)
                }, [3000])
            })
    };


    return (
        <>
            <div className="table-design-background" style={{ padding: "1rem" }}>
                <Typography className="dashboard-home-page-text">
                    Add Price Criteria
                </Typography>
                <div style={{ marginTop: '1rem' }}>
                    <Grid container spacing={3}>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Pricing Start Range:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="price_start"
                                    value={values.price_start} />

                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Pricing End Range:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="price_end"
                                    value={values.price_end} />

                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Service Price:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="service_price"
                                    value={values.service_price} />

                            </div>
                        </Grid>
                        <Grid item xs={6}>
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Package Price:</h1>
                                <Controls.Input
                                    onChange={handleInputChange}
                                    name="package_price"
                                    value={values.package_price} />

                            </div>
                        </Grid>
                        <Grid item xs={2}>
                            <div className="form-group">
                                <Controls.Button
                                    text={"Submit"}
                                    onClick={handleSubmit} />

                            </div>
                        </Grid>
                    </Grid>
                </div>
                {ErrorMessege === null ?
                    null :
                    <div className="bg-danger p-3 text-white rounded validate-message">
                        <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessege} </strong>
                    </div>
                }
                {SuccessMessege === null ?
                    null :
                    <div className="bg-success p-3 text-white rounded validate-message">
                        <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessege} </strong>
                    </div>
                }
            </div>
        </>
    )
}

export default PricingCriteriaAdd;