import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Admin_sidebar from "../../component/sidebar";
import Admin_header from "../../component/header";
import { Grid, Typography } from "@mui/material";
import BasicTable from "../../../components/tables/BasicTable";
import {
  useDeletePricingCriteriaMutation,
  useGetPricingCriteriasPaginationQuery
} from "../../../services/slices/PricingCriteria/pricingCriteriaSlice";
import PricingCriteriaAddButton from "./pricingCriteriasAddButton";
import { Box } from "@mui/material";
import { getPaginationPagesCount } from "../../../components/forms/utils/getPaginationPagesCount";

const DashboardPricingCriteria = () => {
  return (
    <Grid container className="dashboard-full-background">
      <Grid item xs={1} spacing={4}>
        <Admin_sidebar />
      </Grid>
      <Grid item xs={11}>
        <Admin_header />
        <DashboardPricingCriteriaPages />
      </Grid>
    </Grid>
  );
};

const DashboardPricingCriteriaPages = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [headers, setHeaders] = useState([]);
  const [tableData, setTableData] = useState([]);
  const { data, isLoading, isSuccess, isError, error } =
    useGetPricingCriteriasPaginationQuery(currentPage);

  const [deleteBlog] = useDeletePricingCriteriaMutation();

  const deleteConfirm = (e, id) => {
    e.preventDefault();

    deleteBlog({ id });
  };


  let content;
  useEffect(() => {
    if (isLoading) {
      content = <p>"Loading..."</p>;
    } else if (isSuccess) {
      setHeaders(["Price Start", "Price End", "Service Charge", "Package Price"]);
      let tableDatas = [];
      data?.results?.forEach((key) => {
        tableDatas.push({
          "Price Start": key.price_start,
          "Price End": key.price_end,
          "Service Charge": key.service_price,
          "Package Price": key.package_price,
          id: key.id,
        });
      });
      setTableData(tableDatas);
      setTotalPages(getPaginationPagesCount(data.count, 10));
    }
  }, [isLoading, isSuccess, data])
  return (
    <>
      <Box className="table-design-background">
        <Grid container>
          <Grid item xs={10}>
            <Typography className="dashboard-home-page-text" style={{ marginLeft: '20px' }}>
              Service Charges
            </Typography>
          </Grid>
          <Grid item xs={2}>
            <Box style={{ padding: '10px', textAlign: 'right', marginRight: '15px' }}>
              <Link to="/admin/new/pricing-criterias" style={{ textDecoration: 'none' }}>
                <PricingCriteriaAddButton />
              </Link>
            </Box>
          </Grid>
        </Grid>
        <Box style={{ padding: "1.5rem" }}>
          <BasicTable
            headers={headers}
            data={tableData}
            isDelete={true}
            deleteColor={"#f50057"}
            isEdit={true}
            editColor={"#3f51b5"}
            addColor={""}
            tableName={"pricing-criterias"}
            deleteConfirm={deleteConfirm}
            setCurrentPage={setCurrentPage}
            setTotalPages={setTotalPages}
            totalPages={totalPages}
          />
        </Box>
      </Box>
    </>
  );
};
export default DashboardPricingCriteria;

