import React,{useState} from 'react';
import state from '../../functions/state';
import district from '../../functions/districts';
import axios from 'axios';
import Cookies from 'js-cookie';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
const Rider_informationpage = ()=>{
    const [Addremove, setAddremove] = useState(false);
    
    
    const [SelectState,setSelectstate] = useState();
    const [FirstName, setFirstName] = useState();
    const [LastName, setLastName] = useState();
    const [Email,setEmail] = useState();
    const [RiderStreet, setRiderStreet] = useState();  
    const [Contact, setContact] = useState();  
    const [Password, setPassword] = useState();  
    const [File,setFile] = useState([]);  
    const [Photo,setPhoto] = useState([]);
    const [District,setDistrict] = useState([]);
    const [Rider , setRider] = useState([]);
    var updatedDropState = district[SelectState];
    const onState = e =>setSelectstate(e.target.value);
    const onFirstName = e =>setFirstName(e.target.value);
    const onLastName = e =>setLastName(e.target.value);
    const onEmail = e =>{setEmail(e.target.value)};
    const onRiderStreet = e => {setRiderStreet(e.target.value)};
    const onContact = e => {setContact(e.target.value)};
    const onPassword =e =>{setPassword(e.target.value)};
    const onFile = e => {setFile(e.target.files[0])}; 
    const onPhoto = e => {setPhoto(e.target.files[0])};
    const onDistrict = e => {setDistrict(e.target.value)};
    var  driver_form = new FormData();

    const onSave = (e) =>{
        e.preventDefault();
        axios.post(`https://api.mahaboudhawholesale.com/user/register/`,{'email':Email,'first_name':FirstName,'last_name':LastName,'password':Password,'contactno':Contact,'is_driver':true})
        .then((res)=>{
        
            driver_form.append('rider_state',SelectState);
            driver_form.append('rider_district',District);
            driver_form.append('rider_street',RiderStreet);
            driver_form.append('field_name',File);
            driver_form.append('profile_picture',Photo);
            driver_form.append('driver_id',res.data.id)
            axios({
                method: "post",
                url: `https://api.mahaboudhawholesale.com/user/rider-information/`,
                data: driver_form,
                headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'multipart/form-data' },
              })
            .then((res)=>{
            
            })
        })  

    }
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/rider-information/`)
        .then((res)=>{
            setRider(res.data);
            
        })
    },[])

    const Rider_click = (e)=>{
        e.preventDefault();

        const Data = {}
    }
 
    return(
        <div className="px-3">
            <div className="row m-0 mt-4">
                <div className="col p-0">
                    <h1 className="fs-5 fw-bolder text-start">Rider Information</h1>
                </div>
                <div className="col p-0 text-end">
                    <button className="btn btn-info px-3 text-white" onClick={()=>setAddremove(true)}>Add Rider</button>
                </div>
                <div className="">
                        {Addremove === true &&(
                            <div className="py-1 pb-4">
                                <h1 className="fs-6 fw-bolder pb-4 text-start">Add Rider</h1>
                                <div className="row m-0">
                                    <div className="col p-0">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">First Name</label>
                                        <input type="text" className="form-control1" onChange={onFirstName} placeholder="Enter rider first Name" />
                                    </div>
                                    </div>
                                    <div className="col p-0 ms-3">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Last Name</label>
                                        <input type="text" className="form-control1" onChange={onLastName} placeholder="Enter rider last Name" />
                                    </div>
                                    </div>
                                    <div className="col p-0 ms-3">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Email</label>
                                            <input type="text" className="form-control1" onChange={onEmail} placeholder="Enter Rider Email" />
                                        </div>
                                    </div>
                                </div>
                                <div className="row m-0 mt-4">
                                    <div className="col p-0 text-end">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Drop State</label>
                                            <select className="form-control1" onChange={onState}>
                                                {
                                                    state.map(statedata=>(
                                                        <option>{statedata}</option>
                                                    ))
                                                }
                                            </select>
                                        </div>
                                    </div>
                                    <div className="col p-0 ms-3">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Drop District</label>
                                            <select className="form-control1" onChange = {onDistrict}>
                                                {
                                                    updatedDropState && updatedDropState.map(dis=>(
                                                        <option>{dis}</option>
                                                    ))
                                                }
                                            </select>
                                        </div>
                                    </div>
                                    <div className="col p-0 ms-3">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Rider Street</label>
                                            <input type="text" className="form-control1" onChange={onRiderStreet} placeholder="Enter Rider street" />
                                        </div>
                                    </div>
                                </div>
                                <div className="row m-0 mt-4">
                                    <div className="col p-0">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Rider Contact</label>
                                            <input type="text" className="form-control1"onChange={onContact}  placeholder="Enter Rider Contact on" />
                                        </div>
                                    </div>
                                    <div className="col p-0 ms-3">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Password</label>
                                            <input type="password" className="form-control1"onChange={onPassword}  placeholder="Enter Rider Password" />
                                        </div>
                                    </div>
                                    <div className="col p-0 ms-3">
                                        <div className="form-group text-start">
                                        <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Liesion </label>
                                            <input onChange={onFile} type="file" className="form-control1" id="customFile" />
                                        </div>
                                    </div>
                                </div>
                                <div className="row m-0 mt-4">
                                    <div className="col p-0 text-start">
                                        <div className="form-group">
                                        <label className="form-check-label form-text text-dark text-start mb-3 text-start" htmlFor="exampleCheck1">Rider Photo</label>
                                            <input onChange={onPhoto} type="file" className="form-control1" id="customFile"/>
                                        </div>
                                    </div>
                                    <div className="col p-0 text-start ms-3">
                                    </div>    
                                    <div className="col p-0 text-start ms-3">
                                    </div> 
                                </div>
                                <div className="d-flex mt-4">
                                    <div className="">
                                        <button className="btn btn-success border-0 " onClick = {onSave}>Save</button>
                                    </div>
                                    <div className="ms-2">
                                        <button className="btn btn-danger border-0" onClick={()=>setAddremove(false)}>Close</button>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
​
            </div>
            <div className="bg-white shadow-sm p-3 mt-2 rounded" style={{overflowX:'auto'}}>
                <div className="">          
                    <table className="table border-0 text-start">
                        <thead className='border-bottom'>
                            <tr>
                                <th>Rider No.</th>
                                <th>Rider Name</th>
                                <th>Rider Mail</th>
                                <th>Rider Contact</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Rider.map((key)=>(
                            <tr>
                                <td>{key.id}</td>
                                <td>{key.driver_id.first_name}{" "}{key.driver_id.last_name}</td>
                                <td>{key.driver_id.email}</td>
                                <td>{key.driver_id.contactno}</td>
                                <td>
                                    <Link className='text-decoration-none back-color text-white ms-2 px-2 py-1 rounded' to={`/rider/update/${key.driver_id.id}`}><i className="fa fa-edit text-white"></i></Link>
                                {/* <   button className="btn btn-primary btn-sm me-2"><i className="fa fa-eye"></i></button> */}
                                </td>
                            </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}
export default Rider_informationpage;