import axios from 'axios';
import React, {useState,useEffect} from 'react';

const Dashboard_page = ()=>{
    const [driver,setDriver] = useState([]);
    const [path, setPath] = useState([]);
    const [users,setUsers] = useState([]);
    const [stats, setStats] = useState({'total_order_number': -1, 'total_order_price': -1, 'pending_order_number': -1, 'pending_order_price': -1,
                                        'approved_order_number': -1, 'approved_order_price': -1, 'hold_order_number': -1, 'hold_order_price': -1,
                                        'checkedin_order_number': -1, 'checkedin_order_price': -1, 'delievered_order_number': -1, 'delievered_order_price': -1,
                                        'cancelled_order_number': -1, 'cancelled_order_price': -1,})
   
    useEffect(()=>{
        axios.post(`https://api.mahaboudhawholesale.com/order/stats/`,{'id': 'admin'})
        .then((res)=>{
            setStats(res.data);
        })
    },[])
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/user/?is_driver=true`)
        .then((res)=>{
            setDriver(res.data.length)
        })
    },[])

    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/path/pathinfo/`)
        .then((res)=>{
            setPath(res.data.length)
        })
    },[])

    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/user/?is_staff=false&&is_driver=false&&is_verified=true`)
        .then((res)=>{
            setUsers(res.data.length)
        })
    },[])
    return(
        <div className="p-3 pt-4">
           <div className="row m-0">
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ">
                    <p className="pb-0 notification-text1">Total Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.total_order_number}</h1>
                </div>
                <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                    <p className="pb-0 notification-text1">Pending Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.pending_order_number}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Approved Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.approved_order_number}</h1>
                </div>
                <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Hold Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.hold_order_number}</h1>
                </div>
            </div>
            <div className="row m-0 mt-3">
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ">
                    <p className="pb-0 notification-text1">Checked In Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.checkedin_order_number}</h1>
                </div>
                <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                    <p className="pb-0 notification-text1">Delievered Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.delievered_order_number}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Cancelled Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.cancelled_order_number}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Order Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.total_order_price}</h1>
                </div>
            </div>

            <div className="row m-0 mt-3">
               <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total pending value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.pending_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Approved Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.approved_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Hold In Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.hold_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Checked In Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.checkedin_order_price}</h1>
                </div>
            </div>
            <div className="row m-0 mt-3">
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Delivered Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.delievered_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Cancelled Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.cancelled_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Path</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{path}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Users</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{users}</h1>
                </div>
                
            </div>
        </div>
    )
}
export default Dashboard_page;