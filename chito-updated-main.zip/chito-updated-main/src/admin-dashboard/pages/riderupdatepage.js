import React,{useState} from 'react';
import state from '../../functions/state';
import district from '../../functions/districts';
import axios from 'axios';
import Cookies from 'js-cookie';
import { useEffect } from 'react';
import { Link,useParams } from 'react-router-dom';
const Rider_updatepage = ()=>{
    const id = useParams();
    var my_id = id['id'];  
    const [SelectState,setSelectstate] = useState();
    const [FirstName, setFirstName] = useState();
    const [LastName, setLastName] = useState();
    const [Email,setEmail] = useState();
    const [RiderStreet, setRiderStreet] = useState();  
    const [Contact, setContact] = useState();  
    const [Password, setPassword] = useState();  
    const [File,setFile] = useState([]);  
    const [Photo,setPhoto] = useState([]);
    const [District,setDistrict] = useState([]);
    const [Rider , setRider] = useState([]);
    const [userId, setUserId] = useState([]);
    const [DriverId,setDriverId] = useState([]);
    var updatedDropState = district[SelectState];
    const onState = e =>{setSelectstate(e.target.value)}
    const onFirstName = e =>{setFirstName(e.target.value)};
    const onLastName = e =>{setLastName(e.target.value)};
    const onEmail = e =>{setEmail(e.target.value)};
    const onRiderStreet = e => {setRiderStreet(e.target.value)};
    const onContact = e => {setContact(e.target.value)};
    const onPassword =e =>{setPassword(e.target.value)};
    const onFile = e => {setFile(e.target.files[0])}; 
    const onPhoto = e => {setPhoto(e.target.files[0])};
    const onDistrict = e => {setDistrict(e.target.value)};
    var  driver_form = new FormData();

    
    
 
    var abspath = "";
    function reltoabs(path)
    {
  
        path = path.split("");
      
        var count = 0;
    for(var i=0;i<path.length;i++)
    {
       

        if(path[i]=="/")
        {
            count=count+1;
        }
        if(count>=3)
        {
            abspath+=path[i]
        }
    }
   return abspath;
}
   
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/rider-information/?driver_id=${my_id}`)
        .then((res)=>{
         
            setRider(res.data[0]);
            setFirstName(res.data[0].driver_id.first_name);
            setLastName(res.data[0].driver_id.last_name);
            setEmail(res.data[0].driver_id.email);
            setRiderStreet(res.data[0].rider_street);
            setContact(res.data[0].driver_id.contactno);
            setSelectstate(res.data[0].rider_state);
            setDistrict(res.data[0].rider_district);
            setFile((res.data[0].field_name));
            setPhoto(res.data[0].profile_picture);
            setUserId(res.data[0].driver_id.id);
            setDriverId(res.data[0].id);
        })

    },[])


    function save (e,a,b){
        e.preventDefault();
        if(typeof(File)=='string' && typeof(Photo)== 'string')
        {
        axios({
            method: "patch",
            url: `https://api.mahaboudhawholesale.com/user/user/${a}/`,
            data: {'email':Email,'first_name':FirstName,'last_name':LastName,'contactno':Contact,'is_driver':true},
            headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json' },
          })
        .then((res)=>{
          
            driver_form.append('rider_state',SelectState);
            driver_form.append('rider_district',District);
            driver_form.append('rider_street',RiderStreet);
           
            driver_form.append('driver_id',res.data.id)
      
            (SelectState," ",District," ",RiderStreet, " ", File, " ",Photo, " ",res.data.id)
            axios({
                method: "patch",
                url: `https://api.mahaboudhawholesale.com/user/rider-information/${b}/`,
                data: driver_form,
                headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/x-www-form-urlencoded' },
              })
            .then((res)=>{
              
            })
        })
    } 
    else if(typeof(File)=='object' && typeof(Photo)=='string') 
    {
        axios({
            method: "patch",
            url: `https://api.mahaboudhawholesale.com/user/user/${a}/`,
            data: {'email':Email,'first_name':FirstName,'last_name':LastName,'contactno':Contact,'is_driver':true},
            headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json' },
          })
        .then((res)=>{
          
            driver_form.append('rider_state',SelectState);
            driver_form.append('rider_district',District);
            driver_form.append('rider_street',RiderStreet);
            driver_form.append('field_name',File);
            driver_form.append('driver_id',res.data.id)
      
            (SelectState," ",District," ",RiderStreet, " ", File, " ",Photo, " ",res.data.id)
            axios({
                method: "patch",
                url: `https://api.mahaboudhawholesale.com/user/rider-information/${b}/`,
                data: driver_form,
                headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/x-www-form-urlencoded' },
              })
            .then((res)=>{
             
            })
        })   
    }
    else if(typeof(File)=='string' && typeof(Photo)=='object')
    {
        axios({
            method: "patch",
            url: `https://api.mahaboudhawholesale.com/user/user/${a}/`,
            data: {'email':Email,'first_name':FirstName,'last_name':LastName,'contactno':Contact,'is_driver':true},
            headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json' },
          })
        .then((res)=>{
        
            driver_form.append('rider_state',SelectState);
            driver_form.append('rider_district',District);
            driver_form.append('rider_street',RiderStreet);
            driver_form.append('profile_picture',Photo);
            driver_form.append('driver_id',res.data.id)
      
            (SelectState," ",District," ",RiderStreet, " ", File, " ",Photo, " ",res.data.id)
            axios({
                method: "patch",
                url: `https://api.mahaboudhawholesale.com/user/rider-information/${b}/`,
                data: driver_form,
                headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/x-www-form-urlencoded' },
              })
            .then((res)=>{
              
            })
        })

    }
    else if(typeof(File)=='object' && typeof(Photo)=='object')
    {
        axios({
            method: "patch",
            url: `https://api.mahaboudhawholesale.com/user/user/${a}/`,
            data: {'email':Email,'first_name':FirstName,'last_name':LastName,'contactno':Contact,'is_driver':true},
            headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json' },
          })
        .then((res)=>{
           
            driver_form.append('rider_state',SelectState);
            driver_form.append('rider_district',District);
            driver_form.append('rider_street',RiderStreet);
            driver_form.append('profile_picture',Photo);
            driver_form.append('field_name',File);
            driver_form.append('driver_id',res.data.id)
      
            (SelectState," ",District," ",RiderStreet, " ", File, " ",Photo, " ",res.data.id)
            axios({
                method: "patch",
                url: `http://192.1680.0.11:8888/user/rider-information/${b}/`,
                data: driver_form,
                headers: {  Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/x-www-form-urlencoded' },
              })
            .then((res)=>{
            
            })
        })
    }
    else{
 
    }

    }


    return(
        <div className="pt-5 p-3 pb-3">
       <div className="bg-white p-4 rounded">
       <h1 className="fs-6 fw-bolder pb-4 text-start">Update Rider</h1>
        <div className="row m-0">
            <div className="col p-0">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">First Name</label>
                <input type="text" className="form-control1" defaultValue={FirstName} onChange={onFirstName} placeholder="Enter rider first Name" />
            </div>
            </div>
            <div className="col p-0 ms-3">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Last Name</label>
                <input type="text" className="form-control1" defaultValue={LastName} onChange={onLastName} placeholder="Enter rider last Name" />
            </div>
            </div>
            <div className="col p-0 ms-3">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Email</label>
                    <input type="text" className="form-control1" defaultValue={Email} onChange={onEmail} placeholder="Enter Rider Email" />
                </div>
            </div>
        </div>
        <div className="row m-0 mt-3">
            <div className="col p-0 text-end">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Drop State</label>
                    <select className="form-control1" defaultValue={SelectState} onChange={onState}>
                        {
                            state.map(statedata=>(
                                statedata===SelectState?<option selected>{statedata}</option>:<option>{statedata}</option>
                            ))
                        }
                    </select>
                </div>
            </div>
            <div className="col p-0 ms-3">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Drop District</label>
                    <select className="form-control1" onChange = {onDistrict}>
                        {
                            updatedDropState && updatedDropState.map(dis=>(
                                dis===District?<option selected>{dis}</option>:<option>{dis}</option>
                            ))
                        }
                    </select>
                </div>
            </div>
            <div className="col p-0 ms-3">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Rider Street</label>
                    <input type="text" className="form-control1" defaultValue= {RiderStreet} onChange={onRiderStreet} placeholder="Enter Rider street" />
                </div>
            </div>
        </div>
        <div className="row m-0 mt-4">
            <div className="col p-0 ">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Rider Contact</label>
                    <input type="text" className="form-control1" defaultValue = {Contact} onChange={onContact}  placeholder="Enter Rider Contact on" />
                </div>
            </div>
            <div className="col p-0 ms-3">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">License </label>
                    <input onChange={onFile} type="file" value={File.OriginalName} className="form-control mb-4 fs-14 fw-bolder" id="customFile" />
                    <lable className="mt-3">Current File : <img  src={File} className='w-100'/></lable>
                </div>
            </div>
            <div className="col p-0 ms-3">
                <div className="form-group text-start">
                <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Photo </label>
                    <input onChange={onPhoto} type="file" className="form-control mb-4 fs-14 fw-bolder" id="customFile"/>
                    <lable className="mt-3">Current Photo : <img  src={Photo} className='w-100'/></lable>
                </div>
            </div>
        </div>
        <div className="d-flex mt-3">
            <div className="">
                <button className="btn btn-success border-0 " onClick = {(e)=>save(e,userId,DriverId)}>Update</button>
            </div>
        </div>
       </div>
    </div>
    )
}

export default Rider_updatepage