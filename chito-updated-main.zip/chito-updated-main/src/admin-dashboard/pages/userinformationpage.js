import React, { useState,useEffect } from 'react';
import axios from 'axios';

const User_informationpage = ()=>{
    const [UserData,setUserdata] = useState([]);
    const [UserType,setUserType] = useState([]);

    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/user/`)
        .then((res)=>{
            // 
            setUserdata(res.data);
            // if(res.data.is_admin==false && res.data.is_driver==false)
            //             {
            //                 setUserType('Normal User');
            //             }
            //             else if(res.data.is_admin==false && res.data.is_driver==true){
            //                 setUserType('Rider')
            //             }
            //             else if(res.data.is_admin==true){
            //                 setUserType('Admin')
            //             }
            //             else{
            //                
            //             }
        })
        .catch((err)=>{
            
        })
    },[])
    return(
        <div className="px-3">
            <div className="bg-white shadow-sm p-4 mt-4" style={{overflowX:'auto'}}>
                <div className="">          
                    <table className="table border-0 text-start">
                        <thead className='border-bottom'>
                            <tr>
                                <th>User Id</th>
                                <th>Full Name</th>
                                <th>Company Name</th>
                                <th>Email</th>
                                <th>User Type</th>
                                <th>Contact No</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                UserData.map(user=>(
                                    <tr key='id_index'>
                                        <td>{user.id}</td>
                                        <td>{user.first_name} {user.last_name}</td>
                                        <td>{user.company_name}</td>
                                        <td>{user.email}</td>
                                        <td>Hello</td>
                                        <td>{user.contactno}</td>
                                        <td >
                                            {
                                                user.last_login == null ?
                                                <p className="bg-danger rounded-circle active-user border border-2"></p>:
                                                <p className="bg-success rounded-circle active-user border border-2"></p>
                                            }
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}
export default User_informationpage;