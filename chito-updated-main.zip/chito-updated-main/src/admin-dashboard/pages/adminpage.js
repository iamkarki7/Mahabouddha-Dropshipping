import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

const Admin_page = () => {
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const history = useHistory();

    const onEmail = e => setEmail(e.target.value);
    const onPassword = e => setPassword(e.target.value);

    const clickBtn = e => {
        // let isLoggedIn = props.isLoggedIn;
        e.preventDefault();
        if (email === 'chitologistic@gmail.com', password === 'chito123') {
            if (email && password) {
                history.push('/admin/dashboard');
            } else {

            }
        } else {

        }
    }

    return (
        <section className="container-fluid p-0 admin-margin-top">
            <div className="">
                <div className="col-4 m-auto dash-board-color shadow rounded p-5">
                    <header className="text-center pb-5">
                        <h1 className="text-white fs-3 fw-bolder">Chito Logitics </h1>
                    </header>
                    <form>
                        <div className="form-group d-flex form-border mb-4">
                            <i className="fa fa-user admin-form-icon fs-20 bg-light p-2"></i>
                            <input type="text" onChange={onEmail} className="form-control1 border-0 rounded-0 " id="email" name="email" placeholder="Enter Email" />
                        </div>
                        <div className="form-group d-flex form-border mb-3">
                            <i className="fa fa-key admin-form-icon fs-20 bg-light p-2"></i>
                            <input type="password" onChange={onPassword} className="form-control1 border-0 rounded-0 " id="password" name="password" placeholder="Password" />
                        </div>
                        <div className="mb-2 form-check text-start">
                            <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                            <label className="form-check-label text-white" for="exampleCheck1">Remember Me</label>
                        </div>
                        <button type="submit" onClick={clickBtn} className="btn btn-light w-100 px-4 mt-2 fw-bolder">Login</button>
                    </form>
                </div>
            </div>
        </section>

    )
}
export default Admin_page;