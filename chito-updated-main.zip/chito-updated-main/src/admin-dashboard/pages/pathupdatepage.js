import axios from 'axios';
import React,{useState,useEffect} from 'react';
import Cookies from 'js-cookie';
import { Link } from 'react-router-dom';
import { useParams } from 'react-router';

const Path_updatepage = ()=>{
    const [changePath,setchangePath] = useState([]);
    const [inputList, setInputList] = useState([{}]);
    const [PathCode,setPathCode] = useState([]);

    const [Path,setPath] = useState([]);
    const [Pathinfoid,setPathinfoId]= useState([]);
    const [Pathplaceid,setPathplaceid] = useState([]);
  
    var router_code = useParams();
    var id = router_code['route_code']

    const handleInputChange = (e, index) => {
        const { name, value } = e.target;
        const list = [...inputList];
        list[index][name] = value;
        setInputList(list);
      };
     
      // handle click event of the Remove button
      const handleRemoveClick = index => {
        const list = [...inputList];
        list.splice(index, 1);
        setInputList(list);
      };
      // handle click event of the Add button
      const handleAddClick = () => {
        setInputList([...inputList, { place: "",}]);
      };
      const onchangePath = (e)=> setchangePath(e.target.value);
      const onPathCode =(e)=>setPathCode(e.target.value);

      useEffect(()=>{
          axios.get(`https://api.mahaboudhawholesale.com/path/pathinfo/?route_code=${id}`)
          .then((res)=>{
        
              setPathinfoId(res.data[0].id);
              setPath(res.data[0])
              setchangePath(res.data[0].path_name)
              setPathCode(res.data[0].route_code)
              axios.get(`https://api.mahaboudhawholesale.com/path/pathplace/?route_code=${res.data[0].id}`)
              .then((res)=>{
              
                setPathplaceid()
                  var ars= [];
                  for(var i=0;i<res.data.length;i++)
                  {
                      ars.push(res.data[i]);
                  }
              
                  setInputList(ars);
           
              })
          })
      },[])
  

      function createPath(path,input,e)
      {
          e.preventDefault();
       
            axios.put(`https://api.mahaboudhawholesale.com/path/pathinfo/${Pathinfoid}/`,{'path_name':changePath,'route_code':PathCode},{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
            .then((res)=>{
               
                for(var i=0;i<inputList.length;i++)
                {
                  
                    if(inputList[i]['id']==undefined || inputList[i]['id']==null)
                    {
                        axios.post(`https://api.mahaboudhawholesale.com/path/pathplace/`,{'route_code':res.data.id,'route_place':inputList[i]['place']},{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                    .then((res)=>{
                       
                    })
                    }
                    else{
                    axios.put(`https://api.mahaboudhawholesale.com/path/pathplace/${inputList[i]['id']}/`,{'route_code':res.data.id,'route_place':inputList[i]['place']},{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                    .then((res)=>{
                       
                    })
                }
                }
            })
          
      }
    return(
        <div className="p-3 pt-4">
            <div className="bg-white p-3 pt-4 rounded">
                <form>
                    <div className="row m-0">
                        <div className="col p-0">
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Path Name:</h1>
                                <input type="text" className="form-control1" onChange={onchangePath} defaultValue={changePath}placeholder=" Enter Path Name :" />
                            </div>
                        </div>
                        <div className="col p-0 ms-4">
                            <div className="form-group">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Path Code:</h1>
                                <input type="text" className="form-control1" onChange={onPathCode} defaultValue={PathCode} placeholder=" Enter path code :" />
                            </div>
                        </div>
                    </div>
                    {inputList.map((x, i) => {
                    return (
                        <div className="mt-4">
                            <div className='row m-0'>
                                <div className="col p-0 me-4">
                                    <h1 className="fs-16 text-start mb-3 form-text text-dark form-text text-dark">Place {i+1}:</h1>
                                    <input type="text" className="form-control1" name="place" defaultValue={x.route_place} placeholder="Enter Place" onChange={e => handleInputChange(e, i)} />
                                </div>
                                <div className='col p-0'></div>
                            </div>
                            <div className="btn-box text-start mt-3">
                                {inputList.length !== 1 && <button
                                    className="btn btn-danger btn-sm me-2"
                                    onClick={() => handleRemoveClick(i)}>Remove Place</button>}
                                {inputList.length - 1 === i && <button className="btn back-color btn-sm text-white" onClick={handleAddClick}><i className="fa fa-plus me-2"></i>Add Place</button>}
                            </div>
                        </div>
                        );
                    })}
                    <div className="text-start mt-4">
                        <button onClick={(e)=>createPath(changePath,inputList,e)} className="btn btn-info text-white px-3">Create Path</button>
                    </div>
                </form>
            </div>
         
        </div>
        
    )
}
export default Path_updatepage;
