import React from 'react';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';
import Neworder_page from './pages/neworderpage';

const New_order = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <Neworder_page/>
            </div>
        </div>
    )
}
export default New_order;