import React from 'react';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';
import Completed_orderpage from './pages/completedorderpage';

const Completed_order = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <Completed_orderpage/>
            </div>
        </div>
    )
}
export default Completed_order;