import React from 'react';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';
import Today_orderpage from './pages/todayorderpage';

const Today_order = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <Today_orderpage/>
            </div>
        </div>
    )
}
export default Today_order;