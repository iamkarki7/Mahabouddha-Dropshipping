import React from 'react';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';
import Pending_orderpage from './pages/pendingorderpage';

const Pending_order = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <Pending_orderpage/>
            </div>
        </div>
    )
}
export default Pending_order;