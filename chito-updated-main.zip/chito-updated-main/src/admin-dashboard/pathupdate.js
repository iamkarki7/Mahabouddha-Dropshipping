import React from 'react';
import Admin_sidebar from './component/sidebar';
import Header from './component/header';
import Path_updatepage from './pages/pathupdatepage';

const Path_update = ()=>{
    return(
        <div className="row m-0">
            <div className="col-1 p-0">
                <Admin_sidebar/>
            </div>
            <div className="col p-0">
                <Header/>
                <Path_updatepage/>
            </div>
        </div>
    )
}
export default Path_update;