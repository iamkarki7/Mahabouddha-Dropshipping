import React from 'react';
import Rider_sidebar from './component/rider-sidebar';
import Header from './component/header';
import All_orderpage from './page/allorderpage';

const All_order = ()=>{
    return(
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0">
                <Rider_sidebar/>
            </div>
            <div className="col-lg p-0">
                <Header/>
                <All_orderpage/>
            </div>
        </div>
    )
}
export default All_order;