import React from 'react';
import Rider_sidebar from './component/rider-sidebar';
import Header from './component/header';
import Route_page from './page/routepage';

const Rider_route = ()=>{
    return(
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0">
                <Rider_sidebar/>
            </div>
            <div className="col-lg p-0">
                <Header/>
                <Route_page/>
            </div>
        </div>
    )
}
export default Rider_route;