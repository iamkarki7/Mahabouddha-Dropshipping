import React from 'react';
import Rider_sidebar from './component/rider-sidebar';
import Header from './component/header';
import Dashboard_page from './page/dashboardpage';

const Rider_dashboard = ()=>{
    return(
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0">
                <Rider_sidebar/>
            </div>
            <div className="col-lg p-0">
                <Header/>
                <Dashboard_page/>
            </div>
        </div>
    )
}
export default Rider_dashboard;