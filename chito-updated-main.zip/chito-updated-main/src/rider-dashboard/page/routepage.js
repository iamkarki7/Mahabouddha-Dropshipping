import React, { useState } from 'react';

const Route_page = ()=>{
    const [Switch, setSwitch] = useState(false);
    return(
        <div className="p-3 pt-4">
                <div className="col p-0 text-start">
                    <h1 className="fs-5 fw-bolder">Rider Route</h1>
                </div>
            <div className="p-3  bg-white mb-5 rounded mt-4 new-overflow">
                <table className="table border-0 mt-4 new-width">
                    <thead className='border-bottom'>
                        <tr className="bg-white">
                            <th scope="col " className="fs-14">Route No</th>
                            <th scope="col " className="fs-14">Path Start</th>
                            <th scope="col" className="fs-14">Path1</th>
                            <th scope="col" className="fs-14">Path2</th>
                            <th scope="col" className="fs-14">Path3</th>
                            <th scope="col" className="fs-14">Path3</th>
                            <th scope="col" className="fs-14">Path End</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr className="data-information">
                        <th scope="row" className="fs-12"></th>
                        <td className="fs-12"></td>
                        <td className="fs-12"></td>
                        <td className="fs-12"></td>
                        <td className="fs-12"></td>
                        <td className="fs-12">
                          
                        </td>
                        <td className="text-success fs-12">
                            <i className="fa fa-eye"></i>
                            
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
        </div>
    )
}
export default Route_page;