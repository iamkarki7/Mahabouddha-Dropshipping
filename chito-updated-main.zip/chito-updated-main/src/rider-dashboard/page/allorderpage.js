import axios from 'axios';
import Cookies from 'js-cookie';
import React,{useState} from 'react';
import {Link} from 'react-router-dom';
import { useEffect } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ExportToExcel from "../../functions/exporttocsv"
import * as FileSaver from "file-saver";
import dateconversion from '../../functions/dateconversion';


const Neworder_page = ()=>{
    const [pendingOrder,setPendingOrder] = useState([]);
    const [approvedOrder,setApprovedOrder] = useState([]);
    const [holdOrder,setHoldOrder] = useState([]);
    const [checkedInOrder,setcheckedInOrder]= useState([]);
    const [deliveredOrder,setDeliveredOrder] = useState([]);
    const [cancelledOrder,setCancelledOrder] = useState([]);
    const [changeTime,setChangeTime] = useState([]);
    const [status, setStatus] = useState([]);
    const [downloadablelink,setdownloadablelink] = useState([]);
    const [NewSwitch,setNewSwitch] = useState(false);

    const onchangeTime =(e) => 
    {
        
        if(e.target.value=="Custom")
        {
            setNewSwitch(true);
        }
        else{
            setNewSwitch(false)
        }
        setChangeTime(e.target.value);
    }

   

    var id = Cookies.get('id');
    id=parseInt(id);
    var d = new Date();
 
    var today_fulldate = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()
 
    var last_year = new Date(new Date().setFullYear(new Date().getFullYear() - 1))
    var last_year_fulldate = last_year.getFullYear()+"-"+(last_year.getMonth()+1)+"-"+last_year.getDate()
    var last_semiannual = new Date(new Date().setMonth(new Date().getMonth() - 6))
    var last_semiannual_fulldate = last_semiannual.getFullYear()+"-"+(last_semiannual.getMonth()+1)+"-"+last_semiannual.getDate()
    var last_quarter = new Date(new Date().setMonth(new Date().getMonth() - 3))
    var last_quarter_fulldate = last_quarter.getFullYear()+"-"+(last_quarter.getMonth()+1)+"-"+last_quarter.getDate()
    var last_month = new Date(new Date().setMonth(new Date().getMonth() - 1))
    var last_month_fulldate = last_month.getFullYear()+"-"+(last_month.getMonth()+1)+"-"+last_month.getDate()
    var last_week = new Date(new Date().setDate(new Date().getDate() - 7))
    var last_week_fulldate = last_week.getFullYear()+"-"+(last_week.getMonth()+1)+"-"+last_week.getDate()
    var tomorrow = new Date(new Date().setDate(new Date().getDate() + 1))
    var tomorrow_fulldate = tomorrow.getFullYear()+"-"+(tomorrow.getMonth()+1)+"-"+tomorrow.getDate()
 
    var firstdate = "1960-01-01"

    // const onchangeTime =(e) => setChangeTime(e.target.value);
    const [Formdate, setFormdate] = useState(new Date());
    const [Todate, setTodate] = useState(new Date());

    const onFormdate = date => setFormdate(date);
    const onTodate = date => setTodate(date);

    var mydate1 = dateconversion(Formdate);
    var mydate2 = dateconversion(Todate)

    var first_date = firstdate
    var last_date = tomorrow_fulldate;
 

    if((changeTime=="" || changeTime == "Sort By" || changeTime == "Custom") && (Formdate=="" || Todate==""))
    {
        first_date = firstdate;
    }
    else if((changeTime == "Custom") && (Formdate != "" || Todate != ""))
    {
      
        first_date = mydate1;
        last_date = mydate2;
    }
    else if(changeTime=="yearly")
    {
        first_date = last_year_fulldate;
    }
    else if(changeTime == 'hYearly')
    {
        first_date = last_semiannual_fulldate;
    }
    else if(changeTime == "quarterly")
    {
        first_date = last_quarter_fulldate;
    }
    else if(changeTime == "monthly")
    {
        first_date = last_month_fulldate;
    }
    else if(changeTime == "weekly")
    {
        first_date = last_week_fulldate;
    }
    else if(changeTime == "daily")
    {
   
        first_date = today_fulldate;
        last_date = tomorrow_fulldate;
    }
    else{
        first_date = firstdate
    }

    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/status/`)
        .then((res)=>{
            setStatus(res.data);
        })

    },[])
 
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?status=1&created_date__gte=${first_date}&created_date__lte=${last_date}`)
        .then((res)=>{
            var array =[]
          
            for(var i=0;i<res.data.length;i++)
            {
            
                var date = new Date(res.data[i].created_date);
                date = date.toLocaleString();
                res.data[i].created_date = date;
                if(res.data[i].rider_name.id==Cookies.get('id'))
                {
                    array.push(res.data[i])
                }
            }
          
            setPendingOrder(array);
        })
    },[id,first_date,last_date])
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?status=2&created_date__gte=${first_date}&created_date__lte=${last_date}`)
        .then((res)=>{
            var array =[]
          
            for(var i=0;i<res.data.length;i++)
            {
               
                var date = new Date(res.data[i].created_date);
                date = date.toLocaleString();
                res.data[i].created_date = date;
                if(res.data[i].rider_name.id==Cookies.get('id'))
                {
                    array.push(res.data[i])
                }
            }
         
            setApprovedOrder(array);
        })
    },[id,first_date,last_date])
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?status=3&created_date__gte=${first_date}&created_date__lte=${last_date}`)
        .then((res)=>{
            var array =[]
      
            for(var i=0;i<res.data.length;i++)
            {
               
                var date = new Date(res.data[i].created_date);
                date = date.toLocaleString();
                res.data[i].created_date = date;
                if(res.data[i].rider_name.id==Cookies.get('id'))
                {
                    array.push(res.data[i])
                }
            }
          
            setHoldOrder(array);
        })
    },[id,first_date,last_date])
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?status=4&created_date__gte=${first_date}&created_date__lte=${last_date}`)
        .then((res)=>{
            var array =[]
       
            for(var i=0;i<res.data.length;i++)
            {
            
                var date = new Date(res.data[i].created_date);
                date = date.toLocaleString();
                res.data[i].created_date = date;
                if(res.data[i].rider_name.id==Cookies.get('id'))
                {
                    array.push(res.data[i])
                }
            }
           
            setcheckedInOrder(array);
        })
    },[id,first_date,last_date])
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?status=5&created_date__gte=${first_date}&created_date__lte=${last_date}`)
        .then((res)=>{
            var array =[]
        
            for(var i=0;i<res.data.length;i++)
            {
             
                var date = new Date(res.data[i].created_date);
                date = date.toLocaleString();
                res.data[i].created_date = date;
                if(res.data[i].rider_name.id==Cookies.get('id'))
                {
                    array.push(res.data[i])
                }
            }
          
            setDeliveredOrder(array);
        })
    },[id,first_date,last_date])
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?status=6&created_date__gte=${first_date}&created_date__lte=${last_date}`)
        .then((res)=>{
            var array =[]
       
            for(var i=0;i<res.data.length;i++)
            {
               
                var date = new Date(res.data[i].created_date);
                date = date.toLocaleString();
                res.data[i].created_date = date;
                if(res.data[i].rider_name.id==Cookies.get('id'))
                {
                    array.push(res.data[i])
                }
            }
         
            setCancelledOrder(array);
        })
    },[id,first_date,last_date])
    function setCancel(e,id)
    {
    
        if(e)
        {
            if (window.confirm(`Would you like to confirm this ${e} request?`)) {
                for(var i=0;i<status.length;i++){
                if(e==status[i].status_name)
                {
                    var status_id = parseInt(status[i].id);
                }
                }
                axios.patch(`https://api.mahaboudhawholesale.com/order/orders/${parseInt(id)}/`,{'status':status_id})
                .then(res=>{
                   
                })
            }
                window.location.reload(true);
              
                  
              } else {
                var txt = "You pressed Cancel!";
              }
        }
        function myPdf(a,b,c,d){
         
            axios.post(`https://api.mahaboudhawholesale.com/order/docs/`,{'start_date':a,'end_date':b,'document_type':c,'user_id':d})
            .then((res)=>{
               axios.get(`https://api.mahaboudhawholesale.com/order/dump/`,
               {headers: {'Content-Type': "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}, responseType: "arraybuffer"}
               )
               .then((response)=>{
                   (response.data)
                   (typeof(response.data))
                var blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                FileSaver.saveAs(blob, 'fixi.xlsx');
               })
            })
            
        }
        function myXls(a,b,c,d){
        
        }
        const [data, setData] = React.useState([])
        const fileName = "myfile"; // here enter filename for your excel file
      
      
    //custom select option value from date
    
    const [Newshow, setNewshow] = useState(false);
    const[NewDoc, setNewDoc] = useState(false);

    const [xceldata, setxcelData] = React.useState([])
    const xcelfileName = "myfile"; // here enter filename for your excel file
  
    React.useEffect(() => {
      const fetchData = () =>{
       axios.get('https://api.mahaboudhawholesale.com/order/dump/').then(r => setxcelData(r.data) )
      }
      fetchData()
    }, [])

    return(
        <div className="mt-3 p-2">
            <div className="p-3 pt-4 bg-white mb-5 pb-5 rounded">
            <div className="row m-0">
            <div className="col-lg-3 p-0 text-start">
                        <p className="form-text text-dark">Download or Print </p>
                        <div className="d-flex">
                            <button className="btn btn-white rounded-0 border-dark btm-sm py-1 fs-14 fm-11 fw-bolder download-information w-100"><i className="fa fa-download"></i> Export</button>
                            <button className="btn btn-white rounded-0 border-dark btm-sm py-1 ms-4 fs-14 fm-11 fw-bolder download-information w-100"><i className="fa fa-print"></i> Print</button>
                        </div>
                    </div>
                    <div className="col-lg p-0">
                        <div className="row m-0 mt-lg-0 mt-3">
                            <div className="col-lg col-6 p-0 ms-lg-3 text-start">
                                <p className="form-text text-dark">By Status </p>
                                <select className="form-control1" onChange={onchangeTime}>
                                    <option value={null}>Sort By</option>
                                    <option value="yearly">Yearly</option>
                                    <option value="hYearly">Half Yearly</option>
                                    <option value="quarterly">Quarterly</option>
                                    <option value="monthly">Monthly</option>
                                    <option value="weekly">Weekly</option>
                                    <option value="daily">Daily</option>
                                    <option value="express">Express</option>
                                    <option value="normal">Normal</option>
                                    <option>Custom</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div className="col-6 p-0 ms-lg-4 ms-md-2">
                        {
                            NewSwitch===true ?
                            <div className="">
                            <div className="row m-0 text-start">
                                <div className="col-lg col-6 p-0 mt-lg-0 mt-3">
                                    <p className="form-text text-dark">From </p>
                                    <div className="d-flex">
                                        <DatePicker selected={Formdate} onChange={onFormdate}  className="form-control1 form-width"/>
                                    </div>
                                </div>
                                <div className="col-lg col p-0 ms-lg-4 ms-lg-2 mt-lg-0 mt-3">
                                    <p className="form-text text-dark">To </p>
                                    <div className="d-flex">
                                        <DatePicker selected={Todate} onChange={onTodate} className="form-control1 form-width"/>
                                    </div>
                                </div>
                            </div>
                        </div>:null
                        }
                    </div>
                </div>
            </div>
            <div className="p-3 pt-4 bg-white">
                           {/* <div className="App">
      <ExportToExcel apiData={xceldata} fileName={xcelfileName} />
    </div> */}
    <ul className="nav nav-tabs" id="myTab" role="tablist">
                    <li className="nav-item" role="presentation">
                        <button className="nav-link active form-text2 fm-10 btn-padding" id="Pending_tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab" aria-controls="pending" aria-selected="true">Pending Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Approved_tab" data-bs-toggle="tab" data-bs-target="#approved" type="button" role="tab" aria-controls="approved" aria-selected="false">Approved Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Hold_tab" data-bs-toggle="tab" data-bs-target="#hold" type="button" role="tab" aria-controls="hold" aria-selected="false">Hold Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Checked_in_tab" data-bs-toggle="tab" data-bs-target="#checked" type="button" role="tab" aria-controls="checked" aria-selected="false">Checked In Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Delivered_order_tab" data-bs-toggle="tab" data-bs-target="#delivered" type="button" role="tab" aria-controls="delivered" aria-selected="false">Delivered Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Cancelled_tab" data-bs-toggle="tab" data-bs-target="#cancelled" type="button" role="tab" aria-controls="cancelled" aria-selected="false">Cancelled Order</button>
                    </li>
                </ul>
                <div className="tab-content col-12 new-overflow p-0" id="myTabContent">
                    <div className="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="Pending_tab">
                        <table className="table border-0 mt-4 new-width text-start">
                    <thead className='border-bottom'>
                        <tr className="bg-white">
                            <th scope="col " className="fs-14 fm-11">Order Number</th>
                            <th scope="col " className="fs-14 fm-11">Customer Name</th>
                            <th scope="col" className="fs-14 fm-11">Customer Mobile</th>
                            <th scope="col" className="fs-14 fm-11">Created Date</th>
                            {/* <th scope="col" className="fs-14 fm-11">Delivery Date</th> */}
                            <th scope="col" className="fs-14 fm-11">Status</th>
                            <th scope="col" className="fs-14 fm-11">Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        {pendingOrder.map(key=>(
                        <tr className="data-information">
                        <th scope="row" className="fs-12"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                        <td className="fs-12">{key.customer_name}</td>
                        <td className="fs-12">{key.customer_mobile}</td>
                        <td className="fs-12">{key.created_date}</td>
                        {/* <td className="fs-12">{key.delivery_date}</td> */}
                        <td className="fs-12">
                            <select defaultValue = "Pending" className='border-0 new-border px-2 py-1' onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  DefaultValue={state.status_name}>{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select>
                        </td>
                        <td className="text-success fs-12">
                            <Link className="text-decoration-none back-color text-white ms-2 px-2 py-1 rounded" to={`/view/my/data/${key.OrderNumber}`}><i className="fa fa-eye text-white fs-13"></i></Link>
                        </td>
                    </tr>
                        ))}
                </tbody>
            </table>
                    </div>
                    <div className="tab-pane fade" id="approved" role="tabpanel" aria-labelledby="Approved_tab">
                        <table className="table border-0 text-start mt-4 new-width">
                    <thead className='border-bottom'>
              
                        <tr className="bg-white">
                            <th scope="col " className="fs-14 fm-11">Order Number</th>
                            <th scope="col " className="fs-14 fm-11">Customer Name</th>
                            <th scope="col" className="fs-14 fm-11">Customer Mobile</th>
                            <th scope="col" className="fs-14 fm-11">Created Date</th>
                            {/* <th scope="col" className="fs-14 fm-11">Delivery Date</th> */}
                            <th scope="col" className="fs-14 fm-11">Status</th>
                            <th scope="col" className="fs-14 fm-11">Details</th>
                        </tr>
                       
                    </thead>
                    <tbody>
                    {approvedOrder.map(key=>(
                        <tr className="data-information">
                             <th scope="row" className="fs-12"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                        <td className="fs-12">{key.customer_name}</td>
                        <td className="fs-12">{key.customer_mobile}</td>
                        <td className="fs-12">{key.created_date}</td>
                        {/* <td className="fs-12">{key.delivery_date}</td> */}
                        <td className="fs-12">  <select defaultValue = "Approved" className='border-0 new-border px-2 py-1' onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  DefaultValue={state.status_name}>{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select></td>
                        <td className="text-success fs-12">
                        <Link className="text-decoration-none back-color text-white ms-2 px-2 py-1 rounded" to={`/view/my/data/${key.OrderNumber}`}><i className="fa fa-eye text-white fs-13"></i></Link>
                           
                        </td>
                    </tr>
                         ))}
                </tbody>
            </table>
                    </div>
                    <div className="tab-pane fade" id="hold" role="tabpanel" aria-labelledby="Hold_tab">
                        <table className="table border-0 mt-4 new-width text-start">
                    <thead className='border-bottom'>
                        <tr className="bg-white">
                            <th scope="col " className="fs-14 fm-11">Order Number</th>
                            <th scope="col " className="fs-14 fm-11">Customer Name</th>
                            <th scope="col" className="fs-14 fm-11">Customer Mobile</th>
                            <th scope="col" className="fs-14 fm-11">Created Date</th>
                            {/* <th scope="col" className="fs-14 fm-11">Delivery Date</th> */}
                            <th scope="col" className="fs-14 fm-11">Status</th>
                            <th scope="col" className="fs-14 fm-11">Details</th>
                        </tr>
                    </thead>
                    <tbody>
                    {holdOrder.map(key=>(
                        <tr className="data-information">
                             <th scope="row" className="fs-12"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                        <td className="fs-12">{key.customer_name}</td>
                        <td className="fs-12">{key.customer_mobile}</td>
                        <td className="fs-12">{key.created_date}</td>
                        {/* <td className="fs-12">{key.delivery_date}</td> */}
                        <td className="fs-12">
                        <select defaultValue = "Hold" className='border-0 new-border px-2 py-1' onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  DefaultValue={state.status_name}>{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select>
                        </td>
                        <td className="text-success fs-12">
                            <Link className="text-decoration-none back-color text-white ms-2 px-2 py-1 rounded" to={`/view/my/data/${key.OrderNumber}`}><i className="fa fa-eye text-white fs-13"></i></Link>    
                        </td>
                    </tr>
                         ))}
                </tbody>
            </table>
                    </div>
                    <div className="tab-pane fade" id="checked" role="tabpanel" aria-labelledby="Checked_in_tab">
                        <table className="table border-0 mt-4 new-width text-start">
                    <thead className='border-bottom'>
                        <tr className="bg-white">
                            <th scope="col " className="fs-14 fm-11">Order Number</th>
                            <th scope="col " className="fs-14 fm-11">Customer Name</th>
                            <th scope="col" className="fs-14 fm-11">Customer Mobile</th>
                            <th scope="col" className="fs-14 fm-11">Created Date</th>
                            {/* <th scope="col" className="fs-14 fm-11">Delivery Date</th> */}
                            <th scope="col" className="fs-14 fm-11">Status</th>
                            <th scope="col" className="fs-14 fm-11">Details</th>
                        </tr>
                    </thead>
                    <tbody>
                    {checkedInOrder.map(key=>(
                        <tr className="data-information">
                             <th scope="row" className="fs-12"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                        <td className="fs-12">{key.customer_name}</td>
                        <td className="fs-12">{key.customer_mobile}</td>
                        <td className="fs-12">{key.created_date}</td>
                        {/* <td className="fs-12">{key.delivery_date}</td> */}
                        <td className="fs-12">
                        <select defaultValue = "Checked In" className='border-0 new-border px-2 py-1' onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  DefaultValue={state.status_name}>{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select>
                        </td>
                        <td className="text-success fs-12">
                            <Link className="text-decoration-none back-color text-white ms-2 px-2 py-1 rounded" to={`/view/my/data/${key.OrderNumber}`}><i className="fa fa-eye text-white fs-13"></i></Link>
                        </td>
                    </tr>
                         ))}
                </tbody>
            </table>
                    </div>
                    <div className="tab-pane fade" id="delivered" role="tabpanel" aria-labelledby="Delivered_order_tab">
                        <table className="table border-0 mt-4 new-width text-start">
                    <thead className='border-bottom'>
                        <tr className="bg-white">
                            <th scope="col " className="fs-14 fm-11">Order Number</th>
                            <th scope="col " className="fs-14 fm-11">Customer Name</th>
                            <th scope="col" className="fs-14 fm-11">Customer Mobile</th>
                            <th scope="col" className="fs-14 fm-11">Created Date</th>
                            {/* <th scope="col" className="fs-14 fm-11">Delivery Date</th> */}
                            <th scope="col" className="fs-14 fm-11">Status</th>
                            <th scope="col" className="fs-14 fm-11">Details</th>
                        </tr>
                    </thead>
                    <tbody>
                    {deliveredOrder.map(key=>(
                        <tr className="data-information">
                             <th scope="row" className="fs-12"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                        <td className="fs-12">{key.customer_name}</td>
                        <td className="fs-12">{key.customer_mobile}</td>
                        <td className="fs-12">{key.created_date}</td>
                        {/* <td className="fs-12">{key.delivery_date}</td> */}
                        <td className="fs-12">
                        <select defaultValue = "Delivered" className='border-0 new-border px-2 py-1' onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} >Select Status</option>
                            {
                                    status.map(state=>(
                                    <option  DefaultValue={state.status_name}>{state.status_name}</option>
                                ))
                            }
                                {/* <option value="Pending">Pending</option>
                                <option value="Approved">A</option>
                                <option value="Cancelled">Cancelled</option> */}
                            </select></td>
                        <td className="text-success fs-12">
                        <Link className="text-decoration-none back-color text-white ms-2 px-2 py-1 rounded" to={`/view/my/data/${key.OrderNumber}`}><i className="fa fa-eye text-white fs-13"></i></Link>
                          
                        </td>
                    </tr>
                         ))}
                </tbody>
            </table>
                    </div>
                    <div className="tab-pane fade" id="cancelled" role="tabpanel" aria-labelledby="Cancelled_tab">
                        <table className="table border-0 mt-4 new-width text-start">
                    <thead className='border-bottom'>
                        <tr className="bg-white">
                            <th scope="col " className="fs-14 fm-11">Order Number</th>
                            <th scope="col " className="fs-14 fm-11">Customer Name</th>
                            <th scope="col" className="fs-14 fm-11">Customer Mobile</th>
                            <th scope="col" className="fs-14 fm-11">Created Date</th>
                            <th scope="col" className="fs-14 fm-11">Status</th>
                            <th scope="col" className="fs-14 fm-11">Details</th>
                        </tr>
                    </thead>
                    <tbody>
                    {cancelledOrder.map(key=>(
                        <tr className="data-information">
                             <th scope="row" className="fs-12"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                        <td className="fs-12">{key.customer_name}</td>
                        <td className="fs-12">{key.customer_mobile}</td>
                        <td className="fs-12">{key.created_date}</td>
                        <td className="fs-12 text-danger">{key.status.status_name}</td>
                        <td className="text-success fs-12">
                        <Link className="text-decoration-none back-color text-white ms-2 px-2 py-1 rounded" to={`/view/my/data/${key.OrderNumber}`}><i className="fa fa-eye text-white fs-13"></i></Link>
                        </td>
                    </tr>
                         ))}
                </tbody>
            </table>
                    </div>
                </div>
        </div>
    </div>

    )
}
export default Neworder_page;
