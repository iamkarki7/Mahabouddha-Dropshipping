import React from 'react';
import Login_page from './pages/login-page';

const Login = ()=>{
    return(
        <div>
            <Login_page/>
        </div>
    )
}

export default Login;