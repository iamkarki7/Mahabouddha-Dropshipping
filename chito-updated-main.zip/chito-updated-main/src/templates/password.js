import React from 'react';
import New_password from './pages/newpassword';

const Password = ()=>{
    return(
        <div>
            <New_password/>
        </div>
    )
}

export default Password;