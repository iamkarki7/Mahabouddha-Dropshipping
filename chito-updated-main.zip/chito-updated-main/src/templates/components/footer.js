import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../../static/image/logo.png';
import SliderNew from '../../static/image/slidernew.jpg';

const Footer = ()=>{
    return(
       <footer className='container-fluid p-lg-5 p-3 pt-5  dash-board-color'>
           <div className='container p-0'>
               <div className='row m-0 pb-5'>
                   <div className='col-lg p-0 me-lg-5 res-text'>
                       <img src={Logo} className="w-75 me-auto me-1"/>
                       <p className='fs-13 text-white fw-bolder mt-4 text-start'>Everyday is a new day for us and we work really hard to satisfy our customer everywhere.</p>
                       <div className='mt-5'>
                           <div className=''>
                               <p className='pb-3 fs-18 fw-bolder text-white text-start'>NEWSLETTER SIGNUP</p>
                           </div>
                           <div className='row m-0 res-sub-width'>
                               <div className='col p-0'>
                                   <div className='form-group'>
                                       <input type='email' className='form-control fs-14 fw-bolder border-0 rounded-0 new-form-height w-100' placeholder='Email' />
                                   </div>
                               </div>
                               <div className='col-1 p-0'>
                                   <button className='btn btn-sm bg-white border-0 rounded-0 new-form-height new-width'><i className='fa fa-arrow-right text-color fs-16'></i></button>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div className='col-lg p-0 ms-lg-3 mt-lg-0 mt-5'>
                       <p className='pb-3 fs-18 fw-bolder text-white text-start'>USEFUL LINKS</p>
                       <div className='mt-3 text-start ms-lg-3'>
                           <Link to="/" className='d-block text-white fs-14 text-decoration-none fw-weight pb-3'>Services</Link>
                           <Link to="/" className='d-block text-white fs-14 text-decoration-none fw-weight pb-3'>Typography</Link>
                           <Link to="/" className='d-block text-white fs-14 text-decoration-none fw-weight pb-3'>Shortcodes</Link>
                           <Link to="/" className='d-block text-white fs-14 text-decoration-none fw-weight pb-3'>Incoterms</Link>
                           <Link to="/" className='d-block text-white fs-14 text-decoration-none fw-weight pb-3'>Vacancies</Link>
                           <Link to="/" className='d-block text-white fs-14 text-decoration-none fw-weight pb-3'>Track Your Shipment</Link>
                       </div>
                   </div>
                   <div className='col-lg p-0 mt-lg-0 mt-5'>
                        <p className='pb-3 fs-18 fw-bolder text-white text-start'>GET IN TOUCH</p>
                       <div className='mt-3 text-start'>
                          <div className='d-flex'>
                              <i className='fa fa-map-marker text-white fs-16'></i>
                              <p className='fs-14 fw-bolder ms-3 text-white'>Kalanki, Kathmandu, Nepal.</p>
                          </div>
                          <div className='d-flex mt-2'>
                              <i className='fa fa-phone-square text-white fs-16'></i>
                              <p className='fs-14 fw-bolder ms-3 text-white'>+977-1234567</p>
                          </div>
                          <div className='d-flex mt-2'>
                              <i className='fa fa-envelope text-white fs-16'></i>
                              <p className='fs-14 fw-bolder ms-3 text-white'>info@chitologistics.com</p>
                          </div>
                          <div className='d-flex mt-2'>
                              <i className='fa fa-clock-o text-white fs-16'></i>
                              <p className='fs-14 fw-bolder ms-3 text-white'>Sun - Fri: 8 am - 5 pm</p>
                          </div>
                       </div>
                   </div>
                   <div className='col-lg p-0 mt-lg-0 mt-5'>
                        <p className='pb-3 fs-18 fw-bolder text-white text-start'>LATEST NEWS</p>
                        <div className='mt-3'>
                            <Link to="/" className='text-decoration-none'>
                               <div className='row m-0 mb-4'>
                               <div className='col-5 p-0'>
                                    <div className=''>
                                        <img src={SliderNew} className='w-100 rounded'/>
                                    </div>
                               </div>
                               <div className='col p-0 ms-2'>
                               
                           <div className=''>
                               <h1 className='fs-14 fw-bolder text-white text-start'>How Will You Know Success When it Show Up?</h1>
                               <p className='fs-12 fw-bolder text-start text-white pt-1'>Suspendisse euisahdabh...</p>
                           </div>
                               </div>
                               </div>
                            </Link>
                        </div>
                   </div>
               </div>
               <div className='border-top pt-4'>
                   <p className='text-white fs-12'>Copyright © 2021-2022 to Chito Logistics. All rights reserved. <a href="https://www.developersgd.com/" target="_blank" className='text-info'>Design and Developed by G. & D. Developers Pvt. Ltd.</a></p>
               </div>
               <div className='new-position-icon'>
                   <a href="" className='d-block text-decoration-none'><i className='fa fa-facebook text-white facebook-icon'></i></a>
                   <a href="" className='d-block text-decoration-none'><i className='fa fa-instagram text-white facebook-icon1'></i></a>
                   <a href="" className='d-block text-decoration-none'><i className='fa fa-twitter text-white facebook-icon2'></i></a>
                   <a href="" className='d-block text-decoration-none'><i className='fa fa-youtube text-white facebook-icon3'></i></a>
               </div>
           </div>
       </footer>
    )
}
export default Footer;