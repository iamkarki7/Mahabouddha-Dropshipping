import React, { useContext, useEffect,useState } from 'react';
import { Link, useHistory } from 'react-router-dom';
import Logo from '../../static/image/logo.png';
import Cookies from 'js-cookie';
import { UserContext } from './context';
import Modal from 'react-modal';
import axios from 'axios';
import axiosInstance from './axios';

const Header = ()=>{
    const context = useContext(UserContext);

    const logout = (e) => {
        const Refresh_Token=Cookies.get('refresh_token');
          axios.post(`https://api.mahaboudhawholesale.com/user/logout/`,{'refresh':Refresh_Token},{
            headers: {
              Authorization: Cookies.get('access_token') ?
                'JWT ' + Cookies.get('access_token') :
                null,
              'Content-Type': 'application/json',
              accept: 'application/json',
            },
          })
          .then((res)=>{
            Cookies.remove('refresh_token');
            Cookies.remove('access_token');
            Cookies.remove('id');
            Cookies.remove('email');
            Cookies.remove('user_role')
            window.location.href = '/';
          })
          .catch((err)=>{
           
          })
      }
      var subtitle;
      const [modalIsOpen,setIsOpen] = React.useState(false);
      function openModal() {
        setIsOpen(true);
      }
    
      function afterOpenModal() {
        // references are now sync'd and can be accessed.
        subtitle.style.color = '#f00';
      }
    
      function closeModal(){
        setIsOpen(false);
      }

    const [isAuth, setIsAuth] = useState(false);

    const Access_token = Cookies.get('access_token');
    const Refresh_token = Cookies.get('refresh_token');
    const Email = Cookies.get('email');
    const ID = Cookies.get('id');
    const Password = Cookies.get('password');
    const TOKEN_KEY = {Access_token,Refresh_token,ID,Email,Password};

    useEffect(()=>{
        if(TOKEN_KEY['Access_token']==null && TOKEN_KEY['Refresh_token']==null && TOKEN_KEY['id'] == null  && TOKEN_KEY['email'] == null && TOKEN_KEY['password'] == null ){
            setIsAuth(false);
        }
        else{
            setIsAuth(true);
        }
    },[])
    //admin user rider dashboard path
    const history = useHistory();
    const Define_path = (e)=>{
        e.preventDefault();
        axios.get(`https://api.mahaboudhawholesale.com/user/user/${Cookies.get('id')}`)
        .then((res)=>{
            
            if(res.data.is_staff==false && res.data.is_driver==false)
                {
                    history.push('/user/dashboard');
                }
                else if(res.data.is_staff==false && res.data.is_driver==true){
                    history.push('/rider/dashboard')
                }
                else if(res.data.is_staff==true){
                    
                    history.push('/admin/dashboard')
                }
                else{
                    history.push('/login')
                }
        })
        .catch((err)=>{
           
        })
    }
    //end of the admin user dashboard

    //get request for user
    const[Fullname,setFullname] = useState([]);
    
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/user/${Cookies.get('id')}`)
        .then((res)=>{
            setFullname(res.data.first_name+" "+" "+res.data.last_name);
        })
    })
    //end of get request
    return(
        <>
       <div className='container-fluid p-4 position-relative header-index res-display'>
           <div className='container p-0'>
               <div className='col-9 p-0 ms-auto '>
                   <div className='d-flex'>
                       <div className=''>
                           <div className='d-flex'>
                               <i className='fa fa-envelope fs-13 header-icon-margin me-2 text-color'></i>
                               <p className='fs-13 text-white'>info@chitologistics.com</p>
                               <span className='ms-4 text-light fs-16 me-4'>|</span>
                           </div>
                       </div>
                       <div className=''>
                           <div className='d-flex'>
                               <i className='fa fa-clock-o fs-13 header-icon-margin me-2 text-color'></i>
                               <p className='fs-13 text-white'>Sun - Fri: 8 am - 5 pm, Saturday: CLOSED</p>
                               <span className='ms-4 text-light fs-16 me-4'>|</span>
                           </div>
                       </div>
                       <div className=''>
                           <div className='d-flex'>
                               <i className='fa fa-phone fs-13 header-icon-margin me-2 text-color'></i>
                               <p className='fs-13 text-white'>+977-01-1234567</p>
                               <span className='ms-4 text-light fs-16'>|</span>
                           </div>
                       </div>
                       {! isAuth==true ?
                       <>
                       <div className='pt-0'>
                           <i className='fa fa-sign-in fs-13 header-icon-margin me-2 ms-4 text-color'></i>
                           <Link to="/" className='fs-13 text-white text-decoration-none p-0'>Login</Link>
                           <span className='ms-4 text-light fs-16'>|</span>
                        </div>
                        <div className='pt-0'>
                           <i className='fa fa-sign-in fs-13 header-icon-margin me-2 ms-4 text-color'></i>
                           <Link to="/sign-up" className='fs-13 text-white text-decoration-none p-0'>Sign Up</Link>
                        </div>
                        </>
                        :
                        <>
                        <div className="dropdown">
                        <p className="mb-2 fs-13 text-white ms-3 fw-bolder"><i className="fa fa-user text-color fs-13 me-2"></i>{Fullname}</p>
                        <div class="dropdown-content p-2 py-4">
                             <a href="#" onClick={Define_path}><i className="fa fa-user dash-text-color pe-1 fm-22"></i>My Dashboard</a>
                             <a className="nav-link header-res mt-1" href="#" type="button" onClick={logout} id="navbarDropdown" role="button" data-toggle="tooltip" data-placement="bottom" title="Logout">
                                 <i className="fa fa-sign-out dash-text-color pe-1 fm-22"></i> Logout
                             </a>
                         </div>
                         </div>
                         </>
                        }
                   </div>
               </div> 
           </div>
           <header>
               <div className='container p-0'>
                   <div className='row m-0'>
                       <div className='col-2 p-0'>
                           <img src={Logo} className="w-100" alt="chito-logo" />
                       </div>
                       <div className='col p-3 text-start nav-bar-border'>
                           <nav>
                               <ul className='p-0 ps-3'>
                                   <li className='d-inline-block px-4'><Link to="/" className='text-decoration-none text-white fs-16'>Home</Link></li>
                                   <li className='d-inline-block px-4'><Link to="/" className='text-decoration-none text-white fs-16'>About</Link></li>
                                   <li className='d-inline-block px-4'><Link to="/" className='text-decoration-none text-white fs-16'>Services</Link></li>
                                   <li className='d-inline-block px-4'><Link to="/" className='text-decoration-none text-white fs-16'>News</Link></li>
                                   <li className='d-inline-block px-4'><Link to="/" className='text-decoration-none text-white fs-16'>Projects</Link></li>
                                   <li className='d-inline-block px-4'><Link to="/" className='text-decoration-none text-white fs-16'>Others</Link></li>
                               </ul>
                           </nav>
                       </div>
                       <div className='col-3 p-0'>
                            <ul className='p-0'>
                                <Link to="/home" className='text-decoration-none d-flex w-100 text-white'><p className='triangle-down'></p><p className='header-background px-3 pt-2 fs-16 header-padding'>Get a Quote</p></Link>
                            </ul>
                       </div>
                   </div>
               </div>
           </header>
       </div>
       <div className='d-none res-side-bar'>
      <div className='bg-white p-2 shadow-sm'>
          <div className='row m-0'>
              <div className='col p-0 pt-2 text-start'>
                  <img src={Logo} className='res-header-width' alt='logo'/>
              </div>
              <div className='col p-0 text-end'>
              <button className='btn btn-light' onClick={openModal}><i className='fa fa-bars'></i></button>
              </div>
          </div>
      </div>
      <Modal
            isOpen={modalIsOpen}
            onAfterOpen={afterOpenModal}
            onRequestClose={closeModal}
            contentLabel="Example Modal"
            className="border-0 rounded-0 modal-content2 dash-board-color"
          >
  
            <h2 ref={_subtitle => (subtitle = _subtitle)}><img src={Logo} className="w-100 px-2 py-2 pb-3 border-bottom border-2" alt="logo"/></h2>
            <i className="fa fa-times position-absolute text-dangers" onClick={closeModal}></i>
            <div className="pt-2 px-2">
                <Link to="/home" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 dash-active text-decoration side-bar"><i className="fa fa-home fs-5 text-center p-1 px-4"></i><br/>Home</Link>
                <Link to="/bulk/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-address-card fs-5 p-1 px-4"></i><br/>About</Link>
                <Link to="/my/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-first-order fs-5 p-1 px-4"></i><br/>Services</Link>
                <Link to="/my/tickets" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-newspaper-o fs-5 p-1 px-4"></i><br/>News</Link>
                <Link to="/my/profile" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-unlock fs-5 p-1 px-4"></i><br/>Projects</Link>
                <Link to="/my/profile" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-sign-in fs-5 p-1 px-4"></i><br/>Login</Link>
                <Link to="/my/profile" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-sign-out fs-5 p-1 px-4"></i><br/>Sign Up</Link>
                {/* <Link to="/dashboard/add-variation-options" className="text-white text-start text-center px-2 py-4 text-decoration-none fs-17 d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>My Cancelled Order</Link>
                <Link to="/dashboard/add-variation-value" className="text-white text-start side-padding text-decoration-none fs-17 d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>My Delivered Order</Link> */}
                {/* <Link to="/dashboard/add-data" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>Add Data</Link>
                <Link to="/dashboard/user-information" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-users p-1 px-3"></i>User Information</Link>
                <Link to="#" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-cog p-1 px-3"></i>Settings</Link> */}
            </div>
          </Modal>
    </div>
       </>
    )
}
export default Header;