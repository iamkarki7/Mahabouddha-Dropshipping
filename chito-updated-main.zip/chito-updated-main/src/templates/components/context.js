import React from 'react';
import Cookies from 'js-cookie';

    const Access_token = Cookies.get('access_token');
    const Refresh_token = Cookies.get('refresh_token');
    const TOKEN_KEY = {Access_token,Refresh_token};

export const UserContext = React.createContext({TOKEN_KEY})