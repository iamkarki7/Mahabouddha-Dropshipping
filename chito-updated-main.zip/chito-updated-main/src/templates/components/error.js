import React from 'react';


const Error_page = ()=>{
    return(
        <div className="new-colors" style={{height:'100vh'}}>
            <div className="mainbox">
                <div className="err">4</div>
                    <i className="fa fa-question-circle fa-spin error-icons"></i>
                <div className="err2">4</div>
                <div className="msg">Maybe this page moved? Got deleted? Is hiding out in quarantine? Never existed in the first place?<p>Let's go <a className="naya-hover" href="/">home</a> and try from there.</p></div>
            </div>
        </div>
    )
}
export default Error_page;