import React from 'react';
import Footer from './components/footer';
import Header from './components/header';
import Contact_page from './pages/contact-page';

const Contact = ()=>{
    return(
        <div>
            <Header/>
            <Contact_page/>
            <Footer/>
        </div>
    )
}
export default Contact;