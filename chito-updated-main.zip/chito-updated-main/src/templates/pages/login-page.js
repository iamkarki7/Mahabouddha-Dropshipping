import React, { useState, useEffect, useRef } from 'react';
import Logo from '../../static/image/logo.png';
import axiosInstance from '../components/axios';
import Cookies from 'js-cookie';
import { useHistory, useParams } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from '../../constants/baseURL';

const Login_page = () => {
    const [Showform, setShowfrom] = useState(true);

    return (
        <section className="container-fluid p-0 mt-5 pt-2 mb-5">
            <div className="">
                <div className="container p-0 res-padding">
                    <div className='col-lg-5 mb-5 p-0 m-auto'>
                        <div className='d-flex'>
                            <a href="https://mahaboudhawholesale.com/" className='text-decoration-none'><i className='fa fa-arrow-left me-3 header-background fs-14 rounded-pill text-white back-to-home'></i></a>
                            <p className='fs-16 pt-1'>Back to Home</p>
                        </div>
                    </div>
                    <div className="col-lg-5 p-lg-5 p-3 pt-4 m-auto bg-white shadow-sm rounded">
                        <div className="">
                            {Showform === true &&
                                <div>
                                    <div className="mb-4">
                                        <div className="col-5 p-0 m-auto">
                                            <img src={Logo} className="w-100" alt="logo-image" />
                                        </div>
                                        <div className="mt-4">
                                            {/* <h1 className="fs-5 fw-bolder pt-2">Chito Control Panel</h1> */}
                                            {/* <p className="text-secondary mt-4 fw-weight" onClick={() => setShowfrom(true)}>Login in to continue</p> */}
                                        </div>
                                    </div>
                                    <Login_new />
                                    <div className="text-start">
                                        <a href="/#forgot-password" className="fs-16 text-color1 fw-normal" onClick={() => setShowfrom("#forgot-password")}><i className="fa fa-lock me-2"></i>Forgot Password?</a>
                                    </div>
                                    <div className="mt-3 text-start">
                                        <a href="/sign-up" className="fs-16 text-color1 fw-normal text-decoration-none"><i className="fa fa-question-circle me-2"></i>Don't have an Account?</a>
                                    </div>
                                </div>
                            }
                            {Showform === '#forgot-password' &&
                                <div>
                                    <div className="mb-4">
                                        <div className="col-5 p-0 m-auto">
                                            <img src={Logo} className="w-100" alt="logo-image" />
                                        </div>
                                        <div className="mt-4">
                                            <h1 className="fs-5 fw-bolder pt-2">Chito Control Panel</h1>
                                            <p className="text-secondary mt-4 fw-weight">Email Verfication to continue</p>
                                        </div>
                                    </div>
                                    <Forgot_password />

                                </div>
                            }
                        </div>
                    </div>
                </div>
                <div className="">

                </div>

            </div>
        </section>
    )
}

const Login_new = () => {
    const [email, setUsername] = useState([]);
    const [password, setPassword] = useState([]);
    const history = useHistory();
    const [Message, setMessage] = useState(null);
    const [SuccessMessage, setSuccessMessage] = useState(null);

    const onUsername = e => setUsername(e.target.value);
    const onPassword = e => setPassword(e.target.value);

    const Clickbtn = (e) => {
        e.preventDefault();
        const loginData = ({ email, password });
        axios.post(`${BASE_URL}/user/login/`, loginData)
            .then((response) => {
                var a = response.data.tokens;
                var count = 0;
                var id = "";
                var refresh = "";
                var access = "";
                for (var i = 0; i < a.length; i++) {
                    if (a[i] === "'") {
                        i++;
                        count++;
                    }
                    if (count === 3 && count < 4) {
                        refresh = refresh + a[i]
                    }
                    if (count === 7 && count < 8) {
                        access = access + a[i]
                    }
                    if (count === 11 && count < 12) {
                        id = id + a[i]
                    }

                }

                Cookies.set('access_token', access);
                Cookies.set('refresh_token', refresh);
                Cookies.set('id', id);
                Cookies.set('email', email);

                axiosInstance.defaults.headers['Authorization'] =
                    'JWT ' + Cookies.get('access_token')

                setSuccessMessage('Successfully Logged In');
                setTimeout(() => {
                    if (response.data.is_admin === false && response.data.is_driver === false) {
                        Cookies.set('user_role', 'user')
                        window.location.href = '/user/dashboard'
                    }
                    else if (response.data.is_admin === false && response.data.is_driver === true) {
                        window.location.href = '/rider/dashboard'
                        Cookies.set('user_role', 'rider')
                    }
                    else if (response.data.is_admin === true && response.data.is_driver === false) {
                        window.location.href = '/admin/dashboard'
                        Cookies.set('user_role', 'admin')
                    }
                }, [3000])

            })

            .catch((err) => {
                setMessage('Email or Password doesnot Match.')
                setTimeout(() => {
                    setMessage(null)
                }, [3000])
            })
    }


    //remember password in 
    const [Remember, setRemember] = useState(false);

    const BtnRemember = (e) => {
        e.preventDefault();
        const New_email = Cookies.get('email');
        setRemember(true, ...[New_email]);
    }

    //end of remember password
    return (
        <form>
            <div>
                <div className="text-start">
                    <label className="pb-3 fw-weight fs-16 fw-bolder text-uppercase text-color1 fw-bolder" htmlFor="exampleCheck1">Email</label>
                    <input type="email" className="form-control1 rounded-0 py-2 input-form" onChange={onUsername} name="new_email" id="new_email" placeholder="Enter email" />
                </div>
                <div className="mt-3 text-start">
                    <label className="pb-3 fw-weight fs-16 fw-bolder text-uppercase text-color1 fw-bolder" htmlFor="exampleCheck1">Password</label>
                    <input type="password" className="form-control1 rounded-0 py-2 input-form" onChange={onPassword} name="new_password" id="new_password" placeholder="Enter Password" />
                </div>
                <div className="row m-0">
                    <div className="col p-0 text-start mt-4 pt-1">
                        {/* <div className="mb-3 form-check">
                                        <input type="checkbox" onClick={BtnRemember} className="form-check-input mt-1" id="exampleCheck1"/>
                                        <label className="form-check-label form-text text-dark" htmlFor="exampleCheck1">Remember Me</label>
                                    </div> */}
                    </div>
                    <div className="col p-0 text-end">
                        <button className="btn header-background mt-4 text-white border-0 rounded px-4 py-2 fw-bolder " onClick={Clickbtn}>Login</button>
                    </div>
                </div>
            </div>
            {Message === null ? null : <div className="bg-danger p-3 text-white rounded validate-message"><strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{Message}</strong></div>}
            {SuccessMessage === null ?
                null :
                <div >
                    <div className="bg-success p-3 text-white rounded validate-message"><strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessage}</strong></div>
                </div>
            }
        </form>
    )
}
const Forgot_password = () => {
    const [Emailverification, setEmailVerification] = useState([]);

    const onEmailverification = e => setEmailVerification(e.target.value);

    const Uid = useParams();

    const [SuccessMessage, setSuccessMessage] = useState();
    const [ErrorMessege, setErrorMessege] = useState();


    const Verify = e => {
        e.preventDefault();
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: { 'email': Emailverification, 'redirect_url': 'https://api.mahaboudhawholesale.com/forgot-password/reset-password' }
        };
        axiosInstance.post(`user/request-reset-email/`, requestOptions)
            .then((res) => {
                setSuccessMessage("Please Check Your Email");
            })
            .catch((err) => {
                setErrorMessege('Internet Connection Failed or Email Doesnot Exist.');
            })
    }
    return (
        <div className="">
            <div className="form-group">
                <div className="text-start">
                    <label className="pb-3 fw-weight form-text2 text-uppercase text-color1 fw-bolder text-color2" htmlFor="exampleCheck1">Email</label>
                    <input type="email" onChange={onEmailverification} className="form-control1 rounded-0 py-2 input-form" name="new_email" id="new_email" placeholder="Enter email" />
                </div>
                {SuccessMessage === undefined ?
                    null :
                    <div className="bg-success p-3 text-white rounded validate-message">
                        <strong className="fs-13"><i className="fa fa-check-circle me-2"></i>{SuccessMessage} </strong>
                    </div>
                }
                {ErrorMessege === undefined ?
                    null :
                    <div className="bg-success p-3 text-white rounded validate-message">
                        <strong className="fs-13"><i className="fa fa-check-circle me-2"></i>{ErrorMessege} </strong>
                    </div>
                }
                <div className="text-start">
                    <button className="btn header-background mt-4 text-white border-0 rounded px-4 py-2 fw-bolder " onClick={Verify}>Verify Email</button>
                </div>
            </div>
        </div>
    )
}
export default Login_page;
