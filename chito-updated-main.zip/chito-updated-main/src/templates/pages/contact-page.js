import React from 'react';
import { Link } from 'react-router-dom';
import Image from '../../static/image/background.jpg';

const Contact_page = ()=>{
    return(
        <section className="container-fluid p-0 pb-5">
            <div>
                <img src={Image} className="image-height w-100" alt="about_page_image" />
            </div>
            <div className="container p-0 res-padding">
                <div className="py-3 pt-5">
                    <h1 className="fs-4 fw-bolder text-start text-color">Contact Us</h1>
                </div>
                <div className="pb-5 mt-2">
                    <div className="row m-0">
                        <div className="col-lg-8 p-0 bg-white shadow-sm rounded">
                            <div className="p-1 pt-2 back-color">
                                <h1 className="fs-5 text-white fw-bold ps-3">Send Messege</h1>
                            </div>
                            <div className="p-3 mt-3">
                                <form>
                                    <div className="form-group mb-3">
                                        <input type="text" className="form-control1 border-2" placeholder="Enter Your First Name"/>
                                    </div>
                                    <div className="form-group mb-3">
                                        <input type="text" className="form-control1 border-2" placeholder="Enter Your Last Name"/>
                                    </div>
                                    <div className="form-group mb-3">
                                        <input type="text" className="form-control1 border-2" placeholder="Enter Your Email"/>
                                    </div>
                                    <div className="form-group mb-3">
                                        <input type="number" className="form-control1 border-2" placeholder="Enter Your Contact"/>
                                    </div>
                                    <div className="form-group mb-3">
                                        <textarea className="form-control1 border-2" placeholder="Enter Your Message" rows="6"></textarea>
                                    </div>
                                    <div className="text-end form-group">
                                        <button className="btn header-background fs-16 text-white w-100 rounded py-0 btn-background font-weight-bold form-control1 py-1">Send</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div className="col-lg p-0 ms-lg-5 mt-lg-0 mt-4">
                            <div className="bg-white shadow-sm rounded">
                                <div className="p-1 pt-2 back-color">
                                    <h1 className="fs-5 text-white fw-bold ps-3 text-start">Location</h1>
                                </div>
                                <div className="d-flex pt-2 pb-0 border-bottom border-2 ps-3 mb-0">
                                    <i className="fa fa-map-marker text-color fs-5 mt-1"></i>
                                    <p className="fs-6 ms-2 text-decoration-none fw-bolder text-secondary mt-1 text-color">Chandagriri, Kathmandu.</p>
                                </div>
                                <div className="d-flex pt-2 pb-0 border-bottom border-2 ps-3 mb-0">
                                    <i className="fa fa-phone text-color fs-5 mt-1"></i>
                                    <p className="fs-6 ms-2 text-decoration-none fw-bolder text-secondary mt-1 text-color">9845702183, 9845702183</p>
                                </div>
                                <div className="d-flex pt-2 pb-0 border-bottom border-2 ps-3 mb-0">
                                    <i className="fa fa-envelope text-color fs-5 mt-1"></i>
                                    <p className="fs-6 ms-2 text-decoration-none fw-bolder text-secondary mt-1 text-color">info@xito.com</p>
                                </div>
                                <div className="d-flex pt-2 pb-2 border-bottom border-2 ps-3 mb-0">
                                    <h1 className="fs-16 pt-1 pb-0"><a href="" className=" text-decoration-none text-color"><i className="fa fa-facebook-square fs-5"></i></a></h1>
                                    <h1 className="fs-16 pt-1 pb-0"><a href="" className=" text-decoration-none text-color"><i className="fa fa-instagram fs-5 ms-2"></i></a></h1>
                                    <h1 className="fs-16 pt-1 pb-0"><a href="" className=" text-decoration-none text-color"><i className="fa fa-youtube-square fs-5 ms-2"></i></a></h1>
                                    <h1 className="fs-16 pt-1 pb-0"><a href="" className=" text-decoration-none text-color"><i className="fa fa-twitter-square fs-5 ms-2"></i></a></h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className=" width-mar p-0 col-md p-0 res-height text-start">
                    <div id="googlemaps-canvas" className="maps-height" width="100%"><iframe height="100%" width="100%" className="w-100 border-0" frameborder="0" src="https://www.google.com/maps/embed/v1/search?q=kuleshowor&key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"></iframe>
                    </div>
                    <a className="codefor-googlemap text-start" href="https://www.embed-map.com" id="authorizemap-data">https://www.embed-map.com</a>
                </div>
            </div>
        </section>
    )
}
export default Contact_page;