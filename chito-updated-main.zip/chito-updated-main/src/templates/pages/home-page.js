import axios from 'axios';
import React, { useEffect, useState } from 'react';
// import Tilt from 'react-tilt';
import Image from '../../static/image/blog.jpg';
import Modal from 'react-modal';
import Slider from '../../static/image/truck.png';
import SliderNew from '../../static/image/slidernew.jpg';
import Plane from '../../static/image/plane.png';
import Criuse from '../../static/image/cruise.png';
import Shipped from '../../static/image/shipped.png';
import Home from '../../static/image/home.png';
import Package from '../../static/image/package.png';
import WareHousing from '../../static/image/warehouse.png';
import Truck1 from '../../static/image/truck1.png';
import Ship1 from '../../static/image/ship1.png';
import ReactDOM from "react-dom";
import { useGoogleMap, useMap, useMapMarker } from "../components/maps";
import { useRef } from "react";
const API_KEY = 'AIzaSyD57c_hX594KCuFgYj_wp5YTsUO53U4Y34';

const Home_Page = ()=>{
    const [Tracker,setTracker] = useState([]);
    const [TrackerValue,setTrackerValue] = useState([]);

    const onTracker = e => setTracker(e.target.value);

// react modal
var subtitle;
const [modalIsOpen,setIsOpen] = React.useState(false);
function openModal(e) {
  setIsOpen(true);
  e.preventDefault();
    axios.get(`https://api.mahaboudhawholesale.com/order/orders/?OrderNumber=${Tracker}`)
    .then((res)=>{
        if(res.data.length==1)
        {
        setTrackerValue(res.data[0].status.status_name);
        }
    })
    .catch((err)=>{
        
    })
}

function afterOpenModal() {
  // references are now sync'd and can be accessed.
  subtitle.style.color = '#f00';
}

function closeModal(){
  setIsOpen(false);
}


    return(
        <section className='container-fluid p-0 '>
           <div className='position-relative new-slider-position res-display'>
                <div className='new-images'>
                    <div className='images-background'></div>
                </div>
                <div className='position-relative images-sides res-display'>
                    <img src={Slider} className='w-100 me-auto' alt="slider-1" />
                </div>
           </div>
           <div className='container p-0 res-padding'>
               <div className='services-specialise'>
                   <p className='text-color fs-16 fm-11'>WE SPECIALISE IN THE TRANSPORTATION</p>
                   <h1 className='text-dark fs-1 fw-bolder mt-1 fm-22'>Specialist Logistics Services</h1>
               </div>
               <div className='row m-0 mt-5'>
                   <div className='col-lg p-0 bg-white shadow-sm text-start card-border'>
                       <div className='position-absolute '>
                           <img src={Plane} className="w-25 new-opacity" alt="plane" />
                       </div>
                       <div className='p-4 '>
                           <div className='pt-3'>
                                <img src={Plane} className="w-25" alt="plane" />
                           </div>
                           <div className='pt-5 pb-5 card-margin'>
                               
                               <h1 className='fs-20 fw-bolder'><span className='h1-border pt-4'>Air</span> Freight</h1>
                               <p className='fs-14 mt-4 text-justify'>Denouncing pleasure praising pain was born and we will give you a account of the anyone who loves</p>
                           </div>
                           <div className='position-absolute btn-left'>
                               <button className='btn btn-info rounded-0 border-0 text-white py-3 fs-14 fw-bolder px-5 new-btn-padding'>Read More<i class="fa fa-arrow-right ms-2"></i></button>
                           </div>
                       </div>
                   </div>
                   <div className='col-lg p-0 ms-lg-4 bg-white shadow-sm text-start card-border mt-lg-0 mt-5 pt-4'>
                    <div className='position-absolute '>
                           <img src={Criuse} className="w-25 new-opacity" alt="plane" />
                       </div>
                       <div className='p-4 '>
                           <div className='pt-3'>
                                <img src={Criuse} className="w-25" alt="plane" />
                           </div>
                           <div className='pt-4 pb-5 card-margin'>
                               
                               <h1 className='fs-20 fw-bolder pt-1'><span className='h1-border pt-4'>Express</span> Service</h1>
                               <p className='fs-14 mt-3 text-justify'>Denouncing pleasure praising pain was born and we will give you a account of the anyone who loves</p>
                           </div>
                           <div className='position-absolute btn-left1'>
                               <button className='btn btn-info rounded-0 border-0 text-white py-3 fs-14 fw-bolder px-5 new-btn-padding'>Read More<i class="fa fa-arrow-right ms-2"></i></button>
                           </div>
                       </div>
                   </div>
                   <div className='col-lg p-0 ms-lg-4 bg-white shadow-sm text-start card-border mt-lg-0 mt-5'>
                    <div className='position-absolute '>
                           <img src={Shipped} className="icon-width new-opacity" alt="plane" />
                       </div>
                       <div className='p-4 '>
                           <div className='pt-3'>
                                <img src={Shipped} className="w-25" alt="plane" />
                           </div>
                           <div className='pt-5 pb-5 card-margin'>
                               
                               <h1 className='fs-20 fw-bolder pt-1'><span className='h1-border pt-4'>Road</span> Freight</h1>
                               <p className='fs-14 mt-3 text-justify'>Denouncing pleasure praising pain was born and we will give you a account of the anyone who loves</p>
                           </div>
                           <div className='position-absolute btn-left2'>
                               <button className='btn btn-info rounded-0 border-0 text-white py-3 fs-14 fw-bolder px-5 new-btn-padding'>Read More<i class="fa fa-arrow-right ms-2"></i></button>
                           </div>
                       </div>
                   </div>
                   <div className='col-lg p-0 ms-lg-4 bg-white shadow-sm text-start card-border mt-lg-0 mt-5'>
                    <div className='position-absolute '>
                           <img src={Home} className="icon-width new-opacity" alt="plane" />
                       </div>
                       <div className='p-4 '>
                           <div className='pt-3'>
                                <img src={Home} className="w-25" alt="plane" />
                           </div>
                           <div className='pt-5 pb-5 card-margin'>
                               
                               <h1 className='fs-20 fw-bolder pt-1'><span className='h1-border pt-4'>Contract</span> Freight</h1>
                               <p className='fs-14 mt-3 text-justify'>Denouncing pleasure praising pain was born and we will give you a account of the anyone who loves</p>
                           </div>
                           <div className='position-absolute btn-left3'>
                               <button className='btn btn-info rounded-0 border-0 text-white py-3 fs-14 fw-bolder px-5 new-btn-padding'>Read More<i class="fa fa-arrow-right ms-2"></i></button>
                           </div>
                       </div>
                   </div>
               </div>
               <div className='mt-5 pt-5'>
                   <div className='row m-0 mt-5'>
                       <div className='col-lg-5 p-0 text-start'>
                           <div>
                                <h1 className='fs-2 fm-22'><span className='h1-border pt-4'>WHAT</span> MAKES US SPECIAL?</h1>
                                <p className='mt-5 text-secondary fs-13'>Over 42,000 dedicated employees, working in 17 regional clusters around the globe, deliver operational excellence.</p>
                           </div>
                           <div className='row m-0 mt-5'>
                               <div className='col p-0'>
                                   <div className='row m-0'>
                                       <div className='col-3 p-0'>
                                           <img src={Package} className="w-100" alt="plane"/>
                                       </div>
                                       <div className='col-2'></div>
                                       <div className='col p-0 pt-lg-3'>
                                           <p className='fs-15 fw-bolder fm-11'>PACKAGING AND STORAGE</p>
                                       </div>
                                   </div>
                               </div>
                               <div className='col p-0 ms-2'>
                                   <div className='row m-0'>
                                       <div className='col-3 p-0'>
                                           <img src={WareHousing} className="w-100" alt="plane"/>
                                       </div>
                                       <div className='col-2'></div>
                                       <div className='col p-0 pt-lg-3'>
                                           <p className='fs-15 fw-bolder fm-11'>EXPRESS SERVICE</p>
                                       </div>
                                   </div>
                               </div>
                           </div>
                           <div className='row m-0 mt-5'>
                               <div className='col p-0'>
                                   <div className='row m-0'>
                                       <div className='col-3 p-0'>
                                           <img src={Truck1} className="w-100" alt="plane"/>
                                       </div>
                                       <div className='col-2'></div>
                                       <div className='col p-0 pt-lg-3'>
                                           <p className='fs-15 fw-bolder fm-11'>GROUND TRANSPORT</p>
                                       </div>
                                   </div>
                               </div>
                               <div className='col p-0 ms-2'>
                                   <div className='row m-0'>
                                       <div className='col-3 p-0'>
                                           <img src={Ship1} className="w-100" alt="plane"/>
                                       </div>
                                       <div className='col-2'></div>
                                       <div className='col p-0 pt-lg-3'>
                                           <p className='fs-15 fw-bolder fam-16 fm-11 '>LOGISTICS SERVICES</p>
                                       </div>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <div className='col-lg p-5 text-start dash-board-color ms-lg-4 mt-lg-0 mt-5'>
                           <div className='pt-lg-5'>
                               <h1 className='text-white fs-3 fm-18'>REQUEST A FREE QUOTE</h1>
                           </div>
                           <div className='mt-lg-5 mt-4'>
                               <div className='row m-0 '>
                                   <div className='col-lg p-0'>
                                        <div className="mb-3">
                                            <select className='form-control fs-13 fw-bolder border-0 rounded-0 new-form-height'>
                                                <option value={null}>Freight Type</option>
                                                <option >Road Transport</option>
                                                <option >Air Transport</option>
                                                <option >Sea Transport</option>
                                                <option >Warehousing</option>
                                            </select>
                                        </div>
                                        <div className="mb-3">
                                            <input type="text" placeholder='City to Departure' className="form-control fs-13 fw-bolder border-0 rounded-0 new-form-height" id="city"/>
                                        </div>
                                        <div class="mb-3">
                                            <input type="text" placeholder='Delivery City' className="form-control fs-13 fw-bolder border-0 rounded-0 new-form-height" id="delivery-city"/>
                                        </div>
                                        <div className="mb-3">
                                            <select className='form-control fs-13 fw-bolder border-0 rounded-0 new-form-height'>
                                                <option value={null}>Incoterms</option>
                                                <option >EXW</option>
                                                <option >FCA</option>
                                                <option >CPT</option>
                                                <option >CIP</option>
                                                <option >DAT</option>
                                            </select>
                                        </div>
                                        <div className="mb-3">
                                            <input type="text" placeholder='Total Gross Weight(K.G.)' className="form-control fs-13 fw-bolder border-0 rounded-0 new-form-height" id="total-weight"/>
                                        </div>
                                   </div>
                                   <div className='col-lg p-0 ms-lg-4'>
                                        <div className="mb-3">
                                            <input type="text" placeholder='Dimension' className="form-control fs-13 fw-bolder border-0 rounded-0 new-form-height" id="Dimension"/>
                                        </div>
                                        <div class="mb-3">
                                            <input type="email" placeholder='Email' className="form-control fs-13 fw-bolder border-0 rounded-0 new-form-height" id="Email"/>
                                        </div>
                                        <div class="mb-3">
                                            <textarea className='form-control rounded-0 border-0 fs-13 fw-bolder' cols="12" rows="4" placeholder="Message"></textarea>
                                        </div>
                                        <div className=''>
                                            <button className='btn btn-outline-info w-100 fs-14 rounded-pill text-white py-2 border-2 fw-bolder'>Submit <i class="fa fa-arrow-right ms-3"></i></button>
                                        </div>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <div className='mt-5 p-0'>
                   <div className=''>
                       <h1 className='text-color fs-3 pt-4'>Latest Blog</h1>
                   </div>
                   <div className='row m-0 mt-5'>
                       <div className='col-lg p-0'>
                           <div className=''>
                               <img src={SliderNew} className='w-100 rounded'/>
                           </div>
                           <div className='row m-0 py-2 pt-4 dotted-border'>
                               <div className='col p-0'>
                                   <p className='text-dark text-start fs-16 fpm-12'><i className='fa fa-calendar text-color me-3'></i>2 Oct 2019</p>
                               </div>
                               <div className='col p-0'>
                                    <p className='text-dark text-end fs-16 fpm-12'><i className='fa fa-comments-o text-color me-3'></i>0 Comments</p>
                               </div>
                           </div>
                           <div className='pt-4'>
                               <h1 className='fs-4 fw-bolder text-dark text-start'>How Will You Know Success When it Show Up Deliver Proper Product?</h1>
                               <p className='fs-13 fw-bolder text-start text-secondary pt-3'>Suspendisse euismod vestibulum nulla quis condimentum distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum The man, who is in ...</p>
                           </div>
                       </div>
                       <div className='col p-0 ms-lg-4 mt-lg-0 mt-4'>
                           <div className='row m-0 mb-4'>
                               <div className='col-lg-5 p-0'>
                                    <div className=''>
                                        <img src={SliderNew} className='w-100 rounded'/>
                                    </div>
                               </div>
                               <div className='col p-0 ms-lg-4'>
                               <div className='row m-0 pb-lg-1 py-lg-0 pt-lg-0 py-2 pt-4 dotted-border'>
                               <div className='col p-0'>
                                   <p className='text-dark text-start fs-16 fpm-12'><i className='fa fa-calendar text-color me-3'></i>2 Oct 2019</p>
                               </div>
                               <div className='col p-0'>
                                    <p className='text-dark text-end fs-16 fpm-12'><i className='fa fa-comments-o text-color me-3'></i>0 Comments</p>
                               </div>
                           </div>
                           <div className='pt-3'>
                               <h1 className='fs-5 fw-bolder text-dark text-start fm-22'>How Will You Know Success When it Show Up?</h1>
                               <p className='fs-12 fw-bolder text-start text-secondary pt-2 '>Suspendisse euismod vestibulum nulla quis condimentum distracted by the readable content of a page when looking at its layout.s...</p>
                           </div>
                               </div>
                           </div>
                           <div className='row m-0 mb-4 mt-lg-0 mt-4'>
                               <div className='col-lg-5 p-0'>
                                    <div className=''>
                                        <img src={SliderNew} className='w-100 rounded'/>
                                    </div>
                               </div>
                               <div className='col-lg p-0 ms-lg-4'>
                               <div className='row m-0 pb-lg-1 py-lg-0 pt-lg-0 py-2 pt-4 dotted-border'>
                               <div className='col p-0'>
                                   <p className='text-dark text-start fs-16 fpm-12'><i className='fa fa-calendar text-color me-3'></i>2 Oct 2019</p>
                               </div>
                               <div className='col p-0'>
                                    <p className='text-dark text-end fs-16 fpm-12'><i className='fa fa-comments-o text-color me-3'></i>0 Comments</p>
                               </div>
                           </div>
                           <div className='pt-3'>
                               <h1 className='fs-5 fw-bolder text-dark text-start'>How Will You Know Success When it Show Up?</h1>
                               <p className='fs-12 fw-bolder text-start text-secondary pt-2'>Suspendisse euismod vestibulum nulla quis condimentum distracted by the readable content of a page when looking at its layout.s...</p>
                           </div>
                               </div>
                           </div>
                           <div className='row m-0 mb-lg-4 '>
                               <div className='col-lg-5 p-0'>
                                    <div className=''>
                                        <img src={SliderNew} className='w-100 rounded'/>
                                    </div>
                               </div>
                               <div className='col p-0 ms-lg-4'>
                               <div className='row m-0 pb-lg-1 py-lg-0 pt-lg-0 py-2 pt-4 dotted-border'>
                               <div className='col p-0'>
                                   <p className='text-dark text-start fs-16 fpm-12'><i className='fa fa-calendar text-color me-3'></i>2 Oct 2019</p>
                               </div>
                               <div className='col p-0'>
                                    <p className='text-dark text-end fs-16 fpm-12'><i className='fa fa-comments-o text-color me-3'></i>0 Comments</p>
                               </div>
                           </div>
                           <div className='pt-3'>
                               <h1 className='fs-5 fw-bolder text-dark text-start'>How Will You Know Success When it Show Up?</h1>
                               <p className='fs-12 fw-bolder text-start text-secondary pt-2'>Suspendisse euismod vestibulum nulla quis condimentum distracted by the readable content of a page when looking at its layout.s...</p>
                           </div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
           <div>
               <Map_api/>
           </div>
        </section>
    )
}
const initialConfig = {
    zoom: 15,
    center: {
        lat: 27.700769,
        lng: 85.300140,
    }
  };
  
  const markers = [
    { lat: 27.700769, lng: 85.300140 },
  ];
const Map_api = ()=>{
    const googleMap = useGoogleMap(API_KEY);
  const mapContainerRef = useRef(null);
  const map = useMap({
    googleMap,
    mapContainerRef,
    initialConfig
  });
  useMapMarker({ markers, googleMap, map });
  return (
    <div
      style={{
        height: "100vh",
        width: "100%",
        marginTop: '35px',
        // marginBottom: '30px',
        height: '300px',
      }}
      title='Chito Logistics'
      ref={mapContainerRef}
    />
  );
}
export default Home_Page;