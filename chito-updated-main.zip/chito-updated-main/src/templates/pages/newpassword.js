import axios from 'axios';
import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import Logo from '../../static/image/logo.png';
import axiosInstance from '../components/axios';

const New_password = ()=>{
    const [NewPassword,setNewpassword] = useState();
    const [Confirmpassword,setConfirmpassword] = useState();
    const history = useHistory();

    const onNewpassword = e => setNewpassword(e.target.value);
    const onConfirmpassword = e => setConfirmpassword(e.target.value);
    var Url = window.location.href;
    var count=0;
    var uid="";
    var token = "";
    var count1 = 0;
    var count2 = 0;
 
    for(var i=0;i<Url.length;i++)
    {
        if(Url[i]=="=")
        {
            count = count+1;
            i=i+1;
        }
        if(count==3)
        {
            if(Url[i]=='&'){
                uid=uid;
                count1 = count1+1

            }
            else if(count1==1)
            {
                uid=uid;
            }
            else{
            uid = uid+Url[i];
            }
           
        }
        if(count==4)
        {
            if(Url[i]=='#')
            {
                count2=count2+1;
                if(Url[i+1]=='/')
                {
                    count2=count2+1;
                }
            }
            if(count2==0 || count2==1)
            {
                token=token+Url[i]
            }
            else{
                token=token;
            }
        }
    }
    const [SuccessMessage, setSuccessMessage] = useState([]);
    const [ErrorMessage,setErrorMessage] = useState([]);

    const ResetPassword = e =>{
        e.preventDefault();
        const Data = {NewPassword,Confirmpassword};
        if(NewPassword===Confirmpassword){
            const Post_req = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Methods':'*' },
                body: {'password':NewPassword,'uidb64':uid,'token':token},
            };
            
            axiosInstance.post('/user/password-reset-complete/',Post_req)
            .then((res)=>{
                
                setSuccessMessage('Password successfully changed');              
               setTimeout(() =>  history.push('/login')  , 5000);
            })
            .catch((err)=>{
                setErrorMessage('Password Must be 8 Char');
            })
        }
        else{
            setErrorMessage('Password Doesnot Match...');
        }
    } 
    return(
        <section className="container-fluid p-0 mt-5 pt-4">
            <div className="">
                <div className="container p-0 res-padding">
                    <div className="col-lg-5 p-lg-5 p-3 pt-4 m-auto bg-white shadow-sm rounded">
                        <div className="mb-4">
                            <div className="col-5 p-0 m-auto">
                                <img src={Logo} className="w-100" alt="logo-image" />
                            </div>
                            <div className="mt-4">
                                <h1 className="fs-5 fw-bolder">Chito Control Panel</h1>
                                <p className="text-secondary mt-1 fw-weight">Reset password to continue...</p>
                            </div>
                            <form>
                                <div className="text-start">
                                    <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">New Password</label>
                                    <input type="password" onChange={onNewpassword} className="form-control1 rounded-0 py-2 input-form" name="new_password" id="new_password" placeholder="Enter New Password" />
                                </div>
                                <div className="text-start mt-3">
                                    <label className="form-check-label form-text text-dark text-start mb-3" htmlFor="exampleCheck1">Confirm Password</label>
                                    <input type="password" onChange={onConfirmpassword} className="form-control1 rounded-0 py-2 input-form" name="confirm_password" id="confirm_password" placeholder="Enter Confirm Password" />
                                </div>
                                <div className="text-start">
                                    <button className="btn header-background mt-4 text-white border-0 rounded px-4 py-2 fw-bolder " onClick={ResetPassword}>Reset Password</button>
                                </div>
                                {!SuccessMessage ?
                        <div>
                    </div>:
                        <div className="bg-success p-3 text-white rounded validate-message">
                        <strong className="fs-13"><i className="fa fa-check-circle me-2"></i>{SuccessMessage} </strong>
                    </div>
                        }
                        {!ErrorMessage ?
                         <div className="bg-danger p-3 text-white rounded validate-message">
                         <strong className="fs-13"><i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessage} </strong>
                     </div>:
                        <div></div>
                        }
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
export default New_password;