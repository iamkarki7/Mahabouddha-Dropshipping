import React, { useEffect, useState } from 'react';
import Logo from '../../static/image/logo.png';
import axios from 'axios';
import Controls from '../../components/forms/controls/Controls';
import { Link, useHistory } from 'react-router-dom';
import {
    useGetLocationsQuery } from '../../services/slices/LocationSlice/locationSlice';


const Sign_up = () => {
    const [Email, setEmail] = useState([]);
    const [Phonenumber, setPhonenumber] = useState([]);
    const [address, setAddress] = useState("");
    const [Password, setPassword] = useState([]);
    const [C_password, setC_password] = useState([]);
    const [Firstname, setFirstname] = useState([]);
    const [Lastname, setLastname] = useState([]);
    const [Mobileno, setMobileno] = useState([]);
    const [CompanyEmail, setCompanyEmail] = useState([]);
    const [Message, setMessage] = useState();
    const history = useHistory();
    const [SuccessMessage, setSuccessMessage] = useState();
    const [value, setValue] = useState(0);

    const onEmail = e => setEmail(e.target.value);
    const onPassword = e => setPassword(e.target.value);
    const onCpassword = e => setC_password(e.target.value);
    const onFirstname = e => setFirstname(e.target.value);
    const onLastname = e => setLastname(e.target.value);
    const onMobileon = e => setMobileno(e.target.value);

    var registerData = new FormData();
    // var companyData = new FormData();
    var useraddressData = new FormData();

    registerData.append('first_name', Firstname);
    registerData.append('last_name', Lastname);
    registerData.append('email', Email);
    registerData.append('contactno', Mobileno);
    registerData.append('password', Password);

    const locationPrice = useGetLocationsQuery();
    const LocationPrice = []
    locationPrice?.data?.ids.forEach((key) => {
        LocationPrice.push({ id: locationPrice.data.entities[key].address1, title: locationPrice.data.entities[key].address1 })
    })

    useEffect(() => {
        if (Password === null) {
            if (Password === C_password) {

                registerData.append('password', Password);

            }
            else {
                setMessage("Password does not match");
            }
        }
    }, []);

    if (Phonenumber) {
        registerData.append('company_phoneno', Phonenumber);
    }
    else {
        registerData.append('company_phoneno', "");
    }
    if (CompanyEmail) {
        registerData.append('company_email', CompanyEmail);
    }
    else {
        registerData.append('company_email', CompanyEmail);
    }

    if (value) {
        useraddressData.append('addressLine1', value);
    }
    if(address) {
        useraddressData.append('addressLine2', address);
    }

    const handleAddressSelect = (e) =>{
        setValue(e.target.value);
    }

    const handleAddressInput = (e) =>{
        setAddress(e.target.value);
    }

    const BtnClick = (e) => {
        e.preventDefault();
        registerData.append('is_driver', false);

        axios({
            method: "post",
            url: "https://api.mahaboudhawholesale.com/user/register/",
            data: registerData,
            headers: { "Content-Type": "multipart/form-data" },
        })
            .then(function (response) {
                //handle success
                useraddressData.append('user_id', response.data.id);
                axios({
                    method: "post",
                    url: "https://api.mahaboudhawholesale.com/user/useraddresses/",
                    data: useraddressData,
                    headers: { "Content-Type": "multipart/form-data" },
                })
                    .then(function (response) {
                        setSuccessMessage('Please Check Your Mail');
                        const timer = setInterval(() => history.push('/'), 3000);
                        return () => clearInterval(timer);
                    })
                    .catch(function (err) {

                        setMessage('You Forgot Put Your Address');
                    })
            })
            .catch(function (response) {
                //handle error
                setMessage('Some Fields are Missing or Email Already Exists.');
            });
    }

    return (
        <section className="container-fluid p-0 py-5">
            <div className="container p-0 res-padding">
                <div className='col-lg-8 mb-5 p-0 m-auto'>
                    <div className='d-flex'>
                        <a href="https://mahaboudhawholesale.com/" className='text-decoration-none'><i className='fa fa-arrow-left me-3 header-background fs-14 rounded-pill text-white back-to-home'></i></a>
                        <p className='fs-16 pt-1'>Back to Home</p>
                    </div>
                </div>
                <div className="col-lg-8 p-lg-5 p-3 py-3 m-auto bg-white shadow-sm rounded">
                    <div className="mb-4">
                        <div className="col-5 p-0 m-auto">
                            <img src={Logo} className="w-100" alt="logo-image" />
                        </div>
                        {/* <div className="mt-3">
                            <h1 className="fs-5 fw-bolder">Chito Control Panel</h1>
                            <p className="text-secondary mt-1 fw-weight">Sign up to continue...</p>
                        </div> */}
                    </div>
                    <form>
                        <div>
                            <div className="pb-0 mt-3 mt-lg-5">
                                <p className="text-start border-bottom pb-3 fs-4 form-text1 text-uppercase fw-bolder text-color1">Personal Details</p>
                            </div>
                            <div className="row m-0">
                                <div className="col p-0 text-start">
                                    <label className="pb-3 fw-weight form-text2 text-uppercase text-color1 fw-bolder ">First Name</label>
                                    <input type="text" onChange={onFirstname} className="form-control1 rounded-0 py-2 border-0 form-border" name="first_name" id="first_name" placeholder="Enter First Name" />
                                </div>
                                <div className="col p-0 ms-3 text-start">
                                    <label className="pb-3 fw-weight form-text2 text-uppercase text-color1 fw-bolder">Last Name</label>
                                    <input type="text" onChange={onLastname} className="form-control1 rounded-0 py-2 border-0 form-border" name="last_name" id="last_name" placeholder="Enter Last Name" />
                                </div>
                            </div>
                            <div className="row m-0">
                                <div className="col p-0 mt-3 text-start">
                                    <label className="pb-3 fw-weight form-text2 text-uppercase text-color1 fw-bolder">Email</label>
                                    <input type="email" onChange={onEmail} className="form-control1 rounded-0 py-2 border-0 form-border" name="new_email" id="new_email" placeholder="Enter Your Email" />
                                </div>
                                <div className="col p-0 ms-3 mt-3 text-start">
                                    <label className="pb-3 fw-weight form-text2 text-uppercase text-color1 fw-bolder">Mobile No.</label>
                                    <input type="number" onChange={onMobileon} className="form-control1 rounded-0 py-2 border-0 form-border" name="mobile_number" id="mobile_number" placeholder="Enter Mobile Number" />
                                </div>
                            </div>
                            <div className="row m-0">
                                <div className="col p-0 mt-3 text-start">
                                    <label className="pb-3 fw-weight form-text2 text-uppercase text-color1 fw-bolder">Password</label>
                                    <input type="password" onChange={onPassword} className="form-control1 rounded-0 py-2 border-0 form-border" name="new_password" id="new_password" placeholder="Enter Password" />
                                </div>

                                <div className="col p-0 mt-3 text-start ms-3">
                                    <label className="pb-3 fw-weight form-text2 text-uppercase text-color1 fw-bolder">Confirm Password</label>
                                    <input type="password" onChange={onCpassword} className="form-control1 rounded-0 py-2 border-0 form-border" name="c_password" id="c_password" placeholder="Enter Confirm Password" />
                                </div>

                            </div>
                            <div className="pb-0 mt-5">
                                <p className="text-start border-bottom pb-3 fs-4 form-text1 text-uppercase fw-bolder text-color1">Address Details</p>
                            </div>
                            <div className="row m-0 mb-3 mt-3">

                                <div className="col-lg p-0">
                                    <div className="form-group">
                                        <h1 className="fs-16 text-start mb-3 mt-2 form-text2 text-uppercase text-color1 fw-bolder">Your Location:</h1>
                                        <Controls.SearchAutoComplete
                                            name="addressLine1"
                                            label="Address"
                                            value={value}
                                            onChange={(e) => handleAddressSelect(e)}
                                            options={LocationPrice} />
                                    </div>
                                </div>
                                <div className="col-lg p-0">
                                    <div className="form-group">
                                        <h1 className="fs-16 text-start mb-3 mt-2 form-text2 text-uppercase text-color1 fw-bolder">Street Address:</h1>
                                        <input type="text" onChange={handleAddressInput} className="form-control1 rounded-0 py-2 border-0 form-border" name="street_address" id="street_address" placeholder="Street Address"/>
                                    </div>
                                </div>
                                <div className="col-lg p-0 ms-lg-3 text-start mt-4 pt-2">
                                    {/* <div className="form-group">
                                        <button className="btn back-color text-white px-3 border-0 py-2" onClick={() => setDest()}>Confirm</button>
                                    </div> */}
                                </div>
                            </div>
                            {Message === undefined ?
                                <div className="">
                                </div> :
                                <div className="bg-danger p-3 text-white rounded validate-message">
                                    <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{Message} </strong>
                                </div>
                            }
                            {SuccessMessage === undefined ?
                                <div className="">
                                </div> :
                                <div className="bg-success p-3 text-white rounded validate-message">
                                    <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessage} </strong>
                                </div>
                            }

                            <div className="row m-0">
                                <div className="col-lg p-0 text-start mt-4 ms-2">
                                    <Link to="/" className="fs-6 text-color1"><i class="fa fa-unlock-alt me-2"></i>Already have an account?</Link>
                                </div>
                                <div className="col-lg mt-lg-0 mt-3 p-0 text-end">
                                    <button className="btn header-background mt-4 text-white border-0 rounded px-4 py-2 fw-bolder" onClick={BtnClick}>Sign Up</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    {/* <div className="fixed-bottom bg-danger p-2">
                        <p className="text-white">{Message}</p>
                    </div> */}
                </div>
            </div>
        </section>
    )
}
export default Sign_up;