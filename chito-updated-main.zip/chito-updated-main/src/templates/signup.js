import React from 'react';
import Sign_up from './pages/sign-page';

const Sign = ()=>{
    return(
        <div>
            <Sign_up/>
        </div>
    )
}

export default Sign;