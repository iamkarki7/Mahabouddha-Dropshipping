import React from 'react';
import Footer from './components/footer';
import Header from './components/header';
import Home_Page from './pages/home-page';

const Home = ()=>{
    return(
        <div>
            <Header/>
            <Home_Page/>
            <Footer/>
        </div>
    )
}
export default Home;