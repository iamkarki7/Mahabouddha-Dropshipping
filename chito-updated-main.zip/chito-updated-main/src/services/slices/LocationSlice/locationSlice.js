import {
    createSelector,
    createEntityAdapter
} from "@reduxjs/toolkit";

import { apiSlice } from "../apiSlices";

const LocationsAdapter = createEntityAdapter()

const initialState = LocationsAdapter.getInitialState()

const URL = '/path/location-price/'

export const LocationSlice = apiSlice.injectEndpoints({
    endpoints: builder => ({
        getLocations: builder.query({
            query: () => URL,
            transformResponse: responseData => {
                return LocationsAdapter.setAll(initialState, responseData)
            },
            providesTags: (result, error, arg) =>
                [
                    { type: 'Locations', id: "LIST" },
                    ...result.ids.map(id => ({ type: 'Locations', id }))
                ]
        }),
        getLocationsPagination: builder.query({
            query: (page) => `path/location-price-pagination/?page=${page}`,
            providesTags: ['Locations']
        }),
        getLocationsPriceByLocation: builder.query({
            query: (locality) => {
                
            return{
             url: `${URL}?locality=${locality}`,
             method: 'GET'
            }
        },
            providesTags: ['Locations']
        }),
        getLocationById: builder.query({
            query: (id) => ({
                url: `${URL}${id}/`,
                method: 'GET',
            }),
            providesTags: ['Locations']
        }),
        addLocation: builder.mutation({
            query: (Location) => {

                return {
                    url: URL,
                    method: 'POST',
                    body: Location
                }
            },
            invalidatesTags: ['Locations']
        }),
        updateLocation: builder.mutation({

            query: (Location) => {


                return {
                    url: `${URL}${Location.get('id')}/`,
                    method: 'PATCH',
                    body: Location
                }
            },
            invalidatesTags: ['Locations']
        }),
        deleteLocation: builder.mutation({
            query: ({ id }) => {

                return {
                    url: `${URL}${id}/`,
                    method: 'DELETE',
                    body: id
                }
            },
            invalidatesTags: ['Locations']
        }),
    })
})

export const {
    useGetLocationsQuery,
    useGetLocationsPaginationQuery,
    useAddLocationMutation,
    useUpdateLocationMutation,
    useDeleteLocationMutation,
    useGetLocationByIdQuery,
    useGetLocationsPriceByLocationQuery
} = LocationSlice

// returns the query result object
export const selectLocationsResult = LocationSlice.endpoints.getLocations.select()

// Creates memoized selector
const selectLocationssData = createSelector(
    selectLocationsResult,
    LocationsResult => LocationsResult.data // normalized state object with ids & entities
)

//getSelectors creates these selectors and we rename them with aliases using destructuring
export const {
    selectAll: selectAllLocations,
    selectById: selectLocationById,
    selectIds: selectIds
    // Pass in a selector that returns the posts slice of state
} = LocationsAdapter.getSelectors(state => selectLocationssData(state) ?? initialState)
