import {
    createSelector,
    createEntityAdapter
} from "@reduxjs/toolkit";

import { apiSlice } from "../apiSlices";

const CategoriesAdapter = createEntityAdapter()

const initialState = CategoriesAdapter.getInitialState()

const URL = '/product/categories/'

export const CategorieSlice = apiSlice.injectEndpoints({
    endpoints: builder => ({
        getCategories: builder.query({
            query: () => URL,
            transformResponse: responseData => {
                return CategoriesAdapter.setAll(initialState, responseData)
            },
            providesTags: (result, error, arg) =>
                [
                    { type: 'Categories', id: "LIST" },
                    ...result.ids.map(id => ({ type: 'Categories', id }))
                ]
        }),
        getCategoriesPagination: builder.query({
            query: (page) => `/product/categories-pagination/?page=${page}`,
            providesTags: ['Categories']
        }),
        getCategorieById: builder.query({
            query: (id) => ({
                url: `${URL}${id}/`,
                method: 'GET',
            }),
            providesTags: ['Categories']
        }),
        addCategorie: builder.mutation({
            query: (Categorie) => {

                return {
                    url: URL,
                    method: 'POST',
                    body: Categorie
                }
            },
            invalidatesTags: ['Categories']
        }),
        updateCategorie: builder.mutation({

            query: (Categorie) => {


                return {
                    url: `${URL}${Categorie.get('id')}/`,
                    method: 'PATCH',
                    body: Categorie
                }
            },
            invalidatesTags: ['Categories']
        }),
        deleteCategorie: builder.mutation({
            query: ({ id }) => {

                return {
                    url: `${URL}${id}/`,
                    method: 'DELETE',
                    body: id
                }
            },
            invalidatesTags: ['Categories']
        }),
    })
})

export const {
    useGetCategoriesQuery,
    useAddCategorieMutation,
    useUpdateCategorieMutation,
    useDeleteCategorieMutation,
    useGetCategorieByIdQuery,
    useGetCategoriesPaginationQuery
} = CategorieSlice

// returns the query result object
export const selectCategoriesResult = CategorieSlice.endpoints.getCategories.select()

// Creates memoized selector
const selectCategoriessData = createSelector(
    selectCategoriesResult,
    CategoriesResult => CategoriesResult.data // normalized state object with ids & entities
)

//getSelectors creates these selectors and we rename them with aliases using destructuring
export const {
    selectAll: selectAllCategories,
    selectById: selectCategorieById,
    selectIds: selectIds
    // Pass in a selector that returns the posts slice of state
} = CategoriesAdapter.getSelectors(state => selectCategoriessData(state) ?? initialState)
