import {
    createSelector,
    createEntityAdapter
} from "@reduxjs/toolkit";

import { apiSlice } from "../apiSlices";

const PricingCriteriasAdapter = createEntityAdapter()

const initialState = PricingCriteriasAdapter.getInitialState()

const URL = '/order/new-pricing-criteria/'

export const PricingCriteriaSlice = apiSlice.injectEndpoints({
    endpoints: builder => ({
        getPricingCriterias: builder.query({
            query: () => URL,
            transformResponse: responseData => {
                return PricingCriteriasAdapter.setAll(initialState, responseData)
            },
            providesTags: (result, error, arg) =>
                [
                    { type: 'PricingCriterias', id: "LIST" },
                    ...result.ids.map(id => ({ type: 'PricingCriterias', id }))
                ]
        }),
        getPricingCriteriasPagination: builder.query({
            query: (page) => `/order/new-pricing-criteria-pagination/?page=${page}`,
            providesTags: ['PricingCriterias']
        }),
        getPricingCriteriaByPrice: builder.query({
            query: (price) => ({
                url: `${URL}?price_start__lte=${price}&price_end__gt=${price}`,
                method: 'GET',
            }),
            providesTags: ['PricingCriterias']
        }),
        getPricingCriteriaById: builder.query({
            query: (id) => ({
                url: `${URL}${id}/`,
                method: 'GET',
            }),
            providesTags: ['PricingCriterias']
        }),
        addPricingCriteria: builder.mutation({
            query: (PricingCriteria) => {

                return {
                    url: URL,
                    method: 'POST',
                    body: PricingCriteria
                }
            },
            invalidatesTags: ['PricingCriterias']
        }),
        updatePricingCriteria: builder.mutation({

            query: (PricingCriteria) => {


                return {
                    url: `${URL}${PricingCriteria.get('id')}/`,
                    method: 'PATCH',
                    body: PricingCriteria
                }
            },
            invalidatesTags: ['PricingCriterias']
        }),
        deletePricingCriteria: builder.mutation({
            query: ({ id }) => {

                return {
                    url: `${URL}${id}/`,
                    method: 'DELETE',
                    body: id
                }
            },
            invalidatesTags: ['PricingCriterias']
        }),
    })
})

export const {
    useGetPricingCriteriasQuery,
    useGetPricingCriteriasPaginationQuery,
    useAddPricingCriteriaMutation,
    useUpdatePricingCriteriaMutation,
    useDeletePricingCriteriaMutation,
    useGetPricingCriteriaByIdQuery,
    useGetPricingCriteriaByPriceQuery
} = PricingCriteriaSlice

// returns the query result object
export const selectPricingCriteriasResult = PricingCriteriaSlice.endpoints.getPricingCriterias.select()

// Creates memoized selector
const selectPricingCriteriassData = createSelector(
    selectPricingCriteriasResult,
    PricingCriteriasResult => PricingCriteriasResult.data // normalized state object with ids & entities
)

//getSelectors creates these selectors and we rename them with aliases using destructuring
export const {
    selectAll: selectAllPricingCriterias,
    selectById: selectPricingCriteriaById,
    selectIds: selectIds
    // Pass in a selector that returns the posts slice of state
} = PricingCriteriasAdapter.getSelectors(state => selectPricingCriteriassData(state) ?? initialState)
