import {
    createSelector,
    createEntityAdapter
} from "@reduxjs/toolkit";

import { apiSlice } from "../apiSlices";

const ProductsAdapter = createEntityAdapter()

const initialState = ProductsAdapter.getInitialState()

const URL = '/product/products/'

export const ProductSlice = apiSlice.injectEndpoints({
    endpoints: builder => ({
        getProducts: builder.query({
            query: () => URL,
            transformResponse: responseData => {
                return ProductsAdapter.setAll(initialState, responseData)
            },
            providesTags: (result, error, arg) =>
                [
                    { type: 'Products', id: "LIST" },
                    ...result.ids.map(id => ({ type: 'Products', id }))
                ]
        }),
        getProductsPagination: builder.query({
            query: (page) => `/product/products-pagination/?page=${page}`,
            providesTags: ['Products']
        }),
        getProductById: builder.query({
            query: (id) => ({
                url: `${URL}${id}/`,
                method: 'GET',
            }),
            providesTags: ['Products']
        }),
        addProduct: builder.mutation({
            query: (Product) => {

                return {
                    url: URL,
                    method: 'POST',
                    body: Product
                }
            },
            invalidatesTags: ['Products']
        }),
        updateProduct: builder.mutation({

            query: (Product) => {


                return {
                    url: `${URL}${Product.get('id')}/`,
                    method: 'PATCH',
                    body: Product
                }
            },
            invalidatesTags: ['Products']
        }),
        deleteProduct: builder.mutation({
            query: ({ id }) => {

                return {
                    url: `${URL}${id}/`,
                    method: 'DELETE',
                    body: id
                }
            },
            invalidatesTags: ['Products']
        }),
        searchProduct: builder.mutation({
            query: ( body ) => {

                return {
                    url: `${URL}search_products/`,
                    method: 'POST',
                    body: body
                }
            },
            invalidatesTags: ['Products']
        }),
    })
})

export const {
    useGetProductsQuery,
    useAddProductMutation,
    useUpdateProductMutation,
    useDeleteProductMutation,
    useGetProductByIdQuery,
    useGetProductsPaginationQuery,
    useSearchProductMutation
} = ProductSlice

// returns the query result object
export const selectProductsResult = ProductSlice.endpoints.getProducts.select()

// Creates memoized selector
const selectProductssData = createSelector(
    selectProductsResult,
    ProductsResult => ProductsResult.data // normalized state object with ids & entities
)

//getSelectors creates these selectors and we rename them with aliases using destructuring
export const {
    selectAll: selectAllProducts,
    selectById: selectProductById,
    selectIds: selectIds
    // Pass in a selector that returns the posts slice of state
} = ProductsAdapter.getSelectors(state => selectProductssData(state) ?? initialState)
