import React from 'react';
import Place_orderpage from './pages/my-order-page';
import Header from './components/header';
import User_sidebar from './components/side-bar';

const Place_order = ()=>{
    return(
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0">
                <User_sidebar/>
            </div>
            <div className="col-lg  p-0">
                <Header/>
                <Place_orderpage/>
            </div>
        </div>
    )
}
export default Place_order;