import React, { useState, useEffect } from 'react';
import "react-datepicker/dist/react-datepicker.css";
import axios from 'axios';
import Cookies from 'js-cookie';
import { v4 as uuidv4 } from 'uuid';
import axiosInstance from '../../templates/components/axios';
import { useParams } from 'react-router-dom';
import { useGetProductsQuery } from '../../services/slices/ProductSlice/productSlice';
import { useGetPricingCriteriaByPriceQuery } from '../../services/slices/PricingCriteria/pricingCriteriaSlice';
import { useGetLocationsPriceByLocationQuery, useGetLocationByIdQuery, useGetLocationsQuery } from '../../services/slices/LocationSlice/locationSlice';
import useDebounce from '../../components/forms/utils/debounce';
import { useHistory } from 'react-router-dom';
import Controls from '../../components/forms/controls/Controls';

//make bulk order component
const Myorder_update = () => {

    const id = useParams();

    var order_id = id['OrderNumber'];
    const products = useGetProductsQuery();
    const [options, setOptions] = useState([]);
    const [price, setPrice] = useState(0.0);
    const [ErrorMessage, setErrormessage] = useState(null);
    const [totalProductPrice, setTotalProductPrice] = useState(0.0);
    const [packagePrice, setPackagePrice] = useState(0.0);
    const [servicePrice, setServicePrice] = useState(0.0);
    const getPricingCriteria = useGetPricingCriteriaByPriceQuery(totalProductPrice)
    const [LocationType, setLocationType] = useState('');
    const [address, setAddress] = useState('');
    const [locationID, setLocationID] = useState(0);
    const [start, setStart] = useState(false)
    const [streetArea, setStreetArea] = useState('');
    const handleStreetArea = (e) => setStreetArea(e.target.value);

    const getLocationPrice = useGetLocationsPriceByLocationQuery(LocationType)
    const getLocationPriceID = useGetLocationByIdQuery(locationID)
    useEffect(()=>{
        if(getLocationPrice.status="fulfilled")
        {
            if(getLocationPrice?.data?.length>0)
            {
                setPrice(getLocationPrice?.data[0].price);
            }
        }
    },[getLocationPrice])

    useEffect(()=>{
        if(getLocationPriceID.status="fulfilled" && start)
        {
            setLocationType(getLocationPriceID?.data?.locality)
            setAddress(getLocationPrice?.data?.address1)
            setPrice(getLocationPriceID?.data?.price)
        }
    },[getLocationPriceID])
    const locationPrice = useGetLocationsQuery();

    const LocationPrice = []
    locationPrice?.data?.ids.forEach((key)=>{
        LocationPrice.push({id: key, title: locationPrice.data.entities[key].address1})
    })
    const [inputList, setInputList] = useState([{ productname: "", producttype: "", price: "" }]);
    const [CustomerName, setCustomerName] = useState([]);

    const [customerPhone, setcustomerPhone] = useState([]);

    const onCustomername = e => setCustomerName(e.target.value);
    const onsetCustomerPhone = e => setcustomerPhone(e.target.value)

    // const locationPrice = useGetLocationsPriceByLocationQuery(googleData.locality)

    useEffect(() => {

        if (getPricingCriteria?.data?.length > 0) {
            setPackagePrice(getPricingCriteria.data[0].package_price)
            setServicePrice(getPricingCriteria.data[0].service_price);
        }
    }, [getPricingCriteria])

    useEffect(() => {
        let productList = []
        if (products.data) {
            products.data.ids.map((key) => {
                productList.push({
                    id: products.data.entities[key].product_name + "#price" + parseInt(products.data.entities[key].product_price),
                    title: products.data.entities[key].product_name
                })
            })
        }
        setOptions(productList);
    }, [products])

    var orderForm = new FormData();

    


    useEffect(() => {
        axiosInstance.get(`https://api.mahaboudhawholesale.com/order/orders/?OrderNumber=${order_id}`)
            .then((res) => {
                setCustomerName(res?.data[0].customer_name)
                setcustomerPhone(res?.data[0].customer_mobile)
                setLocationType(res?.data[0].locality)
                setAddress(res?.data[0].address)
                setStreetArea(res?.data[0].adminArea1Long)
            })

        axios.get(`https://api.mahaboudhawholesale.com/order/product/?order_id=${order_id}`)
            .then((res) => {
                let productList = []
                res.data.forEach((key) => {
                    productList.push({
                        productname: key.product_name,
                        price: key.price,
                        cost_price: key.cost_price
                    })
                })
                setInputList(productList)
            })
    }, [order_id])

    // handle adding product data 
    const handleInputChange = (e, index) => {

        const { name, value } = e.target;
        const list = [...inputList];

        if (name === "productname") {
            let splitted = value.split("#price")
            list[index][name] = splitted[0]
            list[index]['cost_price'] = splitted[1]
        }
        else {
            list[index][name] = value
        }
        setInputList(list);
    };



    // handle click event of the Remove button
    const handleRemoveClick = index => {
        const list = [...inputList];
        list.splice(index, 1);
        setInputList(list);
    };

    useEffect(() => {
        let initialPrice = 0.0;
        inputList.map((key) => {
            if (key.price !== "" || key.price !== undefined)
                initialPrice += parseInt(key.price)
        })
        setTotalProductPrice(initialPrice);
    }, [useDebounce(inputList, 1000)])

    // handle click event of the Add button
    const handleAddClick = () => {
        setInputList([...inputList, { productname: "", producttype: "", price: "", status: "" }]);
    };

    const history = useHistory();
    
    const handleAddressSelect = (e) =>{
        setStart(true);
        setLocationID(e.target.value);
    }



    //dyanmic product data
    // const [myOrders,setOrders] = useState([]);
    const [SuccessMessage, setSuccessMessage] = useState(false);

    function order() {
        //handle success
        orderForm.append('customer_mobile', customerPhone);
        orderForm.append('customer_name', CustomerName);
        orderForm.append('total_packages', inputList.length);
        orderForm.append('assigned_price', parseFloat(price) + parseFloat(packagePrice) + parseFloat(servicePrice));
        orderForm.append('address1', address);
        orderForm.append('locality', LocationType);
        orderForm.append('adminArea1Long', streetArea);

        //adding data in order table
        axiosInstance.patch(
            `https://api.mahaboudhawholesale.com/order/orders/${order_id}/`,
            orderForm,
            { headers: { Authorization: Cookies.get('access_token') ? 'JWT ' + Cookies.get('access_token') : null, 'Content-Type': 'multipart/form-data' } })
            .then(res => {
                axiosInstance.post(
                    `https://api.mahaboudhawholesale.com/order/delete-products/`,
                    { 'order_id': order_id },
                    { headers: { Authorization: Cookies.get('access_token') ? 'JWT ' + Cookies.get('access_token') : null, 'Content-Type': 'application/json' } }
                ).then((res) => {
                    var a = [];
                    for (var i = 0; i < inputList.length; i++) {
                        var b = {};
                        b["order_id"] = order_id;
                        b["product_name"] = inputList[i].productname;
                        b["product_types"] = inputList[i].producttype;
                        b["created_by"] = parseInt(Cookies.get("id"));
                        b["price"] = parseInt(inputList[i].price);
                        b["cost_price"] = parseFloat(inputList[i].cost_price)
                        a.push(b);
                    }
                    //adding data in product table

                    axiosInstance.post("https://api.mahaboudhawholesale.com/order/product/", a)
                        .then(res => {
                            setSuccessMessage('Order Has Been Successfully Placed');
                            if (res.data) {
                                setTimeout(() => {
                                    history.push('/my/order')
                                    window.location.reload(true);
                                }, 2000);
                            } else {
                                setErrormessage('Your Product Detail is Missing')
                                setTimeout(() => {
                                    setErrormessage(null)
                                }, [3000])
                            }
                        })
                        .catch((err) => {
                            setErrormessage('Your Product Detail is Missing');
                            setTimeout(() => {
                                setErrormessage(null)
                            }, [3000])
                        })
                })
            })
            .catch((err) => {
                setErrormessage('Some Order Fields are Missing');
                setTimeout(() => {
                    setErrormessage(null)
                }, [3000])
            })
    }

    return (
        <div className="pt-4 p-3 dash-new-color">
            <div className="bg-white shadow-sm rounded p-4">
                <div className="row m-0 mb-3">
                    <div className="col-lg p-0 me-3">
                        <div className="form-group">
                            <div className='row m-0'>
                                <div className='col-1 p-0 pt-2'>
                                    <i className='fa fa-user'></i>
                                </div>
                                <div className='col p-0'>
                                    <input type="text" className="form-control1" placeholder="Enter Customer Name" defaultValue={CustomerName} onChange={onCustomername} />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg p-0 me-3 mt-lg-0 mt-3">
                        <div className="form-group">
                            <div className='row m-0'>
                                <div className='col-1 p-0 pt-2'>
                                    <i className='fa fa-phone'></i>
                                </div>
                                <div className='col p-0'>
                                    <input type="text" className="form-control1" placeholder=" Enter Customer Mobile No." defaultValue={customerPhone} onChange={onsetCustomerPhone} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div>
                    {inputList.map((x, i) => {
                        return (
                            <div className="row m-0 mt-4">
                                <div className="col-lg p-0 me-3">
                                    <h1 className="fs-16 text-start mb-3 form-text text-dark form-text text-dark">Product Name {i + 1}:</h1>
                                    <div className="row m-0">
                                        <div className='col-1 p-0 pt-2'>
                                            <i class="fa fa-product-hunt"></i>
                                        </div>
                                        <div className='col p-0'>
                                            {/* <input className="form-control1" name="productname" placeholder="Enter Product Name" value={x.productname} onChange={e => handleInputChange(e, i)} /> */}
                                            <Controls.SearchAutoComplete
                                                name="productname"
                                                label="Products"
                                                value={x.productname + '#price' + x.cost_price}
                                                onChange={(e) => handleInputChange(e, i)}
                                                options={options} />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg p-0 me-3 mt-lg-0 mt-3">
                                    <h1 className="fs-16 text-start mb-3 form-text text-dark">Price {i + 1}:</h1>
                                    <div className='row m-0'>
                                        <div className='col-1 p-0 pt-2'>
                                            <i class="fa fa-dollar"></i>
                                        </div>
                                        <div className='col p-0'>
                                            <input className="form-control1" name="price" placeholder="Enter Product Price" value={x.price} onChange={e => handleInputChange(e, i)} />
                                        </div>
                                    </div>
                                </div>

                                <div className="btn-box text-start mt-3">
                                    {inputList.length !== 1 && <button
                                        className="btn btn-danger btn-sm me-2"
                                        onClick={() => handleRemoveClick(i)}>Remove Product</button>}
                                    {inputList.length - 1 === i && <button className="btn back-color btn-sm text-white" onClick={handleAddClick}><i className="fa fa-plus me-2"></i>Add Product</button>}
                                </div>
                            </div>
                        );
                    })}
                </div>
                <div className="row m-0 mb-3 mt-4">
                    <div className="col-lg p-0 me-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Drop up Location:</h1>
                            <div className='row m-0'>
                                <div className='col-1 p-0 pt-2'>
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <div className='col p-0'>
                                    <div>
                                        {/* <input value={value} className="google-form" onChange={handleInput} disabled={!ready} placeholder="Please pick drop in location !!!" />
                                        {status === 'OK' && <ul className="google-location text-start bg-light shadow-sm p-2"><li>{renderSuggestions()}</li></ul>} */}
                                        <Controls.SearchAutoComplete
                                                name="price"
                                                label="Price"
                                                value={getLocationPrice?.data?.length>0?getLocationPrice?.data[0]?.id:""}
                                                onChange={(e) => handleAddressSelect(e)}
                                                options={LocationPrice} />
                                    </div>
                                    <div className='mt-4'>
                                        <input className="form-control1" name="adminArea1Long" placeholder="Enter Street Details" value={streetArea} onChange={e => handleStreetArea(e)} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-lg p-0 me-3'>
                        <div className='row m-0'>
                            <div className="col-lg p-0 me-3 mt-lg-0 mt-4">
                                <h1 className="fs-16 text-start mb-3 form-text text-dark">Delivery Price + Package Price + Service Price:</h1>
                                <h1 className="fs-16 text-start mb-3">
                                    NPR. {parseFloat(price) + parseFloat(packagePrice) + parseFloat(servicePrice)} (NPR.{price} + NPR.{packagePrice} + NPR.{servicePrice})
                                </h1>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-4 text-start">
                    <button className="btn btn-info text-white px-3 border-0 py-2" onClick={order}>Order Now</button>
                    {ErrorMessage === "" ?
                        <></> :
                        <div className="bg-danger p-3 text-white rounded validate-message">
                            <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessage} </strong>
                        </div>
                    }
                    {SuccessMessage === "" ?
                        <></> :
                        <div className="bg-success p-3 text-white rounded validate-message">
                            <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessage} </strong>
                        </div>
                    }
                </div>
            </div>
        </div>
    )
}

export default Myorder_update;