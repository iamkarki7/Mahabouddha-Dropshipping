import axios from 'axios';
import Cookies from 'js-cookie';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';


const Payment_requestpages = ()=>{
    var user_id = Cookies.get("id");
    const [AccountNumber, setaccountNumber] = useState("")
    const [AccountHolder, setAccountHolder] = useState("")
    const [BankName, setBankName] = useState("")
    const [BankBranch, setBankBranch] = useState("")
    const [Message,setMessage] = useState("")
    const [TicketType,setticketType] = useState("")
    const [SuccessMessage,setSuccessMessage] = useState();
    const [ErrorMessage, setErrorMessage] = useState();
    const history = useHistory();

    const onaccountNumber = (e) => setaccountNumber(e.target.value);
    const onaccountHolder = (e) => setAccountHolder(e.target.value);
    const  onbankName = (e) => setBankName(e.target.value);
    const onbankBranch = (e) => setBankBranch(e.target.value);
    const onmessage = (e) => setMessage(e.target.value);
    const onTickettype = (e) =>setticketType(e.target[e.target.selectedIndex].value);

    const myfunction = () =>{
        
            var data = {'user_id':user_id,'ticket_type':TicketType,'account_number':AccountNumber,'bank_name':BankName,'account_holder':AccountHolder,
                        'bank_branch':BankBranch,'message':Message}

        axios.post('https://api.mahaboudhawholesale.com/order/codtransfer/',data,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
        .then((res)=>{
            
            if(res.data['Error']){
                setErrorMessage(res.data['Error'])
            }else{
                setSuccessMessage('Payment Request Successfully Send.');
                setTimeout(()=>{
                    history.push('/my/tickets');
                },3000)
            }
        })
        .catch((err)=>{
            setErrorMessage('Transfer Doesnot Valid.') 
        })
    }
    return(
        <div className='col-lg-7 res-padding p-0 m-auto mt-5 mb-5'>
            <div className='bg-white p-4 shadow-sm'>
                <div>
                    <p className='fs-17 fw-bolder mb-3 pt-3'>Ticket Details</p>
                </div>
                <div className='row m-0'>
                    <div className='col-lg p-0'>
                        <div className='form-group text-start'>
                            <label className='fs-16 text-start mb-3 form-text text-dark'>Ticket Type</label>
                            <select className='form-control1' onChange={onTickettype}>
                                <option value={null}>Please select Ticket</option>
                                <option value="General">General</option>
                                <option value="COD transfer">COD Transfer</option>
                                <option value="Order Processing">Order Processing</option>
                                <option value="Return">Return</option>
                            </select>
                        </div>
                    </div>
                    <div className='col-lg p-0 ms-lg-3 mt-lg-0 mt-3'>
                        <div className='form-group text-start'>
                            <label className='fs-16 text-start mb-3 form-text text-dark'>Account Number</label>
                            <input className='form-control1' placeholder="Enter Your Account Number" onChange={onaccountNumber}/>
                        </div>
                    </div>
                </div>
                <div className='form-group text-start mt-3'>
                    <label className='fs-16 text-start mb-3 form-text text-dark'>Account Holder Name</label>
                    <input className='form-control1' placeholder="Enter Your Account Holder Name" onChange={onaccountHolder}/>
                </div>
                <div className='row m-0'>
                    <div className='col-lg p-0'>
                        <div className='form-group text-start mt-3'>
                            <label className='fs-16 text-start mb-3 form-text text-dark'>Bank Name</label>
                            <input className='form-control1' placeholder="Enter Your Bank Name" onChange={onbankName}/>
                        </div>
                    </div>
                    <div className='col-lg p-0 ms-lg-3'>
                        <div className='form-group text-start mt-3'>
                            <label className='fs-16 text-start mb-3 form-text text-dark'>Bank Branch</label>
                            <input className='form-control1' placeholder="Enter Your Bank Branch" onChange={onbankBranch}/>
                        </div>
                    </div>
                </div>
                <div className='form-group text-start mt-3'>
                    <label className='fs-16 text-start mb-3 form-text text-dark'>Messege</label>
                    <textarea className='w-100 new-text-area' cols="50" rows="6" placeholder="Enter Your Message" onChange={onmessage}></textarea>
                </div>
                <div className='text-end mt-4'>
                    <button className='border-0 header-background px-4 py-2 text-white rounded fs-14 fw-bolder' onClick={myfunction}>Submit</button>
                </div>
                {ErrorMessage===undefined?null:<div className="bg-danger p-3 text-white rounded validate-message"><strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessage}</strong></div>}
                        {SuccessMessage===undefined ?
                        null:
                        <div >
                            <div className="bg-success p-3 text-white rounded validate-message"><strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessage}</strong></div> 
                        </div>
                        }
            </div>
        </div>
    )
}
export default Payment_requestpages;