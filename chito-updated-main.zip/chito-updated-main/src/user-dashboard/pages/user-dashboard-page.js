import axios from 'axios';
import React, {useState,useEffect} from 'react';
import Cookies from 'js-cookie';
import { Doughnut,Pie } from 'react-chartjs-2';
import Chart from 'react-google-charts';
import {getToken1, onMessageListener} from "../../functions/firebaseinit";
import Notifications from "../../functions/notification";
import ReactNotificationComponent from "../../functions/reactNotification";
import axiosInstance from '../../templates/components/axios';

const User_dashboard = ()=>{

    const [show, setShow] = useState(false);
    const [notification, setNotification] = useState({ title: "", body: "" });
  
    
   
  
    onMessageListener()
      .then((payload) => {
        setShow(true);
        
        setNotification({
          title: payload.notification.title,
          body: payload.notification.body,
        });
        
      })
      .catch((err) => {});
    const [tokens, setTokens] = useState([]);

    const token = Cookies.get('refresh_token')
    useEffect(()=>{
        const getToken2 = async () =>{
            await getToken1().then((res)=>{
                let data = res.split(":")
                setTokens(data);
            })
        }
        getToken2();

    },[])
    useEffect(()=>{
        
        if(tokens.length!=0)
        {
        axiosInstance.post(`https://api.mahaboudhawholesale.com/devices/`,{'device_id': tokens[0], 'registration_id': tokens[1],
                                                                'user_id': Cookies.get('id'), 'type': 'web',
                                                                'active': true})
        .then((res)=>{
            
        })
    }
    },[tokens, token])

   
    const [remaining_return,setRemainingreturn] = useState(-1)
    const [stats, setStats] = useState({'total_order_number': -1, 'total_order_price': -1, 'pending_order_number': -1, 'pending_order_price': -1,
                                        'approved_order_number': -1, 'approved_order_price': -1, 'hold_order_number': -1, 'hold_order_price': -1,
                                        'checkedin_order_number': -1, 'checkedin_order_price': -1, 'delievered_order_number': -1, 'delievered_order_price': -1,
                                        'cancelled_order_number': -1, 'cancelled_order_price': -1,})

    const id = Cookies.get('id')
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/pendingcod/?seller_id=${id}`)
        .then((res)=>{
            
            if(res.data.length!=0)
            {
            setRemainingreturn(res.data[0].amount)
            }
            else{
                setRemainingreturn(0)
            }
       
        })
    },[id])
    useEffect(()=>{
        axios.post(`https://api.mahaboudhawholesale.com/order/stats/`,{'id': id})
        .then((res)=>{
            setStats(res.data);
        })
    },[id])
   
    return(
        <div className="p-3 pt-4 dash-new-color">
            <div className="row m-0">
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ">
                    <p className="pb-0 notification-text1">Total Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.total_order_number}</h1>
                </div>
                <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                    <p className="pb-0 notification-text1">Pending Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.pending_order_number}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Approved Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.approved_order_number}</h1>
                </div>
                <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Hold Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.hold_order_number}</h1>
                </div>
            </div>
            <div className="row m-0 mt-3">
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ">
                    <p className="pb-0 notification-text1">Checked In Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.checkedin_order_number}</h1>
                </div>
                <div className="col p-3 pt-4 text-start bg-white rounded shadow-sm ms-3">
                    <p className="pb-0 notification-text1">Delievered Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.delievered_order_number}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Cancelled Orders</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">{stats.cancelled_order_number}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Order Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.total_order_price}</h1>
                </div>
            </div>

            <div className="row m-0 mt-3">
               <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total pending value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.pending_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Approved Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.approved_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Hold In Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.hold_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Checked In Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.checkedin_order_price}</h1>
                </div>
            </div>
            <div className="row m-0 mt-3">
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Delivered Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.delievered_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                    <p className="pb-0 notification-text1">Total Cancelled Value</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {stats.cancelled_order_price}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start bg-white rounded shadow-sm ms-lg-3 mt-lg-0 mt-4">
                <p className="pb-0 notification-text1">Remaining Return</p>
                    <h1 className="text-color dash-margin fs-5 pt-2">NPR. {remaining_return}</h1>
                </div>
                <div className="col-lg col-6 p-3 pt-4 text-start  ms-lg-3 mt-lg-0 mt-4"></div>
            </div>
            {(stats.cancelled_order_number == -1 || stats.approved_order_number == -1 || stats.pending_order_number == -1 ||
            stats.checkedin_order_number == -1 || stats.delievered_order_number == -1 || stats.hold_order_number == -1 ||
            stats.cancelled_order_price == -1 || stats.approved_order_price == -1 || stats.pending_order_price == -1 ||
            stats.checkedin_order_price == -1 || stats.delievered_order_price == -1 || stats.hold_order_price == -1 ||
            stats.total_order_number == -1 || stats.total_order_price == -1) ? 
            <Mcall {...stats}/>:<Doughnut_com {...stats}/>}
        </div>
    )
}
const Doughnut_com =(props)=>{
    
    const [total,setTotal]  = useState({
        'Jan':{'del':0,'can':0},
        'Feb':{'del':0,'can':0},
        'Mar':{'del':0,'can':0},
        'Apr':{'del':0,'can':0},
        'May':{'del':0,'can':0},
        'Jun':{'del':0,'can':0},
        'Jul':{'del':0,'can':0},
        'Aug':{'del':0,'can':0},
        'Sep':{'del':0,'can':0},
        'Oct':{'del':0,'can':0},
        'Nov':{'del':0,'can':0},
        'Dec':{'del':0,'can':0},

    })
    
    const [Year,setYear] = useState(0)
    const onYear = (e) => setYear(e.target[e.target.selectedIndex].id)
    useEffect(()=>{
        axios.post(`https://api.mahaboudhawholesale.com/order/chart/`,{'year':Year,'user':'User','seller':Cookies.get('id')})
        .then((res)=>{
            var data = res.data
            if(data['Jan']==undefined)
            {
                data['Jan'] = {'can':0,'del':0}
               
            }
            if(data['Feb']==undefined)
            {
                data['Feb'] = {'can':0,'del':0}
              
            }
            if(data['Mar']==undefined)
            {
                data['Mar'] = {'can':0,'del':0}
          
            }
            if(data['Apr']==undefined)
            {
                data['Apr'] = {'can':0,'del':0}
              
            }
            if(data['May']==undefined)
            {
                data['May'] = {'can':0,'del':0}
            
            }
            if(data['Jun']==undefined)
            {
                data['Jun'] = {'can':0,'del':0}
            
            }
            if(data['Jul']==undefined)
            {
                data['Jul'] = {'can':0,'del':0}
             
            }
            if(data['Aug']==undefined)
            {
                data['Aug'] = {'can':0,'del':0}
               
            }
            if(data['Sep']==undefined)
            {
                data['Sep'] = {'can':0,'del':0}
               
            }
            if(data['Oct']==undefined)
            {
                data['Oct'] = {'can':0,'del':0}
            
            }
            if(data['Nov']==undefined)
            {
                data['Nov'] = {'can':0,'del':0}
              
            }
            if(data['Dec']==undefined)
            {
                data['Dec'] = {'can':0,'del':0}
               
            }
            else{
                
            }
            setTotal(data)  
        })
      

    },[Year])
    return(
        <>
        <div className="row m-0 mt-3">
            <div className="col-3 p-0">
            <Doughnut data={{
                labels:['Pending','Approved','Hold In','Checked In','Delivered','Cancelled'],
                datasets:[{
                    data: [parseInt(props.pending_order_price),parseInt(props.approved_order_price),parseInt(props.hold_order_price),
                            parseInt(props.checkedin_order_price),parseInt(props.delievered_order_price),parseInt(props.cancelled_order_price)],
                    backgroundColor:['#00f3ff','#8bf6ac','#ffeb00','#4b89fa','#23ba27','#fa271d'],
                }]
            }} reveal />
            </div>
            <div className="col-3 p-0">
            <Doughnut data={{
                labels:['Pending','Approved','Hold In','Checked In','Delivered','Cancelled'],
                datasets:[{
                    data: [parseInt(props.pending_order_number),parseInt(props.approved_order_number),parseInt(props.hold_order_number),
                        parseInt(props.checkedin_order_number),parseInt(props.delievered_order_number),parseInt(props.cancelled_order_number)],
                    backgroundColor:['#00f3ff','#8bf6ac','#ffeb00','#4b89fa','#23ba27','#fa271d'],
                }],
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutoutPercentage: 80,
                    tooltips: {
                      callbacks: {
                        label: function(tooltipItem, data) {
                          return data['labels'][tooltipItem['index']] + ': ' + data['datasets'][0]['data'][tooltipItem['index']] ;
                        }
                      }
                    }
                  }
            }}
             />
            </div>
           
            <div className='col-6 p-0'>
                <div className='col-3 p-0 mb-4'>
                <select className="form-control1" onChange={onYear}>
                                <option value="0" >Select Status</option>
                            
                                   
                                        <option id="2021">2021</option>
                                        <option id="2022">2022</option>
                                        <option id="2023">2023</option>
                                        <option id="2024">2024</option>
                                        <option id="2025">2025</option>
                                        <option id="2026">2026</option>
                                        <option id="2027">2027</option>
                                        <option id="2028">2028</option>
                                        <option id="2029">2029</option>
                                        <option id="2030">2030</option>
                                
                            
                             </select>

                </div>
                <div className='col-3 p-0'>
            <Chart
                width={'642px'}
                height={'300px'}
                chartType="Bar"
                loader={<div>Loading Chart</div>}
                data={[
                    ['Yearly Order Chart', 'Success Order', 'Cancelled Order'],
                    ['Jan', total['Jan']['del'], total['Jan']['can']],
                    ['Feb', total['Feb']['del'], total['Feb']['can']],
                    ['Mar', total['Mar']['del'], total['Mar']['can']],
                    ['Apr', total['Apr']['del'], total['Apr']['can']],
                    ['May', total['May']['del'], total['May']['can']],
                    ['Jun', total['Jun']['del'], total['Jun']['can']],
                    ['Jul', total['Jul']['del'], total['Jul']['can']],
                    ['Aug', total['Aug']['del'], total['Aug']['can']],
                    ['Sep', total['Sep']['del'], total['Sep']['can']],
                    ['Oct', total['Oct']['del'], total['Oct']['can']],
                    ['Nov', total['Nov']['del'], total['Nov']['can']],
                    ['Dec', total['Dec']['del'], total['Dec']['can']],
                ]}
                options={{
                    chart: {
                        title: 'User Order',
                        subtitle: 'Order of Every Month',
                    },
                }}
                rootProps={{ 'data-testid': '2' }}
            />
            </div>
            </div>
            </div>
        </>
    )
}
const Mcall =(props)=>{
    
    return(
        <>
        <div>hello</div></>
    )
}
export default User_dashboard;