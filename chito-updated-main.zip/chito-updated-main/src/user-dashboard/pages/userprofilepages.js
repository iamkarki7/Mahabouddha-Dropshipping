import React,{useState,useEffect} from 'react';
import axios from 'axios';
import Cookies, { set } from 'js-cookie';
import { v4 as uuidv4 } from 'uuid';
import axiosInstance from '../../templates/components/axios';
import usePlacesAutocomplete, { getGeocode, getLatLng } from 'use-places-autocomplete';
import useOnclickOutside from 'react-cool-onclickoutside';

//make bulk order component
const User_profilepage = ()=>{

    const [SuccessMessage,setSuccessMessage] = useState();
    const [ErrorMessage, setErrorMessage] = useState();
 
    const [firstName,setFirstName] = useState([]);
    const [lastName, setLastName] = useState([]);
    const [Email,setEmail] = useState([])
    const [Contact,setContact] = useState([]);
    const [companyDesignation,setCompanyDesignation] = useState([]);
    const [companyName,setCompanyName] = useState([]);
    const [companyPhone,setCompanyPhone] = useState([]);
    const [companyEmail,setCompanyEmail] = useState([]);
    const [companyAddress,setCompanyAddress] = useState([]);
    const onFirstName = (e) => setFirstName(e.target.value);
    const onLastName = (e) => setLastName(e.target.value);
    const onEmail = (e) => setEmail(e.target.value);
    const onContact = (e) => setContact(e.target.value);
    const onCompanyDesignation = (e) => setCompanyDesignation(e.target.value);
    const onCompanyName = (e) => setCompanyName(e.target.value);
    const onCompanyPhone = (e) => setCompanyPhone(e.target.value);
    const onCompanyEmail = (e) => setCompanyEmail(e.target.value);
    const onCompanyAddress = (e) => setCompanyAddress(e.target.value);
    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/user/${Cookies.get('id')}`)
        .then((res)=>{
          
            setFirstName(res.data.first_name);
            setLastName(res.data.last_name);
            setEmail(res.data.email);
            setContact(res.data.contactno);
            setCompanyDesignation(res.data.company_designation);
            setCompanyName(res.data.company_name);
            setCompanyPhone(res.data.company_phoneno);
            setCompanyEmail(res.data.company_email);
        })
        axios.get(`https://api.mahaboudhawholesale.com/user/useraddresses/?user_id=${Cookies.get('id')}`)
        .then((res)=>{
            setCompanyAddress(res.data[0].addressLine1);
        })
    },[])


    const [pickstreetPoints,setpickstreet] = useState({});
    const {
        ready,
        value,
        suggestions: { status, data },
        setValue,
        clearSuggestions
      } = usePlacesAutocomplete({
        requestOptions: { /* Define search scope here */ },
        debounce: 300
      });
     
        const registerRef = useOnclickOutside(() => {
          // When user clicks outside of the component, we can dismiss
          // the searched suggestions by calling this method
          clearSuggestions();
        });

      const handleInput = (e) => {
        // Update the keyword of the input element
        setValue(e.target.value);
      };

      const handleSelect =
      ({ description }) =>
      () => {
        // When user selects a place, we can replace the keyword without request data from API
        // by setting the second parameter to "false"
        setValue(description, false);
        clearSuggestions();
  
        // Get latitude and longitude via utility functions
        getGeocode({ address: description })
          .then((results) => getLatLng(results[0]))
          .then(({ lat, lng }) => {
       
            setpickstreet({"lat":lat,"long":lng});

          })
          .catch((error) => {
            
          });
      };

      const renderSuggestions = () =>
      data.map((suggestion) => {
        const {
          place_id,
          structured_formatting: { main_text, secondary_text },
        } = suggestion;
  
        return (
          <li key={place_id} onClick={handleSelect(suggestion)}>
            <strong>{main_text}</strong> <small>{secondary_text}</small>
          </li>
        );
      });

      function update(){
        var userdata = new FormData();
        var useraddresses = new FormData();
        userdata.append('first_name',firstName)
        userdata.append('last_name',lastName)
        userdata.append('email',Email)
        userdata.append('contactno',Contact);
        userdata.append('company_designation',companyDesignation)
        userdata.append('company_name',companyName);
        userdata.append('company_phoneno',companyPhone)
        userdata.append('company_email',companyEmail) 
    
        axios.patch(`https://api.mahaboudhawholesale.com/user/user/${Cookies.get('id')}/`,userdata,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'multipart/form-data'}})
        .then((res)=>{
          
  
        useraddresses.append('addressLine1',value)
        useraddresses.append('addressX',pickstreetPoints['lat'])
        useraddresses.append('addressY',pickstreetPoints['long'])
        })
        if(value!=null || value!="")
        {
        axios.get(`https://api.mahaboudhawholesale.com/user/useraddresses/?user_id=${Cookies.get('id')}`).then((res)=>{
        axios.patch(`https://api.mahaboudhawholesale.com/user/useraddresses/${res.data[0].id}/`,useraddresses,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'multipart/form-data'}})
        .then((res)=>{
           setSuccessMessage('Your Data Has Been Successfully Updated')
        })
        .catch((err)=>{
            setErrorMessage('Some Fields are Missing');
        })
    })
}

      
      }
    
    
    return(
        <div>
        <div className="pt-4 p-3">
            <div className="bg-white shadow-sm rounded p-4">
                <div className="row m-0 mb-3">
                    <div className="col-lg p-0 me-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">First Name: <sup className="star"> *</sup></h1>
                            <input type="text" className="form-control1" placeholder="Enter first name" defaultValue={firstName} onChange={onFirstName}  />
                        </div>
                    </div>
                    <div className="col-lg p-0 me-3 mt-lg-0 mt-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Last Name:</h1>
                            <input type="text" className="form-control1" placeholder=" Enter Last Name" defaultValue={lastName} onChange={onLastName} />
                        </div>
                    </div>
                    <div className="col-lg p-0 me-3 mt-lg-0 mt-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Email:</h1>
                            <input type="text" className="form-control1" placeholder=" Enter Email"  defaultValue={Email} onChange={onEmail}/>
                        </div>
                    </div>
                </div>   
                <div className="row m-0 mt-4">
                    <div className="col-lg p-0 me-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Contact:</h1>
                            <input type="text" className="form-control1" placeholder=" Enter Email"  defaultValue={Contact} onChange={onContact}/>
                        </div>
                    </div>
                    <div className="col-lg p-0 me-3 mt-lg-0 mt-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Company Designation:</h1>
                            <input type="text" className="form-control1" placeholder=" Enter designation"  defaultValue={companyDesignation} onChange={onCompanyDesignation}/>
                           
                        </div>
                    </div>
                    <div className="col-lg p-0 me-3 mt-lg-0 mt-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Company Name:</h1>
                            <input type="text" className="form-control1" placeholder="any remarks (optional)"  defaultValue={companyName} onChange={onCompanyName} />
                        </div>
                    </div>
                </div>

                <div className="row m-0 mt-4">
                    <div className="col-lg p-0 me-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Company Phone:</h1>
                            <input type="text" className="form-control1" placeholder="any remarks (optional)"  defaultValue={companyPhone} onChange={onCompanyPhone} />
                        </div>
                    </div>
                    <div className="col-lg p-0 me-3 mt-lg-0 mt-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Company Email:</h1>
                            <input type="text" className="form-control1" placeholder="any remarks (optional)"  defaultValue={companyEmail} onChange={onCompanyEmail} />
                        </div>
                    </div>
                    <div className="col-lg p-0 me-3 mt-lg-0 mt-3">
                        <div className="form-group">
                            <h1 className="fs-16 text-start mb-3 form-text text-dark">Company Address: <span className="fs-13">Current value: {companyAddress}</span></h1>
                            <div ref={registerRef}>
                                <input value={value} className="form-control1" defaultValue={companyAddress} onChange={handleInput} disabled={!ready} placeholder="Enter company address"/>
                                {status === 'OK' && <ul className="google-location text-start bg-light shadow-sm p-2"><li>{renderSuggestions()}</li></ul>}
                            </div>
                        </div>
                    </div>
                    </div>
                    {!ErrorMessage ?
                        <div className="">
                        </div>:
                        <div className="bg-danger p-3 text-white rounded validate-message">
                        <strong className="fs-13"> <i className="fa fa-exclamation-triangle me-2"></i>{ErrorMessage} </strong>
                    </div>
                        }
                        {!SuccessMessage ?
                        <div className="">
                        </div>:
                        <div className="bg-success p-3 text-white rounded validate-message">
                        <strong className="fs-13"> <i className="fa fa-check-circle me-2"></i>{SuccessMessage} </strong>
                    </div>
                        }
                    <div className="col p-0 text-start mt-4 pt-2">
                    <button type="button" className="btn back-color text-white" onClick={(e)=>update(e.preventDefault())}>Save changes</button>
                    </div>
          
               
                </div>
               
                    </div>
         
                    </div>

               
              
    )
}
export default User_profilepage;
