import axios from 'axios';
import React,{useState,useEffect} from 'react';
import Cookies from 'js-cookie';
import { Link } from 'react-router-dom';
import User_icon from '../../static/image/usericon.png'

const User_mainprofile = ()=>{
    const [UserData,setUserdata] = useState([]);

    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/user/user/${Cookies.get('id')}`)
        .then((res)=>{
            
            setUserdata(res.data);
        })
        .catch((err)=>{
            
        })
    },[])
    return(
        <div className='p-4 mt-4'>
            <div className='row m-0'>
                <div className='col-lg-4 p-0'>
                    <div className='p-4 bg-white rounded shadow-sm'>
                        <div className='w-25 m-auto'>
                            <img src={User_icon} className='w-100' alt='user-icon'/>
                        </div>
                        <div className=''>
                            <h1 className='fs-5 fw-bolder mt-4'>{UserData.first_name} {UserData.last_name}</h1>
                            <p className='fs-13 mt-3 mb-2'>{UserData.company_designation}</p>
                            <p className='fs-13 '>{UserData.company_name}</p>
                            <Link to="/my/profile/update" className='text-decoration-none mt-2'><button className='btn-outline border-0 text-white py-2 px-3 rounded fs-14 header-background'><i className='fa fa-edit me-2'></i>Edit</button></Link>
                        </div>
                    </div>
                </div>
                <div className='col-lg p-0 ms-lg-3 mt-lg-0 mt-3'>
                    <div className='bg-white p-4 rounded shadow-sm'>
                        <div className='row m-0 py-1 pt-4 border-bottom'>
                            <div className='col-3 p-0 text-start'>
                                <p className='fs-16 text-dark fm-12'>Full Name</p>
                            </div>
                            <div className='col p-0 text-start'>
                                <p className='fs-15 text-secondary fm-11'>{UserData.first_name} {UserData.last_name}</p>
                            </div>
                        </div>
                        <div className='row m-0 py-1 pt-4 border-bottom'>
                            <div className='col-3 p-0 text-start'>
                                <p className='fs-16 text-dark fm-12'>Email</p>
                            </div>
                            <div className='col p-0 text-start'>
                                <p className='fs-15 text-secondary fm-11'>{UserData.email}</p>
                            </div>
                        </div>
                        <div className='row m-0 py-1 pt-4 border-bottom'>
                            <div className='col-3 p-0 text-start'>
                                <p className='fs-16 text-dark fm-12'>Mobile No</p>
                            </div>
                            <div className='col p-0 text-start'>
                                <p className='fs-15 text-secondary fm-11'>{UserData.contactno}</p>
                            </div>
                        </div>
                        <div className='row m-0 py-1 pt-4 border-bottom'>
                            <div className='col-3 p-0 text-start'>
                                <p className='fs-16 text-dark fm-12'>Company Name</p>
                            </div>
                            <div className='col p-0 text-start'>
                                <p className='fs-15 text-secondary fm-11'>{UserData.company_name}</p>
                            </div>
                        </div>
                        <div className='row m-0 py-1 pt-4 border-bottom'>
                            <div className='col-3 p-0 text-start'>
                                <p className='fs-16 text-dark fm-12'>Company Number</p>
                            </div>
                            <div className='col p-0 text-start'>
                                <p className='fs-15 text-secondary fm-11'>{UserData.company_phoneno}</p>
                            </div>
                        </div>
                        <div className='row m-0 py-1 pt-4 border-bottom'>
                            <div className='col-3 p-0 text-start'>
                                <p className='fs-16 text-dark fm-12'>Company Email</p>
                            </div>
                            <div className='col p-0 text-start'>
                                <p className='fs-15 text-secondary fm-11'>{UserData.company_email}</p>
                            </div>
                        </div>
                        <div className='row m-0 py-1 pt-4'>
                            <div className='col-3 p-0 text-start'>
                                <p className='fs-16 text-dark fm-12'>Company Designation</p>
                            </div>
                            <div className='col p-0 text-start'>
                                <p className='fs-15 text-secondary fm-11'>{UserData.company_designation}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default User_mainprofile;