import React,{useRef,useState} from "react";
import { Link } from "react-router-dom";
import ReactToPrint from "react-to-print";
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import axios from "axios";
import Cookies from "js-cookie";

const Admin_allticket=  ()=>{
    let componentRef = useRef();
    const [status,setStatus] = useState("Active");
    

    const onTicketStatus = (e) => setStatus(e.target[e.target.selectedIndex].value)

    //exporting data to xls excel sheet

        //end of xls sheet
    return(
        <div className="p-3 pt-4 dash-new-color">
            <div className="text-start mt-3">
                <Link to="/payment/request" className="text-decoration-none back-color fs-16 text-white ms-2 px-4 py-2 font-weight-bold ">Payment Request</Link>
            </div>
            <div className="bg-white mt-5 rounded p-3 col-12 new-overflow">
                <div className="row m-0">
                    <div className="col p-0">
                    <div className="d-flex">
                        <button className="header-background btn-sm text-white border-0 px-3 py-2"><i className="fa fa-download me-2"></i>Export</button>
                        <ReactToPrint
                            trigger={() => <button className="header-background btn-sm text-white border-0 px-3 py-2 ms-3"><i className="fa fa-print me-2"></i>Print</button>}
                            content={() => componentRef}
                        />
                </div>
                </div>
                <div className="col-lg-2 p-0 mt-lg-0 mt-3">
                        <div className="form-group">
                        <select className="form-control fs-13 fw-bolder text-dark  form-height" onChange={onTicketStatus}>
                            {/* <option value={null}>Please Select Type</option> */}
                            <option value="Active">Active</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                </div>
                    </div>
                <ComponentToPrint status={status} ref={(el) => (componentRef = el)} />
            </div>
        </div>
    )
}

class ComponentToPrint extends React.Component {
    state = {
        cod: [],
        my_status: "",
        my_amount: 0,
        id: 0,
        ticket_status:"Active",
        ticket_type:"COD",

      }



    componentDidMount() {

        axios.get(`https://api.mahaboudhawholesale.com/order/codtransfer/?active=true&seller_id=${Cookies.get('id')}`)
        .then(res=>{
            // 
            const cod = res.data;
            this.setState({ cod });
          })
          

          axios.get(`https://api.mahaboudhawholesale.com/order/orders/?sellerId=4&status=5`)
        .then(res=>{
            
            // const cod = res.data;
            // this.setState({ cod });
          })

      }
      componentDidUpdate(prevProps, prevState) {
        
        
        if(prevState.ticket_status != this.props.status)
        {
        if(this.props.status == "Active")
        {
            axios.get(`https://api.mahaboudhawholesale.com/order/codtransfer/?active=true&seller_id=${Cookies.get('id')}`)
            .then(res=>{
                // 
                
                const cod = res.data;
                const ticket_status = "Active"
                this.setState({ticket_status})
                this.setState({ cod });


              })
        }
        else if(this.props.status == "Completed")
        {
            axios.get(`https://api.mahaboudhawholesale.com/order/codtransfer/?active=false&seller_id=${Cookies.get('id')}`)
            .then(res=>{
                
                const cod = res.data;
                const ticket_status = "Completed"
                this.setState({ticket_status})
                this.setState({ cod });

              })

        }
        else{
            axios.get(`https://api.mahaboudhawholesale.com/order/codtransfer/seller_id=${Cookies.get('id')}`)
            .then(res=>{
                
                const cod = res.data;
                const ticket_status = "Null";
                this.setState({ticket_status});
                this.setState({ cod });

              })
        }
    }

    }
      change = event =>{
          
          var a = event.target.value;
          var array = a.split(",");
          var my_amount = 0;
          if (array[1] == 'null')
          {
            my_amount = 0;
          }
          else{
            my_amount = parseInt(array[1]);
          }
          const my_status = array[0];
          const id = parseInt(array[2]);
          const ticket_type = array[3]
          this.setState({my_status});
          this.setState({my_amount});
          this.setState({id});
          this.setState({ticket_type})


      }
    // onReturnPrice = event =>{
    //     
    //     var my_amount = event.target.value
    //     this.setState({my_amount})
    // }
    // onChangeStatus = event =>{
    //     
    //     var my_status = event.target[event.target.selectedIndex].value;
    //     this.setState({my_status})
    // }
    mySave = () =>{
        
        
        
        
        
        var data = {'active':false}
        var pending_data = {'created_by':Cookies.get('id'),'cod':this.state.id,'seller_id':Cookies.get('id')}
        if(this.state.my_status == "Delievered")
        {
        if(this.state.ticket_type == "COD transfer")
        {
           axios.get(`https://api.mahaboudhawholesale.com/order/pendingcod/?seller_id=${Cookies.get('id')}`).then(res=>{
               
            if(res.data.length == 0)
            {
            axios.post(`https://api.mahaboudhawholesale.com/order/pendingcod/`,pending_data,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
            .then(res=>{
                
                axios.patch(`https://api.mahaboudhawholesale.com/order/codtransfer/${this.state.id}/`,data,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                .then(res=>{
                    // 
                    // const cod = res.data;
                    // this.setState({ cod });
                    if(res.data){
                        window.location.reload(true);
                    }else{
                        
                    }
            })
          })
        }
        else{
            axios.patch(`https://api.mahaboudhawholesale.com/order/pendingcod/${res.data[0].id}/`,pending_data,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
            .then(res=>{
                axios.patch(`https://api.mahaboudhawholesale.com/order/codtransfer/${this.state.id}/`,data,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                .then(res=>{
                    // 
                    // const cod = res.data;
                    // this.setState({ cod });
                    if(res.data){
                        window.location.reload(true);
                    }else{
                        
                    }
            })
          })
        }

           })

        }
    }
    else if(this.state.my_status == "Cancelled")
    {
        axios.patch(`https://api.mahaboudhawholesale.com/order/codtransfer/${this.state.id}/`,data,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
        .then(res=>{
            // 
            // const cod = res.data;
            // this.setState({ cod });
            window.location.reload(true);
    }) 
    }
    else{
        
    }
   
        // 
        // var data = {'return_amount':this.state.my_amount,'status':this.state.my_status,'updated_by':Cookies.get('id')}
        // axios.patch(`https://api.mahaboudhawholesale.com/order/codtransfer/${id}/`,data,{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
        // .then(res=>{
        //     // 
        //     const cod = res.data;
        //     this.setState({ cod });
        //   })
    }



    render() {
      return (
        <div>
          <table class="table text-start mt-3">
                    <thead className="border-bottom">
                        <tr>
                            <th scope="col" className="fs-14 fm-11">Ticket Type</th>
                            <th scope="col" className="fs-14 fm-11">Amount</th>
                            <th scope="col" className="fs-14 fm-11">Account Number</th>
                            <th scope="col" className="fs-14 fm-11">Bank Name</th>
                            <th scope="col" className="fs-14 fm-11">Account Holder Name</th>
                            <th scope="col" className="fs-14 fm-11">Bank Branch</th>
                            <th scope="col" className="fs-14 fm-11">Message</th>
                            <th scope="col" className="fs-14 fm-11">Ticket Time</th>
                            <th scope = "col" className = "fs-14 fm-11">Return Amount</th>
                            <th scope="col" className="fs-14 fm-11">Status</th>
                            <th scope = "col" className = "fs-14 fm-11">Remark</th>
                        </tr>
                    </thead>
                    <tbody>
                   { this.state.cod
            .map(co =>

                        <tr className="data-information">
                            <td scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>{co.ticket_type}</td>
                            <td className="fs-13 text-dark">NPR. {co.total_amount}</td>
                            <td className="fs-13 text-dark">{co.account_no}</td>
                            <td className="fs-13 text-dark">{co.bank_name}</td>
                            <td className="fs-13 text-dark">{co.account_holder_name}</td>
                            <td className=" fs-13 text-dark">{co.bank_branch}</td>
                            <td className=" fs-13 text-dark">{co.message}</td>
                            <td className="fs-13 text-dark">{co.ticket_time}</td>
                            <td className="fs-13 text-dark">NPR. {co.return_amount}</td>
                            {
                                this.props.status == "Completed" ?
                                <td className=" fs-13 text-success"><span className="border border-success px-2 py-1 rounded fs-11">{co.status}</span></td>:<td className=" fs-13 text-info"><span className="border border-info px-2 py-1 rounded fs-11">{co.status}</span></td>

                            }
                          {this.state.ticket_status == 'Active'?((co.status == "Delievered" || co.status == "Cancelled")?<td className="fs-13 text-dark"><button className="back-color border-0 text-white ms-2 px-2 py-1 rounded" onClick={this.change} value ={co.status + "," +co.return_amount+","+co.id+","+co.ticket_type} type="button" data-bs-toggle="modal" data-bs-target="#TicketModal">Edit</button></td>:<></>):<></>}
                        </tr>
    )}
                    </tbody>
                </table>
                <div className="modal fade" id="TicketModal" tabindex="-1" aria-labelledby="TicketModalLabel" aria-hidden="true">
                            <div className="modal-dialog">
                                <div className="modal-content">
                                    <div className="modal-body text-start">
                                        <div className="text-end">
                                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div className="col-11 m-auto p-3 py-4">
                                            <h1 className="fs-16 text-dark">Do you want to confirm this ticket??</h1>
                                            <div className="d-flex mt-3">
                                                <button className="btn btn-outline-info btn-sm" id="here" onClick = {this.mySave}>Yes</button>
                                                <button className="btn btn-outline-danger btn-sm ms-3">No</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
        </div>
      );
    }
  }
export default Admin_allticket;