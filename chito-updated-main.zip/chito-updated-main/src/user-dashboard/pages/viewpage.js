import React,{useState,useEffect} from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import ReactExport from "react-export-excel";


const View_page = ()=>{
    const OrderNumber = useParams();
    const [NewViews, setNewViews] = useState([{OrderNumber:'',status :{status_name:''},assigned_price:''}]);

   const Order = (OrderNumber["OrderNumber"]);
     useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?OrderNumber=${Order}`)
        .then(res=>{
            
            var arr=[]
            arr.push(res.data[0])
            setNewViews(arr);
            
        })
        .catch(err=>{
           
        })
    },[])

    const [inputList, setInputList] = useState([{id:"", productname: "", producttype: "",price:"" }]);

    useEffect(()=>{
        axios.get(`https://api.mahaboudhawholesale.com/order/product/?order_id=${Order}`)
        .then((res)=>{
            var arrs = [];
            for(var i=0;i<res.data.length;i++)
            {
            var dict = {id:res.data[i].id,productname:res.data[i].product_name,producttype:res.data[i].product_types,price:res.data[i].price,status:res.data[i].status}
            arrs.push(dict);
            }
            setInputList(arrs);
        })
     },[])
     // handle adding product data 
    const handleInputChange = (e, index) => {
        const { name, value } = e.target;
    
        const list = [...inputList];
    
        list[index][name] = value;
        setInputList(list);
      };
     
      // handle click event of the Remove button
      const handleRemoveClick = index => {
        const list = [...inputList];
        list.splice(index, 1);
        setInputList(list);
      };
      // handle click event of the Add button
      const handleAddClick = () => {
        setInputList([...inputList, {id:"", productname: "", producttype: "",price:"" ,status:""}]);
      };

    

    //converting data to excel sheet
    const ExcelFile = ReactExport.ExcelFile;
    const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
    const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

    var Order_Id = NewViews[0].OrderNumber;
    var customername = NewViews[0].customer_name;
    var customermobile = NewViews[0].customer_mobile;
    var statu_s = NewViews[0].status.status_name;
    var ordertype = NewViews[0].order_type;
    var Delivery_Price = NewViews[0].assigned_price;
    var Package_Price = NewViews[0].package_price;


    const data = [
        { OrderId: Order_Id, CutomerName: customername, CustomerMobile:customermobile, OrderType:ordertype ,Status:statu_s,Deliveryprice:Delivery_Price,Packageprice:Package_Price},
    ];

    const camelCase = (str) =>  {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    };

    const filterColumns = (data) => {
        // Get column names
        const columns = Object.keys(data[0]);

        // Remove by key (firstname)
        const filterColsByKey = columns.filter(c => c !== 'firstname');

        // OR use the below line instead of the above if you want to filter by index
        // columns.shift()

        return filterColsByKey // OR return columns
    };
    return(
        <div className="p-4 dash-new-color border-0">
            {/* <div className="text-end">
                <button className="btn back-color mb-4 px-3 text-white fw-bolder"><i class="fa fa-download me-2"></i>Download</button>
            </div> */}
            <ExcelFile filename="data" >
                <ExcelSheet data={data} name="data">
                    {
                        filterColumns(data).map((col)=> {
                            return <ExcelColumn  label={camelCase(col)} value={col}/>
                        })
                    }
                </ExcelSheet>
            </ExcelFile>
            <div className="mt-4 pt-2">
                      <div className="row m-0">
                          <div className="col bg-white shadow-sm p-3 text-start border-0 rounded">
                            <table className="table border new-width border-0">
                                <thead className='border-bottom'>
                                    <tr className="bg-white">
                                        <th scope="col " className="fs-14 fm-11">Details</th>
                                        <th scope="col " className="fs-14 fm-11">Data</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {NewViews.map(key=>(
                                        <tr className="data-information">
                                            <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Order Id</th>
                                            <td className="fs-13 text-dark">{key.OrderNumber}</td>
                                        </tr>
                                    ))}
                                    {NewViews.map(key=>(
                                        <tr className="data-information">
                                            <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i> Cutomer Name</th>
                                            <td className="fs-13 text-dark">{key.customer_name}</td>
                                        </tr>
                                    ))}
                                    {NewViews.map(key=>(
                                        <tr className="data-information">
                                            <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Customer Mobile</th>
                                            <td className="fs-13 text-dark">{key.customer_mobile}</td>
                                        </tr>
                                    ))}
                                    {NewViews.map(key=>(
                                        <tr className="data-information">
                                            <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Customer Location</th>
                                            <td className="fs-13 text-dark">{key.locality}</td>
                                        </tr>
                                    ))}
                                     {NewViews.map(key=>(
                                        <tr className="data-information">
                                            <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Customer Street</th>
                                            <td className="fs-13 text-dark">{key.adminArea1Long}</td>
                                        </tr>
                                    ))}
    
                                    {NewViews.map(key=>(
                                        <tr className="data-information">
                                            <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Status</th>
                                            <td className="fs-13 text-dark">{key.status.status_name}</td>
                                        </tr>
                                    ))}
                                    {NewViews.map(key=>(
                                        <tr className="data-information">
                                            <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Delivery Charge + Packaging Charge + Service Charge</th>
                                            <td className="fs-13 text-dark">NPR. {key.assigned_price}</td>
                                        </tr>
                                    ))}
                                    {NewViews.map(key=>(
                                        <tr className="data-information">
                                            <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Package Price</th>
                                            <td className="fs-13 text-dark">NPR. {key.package_price}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="col ms-lg-3 p-0">
                            <table className="table border new-width border-0 bg-white me-0 shadow-sm p-3 text-start rounded">
                                <thead className='border-bottom'>
                                    <tr className="bg-white">
                                        <th scope="col " className="fs-14 fm-11">Product Information</th>
                                        <th scope="col " className="fs-14 fm-11">Product Data</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {inputList.map((x, i) => {
                                        return(
                                            <tr className="data-information">
                                                <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Product Name {i+1}</th>
                                                <td className="fs-13 text-dark">{x.productname}</td>
                                            </tr>
                                        );
                                    })}
                         {inputList.map((x, i) => {
                        return(
                        <tr className="data-information">
                             <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>Product Price {i+1}</th>
                            <td className="fs-13 text-dark">NPR. {x.price}</td>
                        </tr>
                            );
                        })}
                </tbody>
            </table>
                          </div>
                      </div>
            </div>
        </div>
    )
}
export default View_page;