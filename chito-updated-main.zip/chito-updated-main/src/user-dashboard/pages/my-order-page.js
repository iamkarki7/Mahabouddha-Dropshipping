import axios from 'axios';
import Cookies from 'js-cookie';
import React, { useState } from 'react';
import { useEffect } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Link } from 'react-router-dom';
import HorizontalScroll from 'react-scroll-horizontal';
import dateconversion from '../../functions/dateconversion';
import ReactPaginate from "react-paginate";
import Pagination from '../components/pagination';
import Posts from '../components/posts';
import { ExportToExcel } from '../components/excelsheet';
import { changePaginationButton } from '../../functions/paginationButton';


const Place_orderpage = () => {

    const [approvedOrder, setApprovedOrder] = useState([]);
    const [holdOrder, setHoldOrder] = useState([]);
    const [checkedInOrder, setcheckedInOrder] = useState([]);
    const [deliveredOrder, setDeliveredOrder] = useState([]);
    const [cancelledOrder, setCancelledOrder] = useState([]);
    const [NewSwitch, setNewSwitch] = useState(false);
    const [NewSwitch1, setNewSwitch1] = useState(false);
    const [NewSwitch2, setNewSwitch2] = useState(false);
    const [pendingOrder, setPendingOrder] = useState([]);
    const [changeTime, setChangeTime] = useState([]);
    const [status, setStatus] = useState([]);
    const [pageID, setPageId] = useState(1);
    const [dataNo, setDataNo] = useState(-1);
    const [nextValue, setNextValue] = useState(1)
    const [buttonNo, setButtonNo] = useState([]);
    const [StatusValue, setStatusValue] = useState(1);


    var Seller_id = Cookies.get('id');


    //exporting data to excel sheet
    const [ExcelData, setExcelData] = useState([]);

    useEffect(() => {
        const ExcelNewData = () => {
            axios.get(`https://api.mahaboudhawholesale.com/order/orders/?sellerId=${Seller_id}`)
                .then((res) => {
                    setExcelData(res.data);
                })
                .catch((err) => {

                })
        }
        ExcelNewData();
    }, [])
    const fileName = 'allorderdata';
    const fileName1 = 'pending_order';
    const fileName2 = 'approved_order';
    const fileName3 = 'hold_order';
    const fileName4 = 'checked_in_order';
    const fileName5 = 'delivered_order';
    const fileName6 = 'cancelled_order';
    const [ExportedData, setExportedData] = useState([]);







    useEffect(() => {
        const ExcelNewData = () => {
            axios.get(`https://api.mahaboudhawholesale.com/order/orders/?seller_id=${Seller_id}`)
                .then((res) => {
                    setExcelData(res.data);
                })
                .catch((err) => {

                })
        }
        ExcelNewData();
    }, [])
    //end of excel sheet


    const onChangeTime = (e) => {

        if (e.target.value == "Custom") {
            setNewSwitch(true);
        }
        else {
            setNewSwitch(false)
        }
        setChangeTime(e.target.value);
        if (e.target.value == "Delivery Type") {
            setNewSwitch1(true);
        }
        else {
            setNewSwitch1(false);
        }
        if (e.target.value == "By Payment") {
            setNewSwitch2(true);
        }
        else {
            setNewSwitch2(false);
        }
    }

    useEffect(() => {
        if (dataNo != -1) {
            const buttonNo = changePaginationButton(dataNo, nextValue);
            setButtonNo(buttonNo.array);
            setNextValue(buttonNo.next);
            setPageId(buttonNo.defaultValue);
        }
    }, [nextValue, dataNo])


    const onButtonValue = (e, id) => {
        if (id === "Next") {
            setNextValue(nextValue + 1);
        }
        if (id === "Prev") {
            setNextValue(nextValue - 1);
        }
        setPageId(parseInt(id));
    }


    var id = Cookies.get('id');
    id = parseInt(id);
    var d = new Date();

    var today_fulldate = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()

    var last_year = new Date(new Date().setFullYear(new Date().getFullYear() - 1))
    var last_year_fulldate = last_year.getFullYear() + "-" + (last_year.getMonth() + 1) + "-" + last_year.getDate()
    var last_semiannual = new Date(new Date().setMonth(new Date().getMonth() - 6))
    var last_semiannual_fulldate = last_semiannual.getFullYear() + "-" + (last_semiannual.getMonth() + 1) + "-" + last_semiannual.getDate()
    var last_quarter = new Date(new Date().setMonth(new Date().getMonth() - 3))
    var last_quarter_fulldate = last_quarter.getFullYear() + "-" + (last_quarter.getMonth() + 1) + "-" + last_quarter.getDate()
    var last_month = new Date(new Date().setMonth(new Date().getMonth() - 1))
    var last_month_fulldate = last_month.getFullYear() + "-" + (last_month.getMonth() + 1) + "-" + last_month.getDate()
    var last_week = new Date(new Date().setDate(new Date().getDate() - 7))
    var last_week_fulldate = last_week.getFullYear() + "-" + (last_week.getMonth() + 1) + "-" + last_week.getDate()
    var tomorrow = new Date(new Date().setDate(new Date().getDate() + 1))
    var tomorrow_fulldate = tomorrow.getFullYear() + "-" + (tomorrow.getMonth() + 1) + "-" + tomorrow.getDate()

    var firstdate = "1960-01-01"

    const onchangeTime = (e) => setChangeTime(e.target.value);
    const [Formdate, setFormdate] = useState(new Date());
    const [Todate, setTodate] = useState(new Date());
    const [DeliveryType, setDeliveryType] = useState("")
    const [PaymentType, setPaymentType] = useState("")


    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [postsPerPage] = useState(10);

    const onFormdate = date => setFormdate(date);
    const onTodate = date => setTodate(date);

    const onDeliveryType = (e) => setDeliveryType(e.target[e.target.selectedIndex].value)
    const onPaymentType = (e) => setPaymentType(e.target[e.target.selectedIndex].value)

    var mydate1 = dateconversion(Formdate);
    var mydate2 = dateconversion(Todate)

    var first_date = firstdate
    var last_date = tomorrow_fulldate;

    if ((changeTime == "" || changeTime == "Sort By" || changeTime == "Custom" || changeTime == "Delivery Time") && (Formdate == "" || Todate == "")) {
        first_date = firstdate;
    }
    else if ((changeTime == "Custom") && (Formdate != "" || Todate != "")) {

        first_date = mydate1;
        last_date = mydate2;
    }
    else if (changeTime == "yearly") {
        first_date = last_year_fulldate;
    }
    else if (changeTime == 'hYearly') {
        first_date = last_semiannual_fulldate;
    }
    else if (changeTime == "quarterly") {
        first_date = last_quarter_fulldate;
    }
    else if (changeTime == "monthly") {
        first_date = last_month_fulldate;
    }
    else if (changeTime == "weekly") {
        first_date = last_week_fulldate;
    }
    else if (changeTime == "daily") {

        first_date = today_fulldate;
        last_date = tomorrow_fulldate;
    }

    else {
        first_date = firstdate
    }



    useEffect(() => {
        // setLoading(true)
        axios.get(`https://api.mahaboudhawholesale.com/order/orders-page/?page=${pageID}&status=${StatusValue}&sellerId=${id}&created_date__gte=${first_date}&created_date__lte=${last_date}&final_payment=${PaymentType}&order_type=${DeliveryType}`)
            .then((res) => {
                setDataNo(parseInt(res.data.count));
                var data = res.data.results;
                var array = []

                for (var i = 0; i < data.length; i++) {

                    var date = new Date(data[i].created_date);
                    date = date.toLocaleString();
                    data[i].created_date = date;
                }

                array.push(data);

                setPendingOrder(data);
            })


    }, [first_date, last_date, PaymentType, DeliveryType, pageID, StatusValue])


    function setCancel(e, id) {
        
        

        if (e == "Cancelled") {
            if (window.confirm(`Would you like to confirm this cancel request?`)) {
                axios.patch(`https://api.mahaboudhawholesale.com/order/orders/${id}/`, { 'status': 6, 'updated_by': parseInt(Cookies.get('id')) })
                    .then(res => {
                        

                    })
                // window.location.reload(true);


            } else {
                var txt = "You pressed Cancel!";
            }
        }
    }

    const [ShowExport, setShowExport] = useState(false);
    useEffect(() => {
        axios.get(`https://api.mahaboudhawholesale.com/order/orders/?status=${StatusValue}&sellerId=${Seller_id}`)
            .then((res) => {

                setExportedData(res.data);
            })
            .catch((err) => {

            })
    }, [StatusValue])

    return (
        <div className="p-3 pt-4 dash-new-color">
            <div className="p-3 pt-4 bg-white mb-5 pb-5 rounded">
                <div className="row m-0">
                    <div className="col-lg-2 p-0 text-start me-lg-4">
                        <p className="form-text text-dark">Export Data </p>
                        <button onClick={(e) => setShowExport(true)} className="btn btn-white rounded-0 border-dark btm-sm py-1 fs-14 fm-11 fw-bolder download-information w-100"><i className="fa fa-download"></i> Export File</button>
                        {/* <ExportToExcel onClick={(e)=>setShowExport(true)} apiData={ExcelData} fileName={file_Name} /> */}
                        {
                            ShowExport === true ?
                                <div className='position-absolute bg-white p-3 export-data py-3 shadow-sm mt-2'>
                                    <i className='fa fa-close position-absolute text-danger' style={{ top: '0rem', right: '0rem' }} onClick={(e) => setShowExport(false)}></i>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName1} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Pending Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName2} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Approved Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName3} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Hold Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName4} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Checked In Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName5} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Delivered Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExportedData} fileName={fileName6} /> <span className='ms-2 fw-bolder fs-11 pt-2'>Cancelled Order</span></div>
                                    <div className='d-flex border border-dark rounded mb-2 mt-2'><ExportToExcel apiData={ExcelData} fileName={fileName} /> <span className='ms-2 fw-bolder fs-11 pt-2'>All Order</span></div>
                                </div> : null
                        }
                    </div>
                    <div className="col-lg-3 p-0">
                        <div className="row m-0 mt-lg-0 mt-3">
                            <div className="col-lg col-12 p-0 ms-lg-3 text-start">
                                <p className="form-text text-dark">By Status </p>
                                <select className="form-control1" onChange={onChangeTime}>
                                    <option value={null}>Sort By</option>
                                    <option value="yearly">Yearly</option>
                                    <option value="hYearly">Half Yearly</option>
                                    <option value="quarterly">Quarterly</option>
                                    <option value="monthly">Monthly</option>
                                    <option value="weekly">Weekly</option>
                                    <option value="daily">Daily</option>
                                    <option>Delivery Type</option>
                                    <option>By Payment</option>
                                    <option>Custom</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    {
                        NewSwitch1 === true ?
                            <div className="col-lg p-0 ms-lg-4 ms-md-2">
                                <div className="">
                                    <div className="row m-0 text-start">
                                        <div className="col-lg  p-0 mt-lg-0 mt-3">
                                            <p className="form-text text-dark">Delivery Type</p>
                                            <div className="d-flex">
                                                <select className='form-control1' onChange={onDeliveryType}>
                                                    <option value={null}>Select delivery type</option>
                                                    <option value={1}>Normal</option>
                                                    <option value={2}>Express</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-lg p-0 ms-lg-4 ms-lg-2 mt-lg-0 mt-3">
                                            {/* <p className="form-text text-dark">To </p>
                                    <div className="d-flex">
                                        <DatePicker selected={Todate} onChange={onTodate} className="form-control1 form-width"/>
                                    </div> */}
                                        </div>
                                    </div>
                                </div>
                            </div> : null
                    }
                    {
                        NewSwitch2 === true ?
                            <div className="col-lg  p-0 ms-lg-4 ms-md-2">
                                <div className="">
                                    <div className="row m-0 text-start">
                                        <div className="col-lg p-0 mt-lg-0 mt-3">
                                            <p className="form-text text-dark">Payment Type</p>
                                            <div className="d-flex">
                                                <select className='form-control1' onChange={onPaymentType}>
                                                    <option value={null}>Select payment type</option>
                                                    <option value={false}>Pending</option>
                                                    <option value={true}>Completed</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-lg col p-0 ms-lg-4 ms-lg-2 mt-lg-0 mt-3">
                                            {/* <p className="form-text text-dark">To </p>
                                    <div className="d-flex">
                                        <DatePicker selected={Todate} onChange={onTodate} className="form-control1 form-width"/>
                                    </div> */}
                                        </div>
                                    </div>
                                </div>
                            </div> : null
                    }
                    {
                        NewSwitch === true ?
                            <div className="col p-0 ms-lg-4 ms-md-2">
                                <div className="">
                                    <div className="row m-0 text-start">
                                        <div className="col-lg col-6 p-0 mt-lg-0 mt-3">
                                            <p className="form-text text-dark">From </p>
                                            <div className="d-flex">
                                                <DatePicker selected={Formdate} onChange={onFormdate} className="form-control1 form-width" />
                                            </div>
                                        </div>
                                        <div className="col-lg col p-0 ms-lg-4 ms-lg-2 mt-lg-0 mt-3">
                                            <p className="form-text text-dark">To </p>
                                            <div className="d-flex">
                                                <DatePicker selected={Todate} onChange={onTodate} className="form-control1 form-width" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> : null
                    }
                </div>

            </div>
            <div className="p-lg-3 p-1 pt-4 bg-white">
                {/* <div className="pb-3 pt-2 text-start">
                    <h1 className="fs-6 fw-bolder">My Orders</h1>
                </div> */}
                <ul className="nav nav-tabs" id="myTab" role="tablist">
                    <li className="nav-item" role="presentation">
                        <button className="nav-link active form-text2 fm-10 btn-padding" id="Pending_tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab" aria-controls="pending" aria-selected="true" onClick={() => setStatusValue('1')}>Pending Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Approved_tab" data-bs-toggle="tab" data-bs-target="#approved" type="button" role="tab" aria-controls="approved" aria-selected="false" onClick={() => setStatusValue('2')}>Approved Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Hold_tab" data-bs-toggle="tab" data-bs-target="#hold" type="button" role="tab" aria-controls="hold" aria-selected="false" onClick={() => setStatusValue('3')}>Hold Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Checked_in_tab" data-bs-toggle="tab" data-bs-target="#checked" type="button" role="tab" aria-controls="checked" aria-selected="false" onClick={() => setStatusValue('4')}>Checked In Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Delivered_order_tab" data-bs-toggle="tab" data-bs-target="#delivered" type="button" role="tab" aria-controls="delivered" aria-selected="false" onClick={() => setStatusValue('5')}>Delivered Order</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link form-text2 fm-10 btn-padding" id="Cancelled_tab" data-bs-toggle="tab" data-bs-target="#cancelled" type="button" role="tab" aria-controls="cancelled" aria-selected="false" onClick={() => setStatusValue('6')}>Cancelled Order</button>
                    </li>
                </ul>
                <div className="tab-content col-12 new-overflow p-0" id="myTabContent">
                    <div className="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="Pending_tab">
                        <table className="table border mt-4 new-width border-0 text-start">
                            <thead className='border-bottom'>
                                <tr className="bg-white fm-11">
                                    <th scope="col border-0" className="fs-14 fm-11">Order Number</th>
                                    <th scope="col border-0 " className="fs-14 fm-11">Customer Name</th>
                                    <th scope="col border-0" className="fs-14 fm-11">Customer Mobile</th>

                                    <th scope="col border-0" className="fs-14 fm-11">Riders</th>
                                    <th scope="col border-0" className="fs-14 fm-11">Status</th>
                                    <th scope="col border-0" className="fs-14 fm-11">Details</th>

                                </tr>
                            </thead>
                            {
                                StatusValue ?
                                    <tbody>
                                        {pendingOrder.map(key => (
                                            <tr className="data-information">
                                                <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                                                <td className="fs-13 text-dark">{key.customer_name}</td>
                                                <td className="fs-13 text-dark">{key.customer_mobile}</td>

                                                <td className="fs-13 text-dark">{key.rider_name.contactno}</td>
                                                {key.status.status_name == "Pending" ? <td><select className='border-0 new-border px-2 py-1' defaultValue='Pending' onChange={(e) => setCancel(e.target.value, key.OrderNumber)}>
                                                    <option value={null} className='text-dark' >Select Status</option>
                                                    <option value='Pending' className='text-dark'>Pending</option>
                                                    <option value='Cancelled' className='text-dark'>Cancelled</option>

                                                </select></td> : <td className="fs-13 text-danger">{key.status.status_name}</td>
                                                }
                                                <td className=" fs-13">
                                                    <Link className="text-decoration-none back-color text-white px-2 py-1 rounded" to={`/view/my/data/${key.OrderNumber}`}><i className="fa fa-eye text-white fs-13"></i></Link>
                                                    {
                                                        StatusValue == '1' ?
                                                            <Link className="text-decoration-none back-color text-white px-2 py-1 rounded ms-2" to={`/my/order/update/${key.OrderNumber}`}><i className="fa fa-edit text-white fs-13"></i></Link> : null
                                                    }
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody> : null
                            }
                            {buttonNo.map((key) => (
                                <button onClick={(e) => onButtonValue(e, key)} className="new-pagination-button">{key}</button>
                            ))}
                        </table>
                    </div>
                </div>
            </div>
        </div>



    )
}
export default Place_orderpage;