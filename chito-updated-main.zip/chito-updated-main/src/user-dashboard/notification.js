import React from 'react';
import User_sidebar from './components/side-bar';
import Header from './components/header';
import Notification_page from './pages/notificationpage';

const Notification = ()=>{
    return(
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0">
                <User_sidebar/>
            </div>
            <div className="col-lg  p-0">
                <Header/>
                <Notification_page/>
            </div>
        </div>
    )
}
export default Notification;