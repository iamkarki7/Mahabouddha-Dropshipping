import React from 'react';
import Header from './components/header';
import User_sidebar from './components/side-bar';
import My_ticketpage from './pages/myticketpage';

const My_tickets = ()=>{
    return(
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0">
                <User_sidebar/>
            </div>
            <div className="col-lg  p-0">
                <Header/>
                <My_ticketpage/>
            </div>
        </div>
    )
}
export default My_tickets;