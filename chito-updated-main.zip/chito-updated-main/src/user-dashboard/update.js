import React from 'react';
import Header from './components/header';
import User_sidebar from './components/side-bar';
import Update_page from './pages/updatepage';

const Update = ()=>{
    return(
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0">
                <User_sidebar/>
            </div>
            <div className="col-lg p-0">
                <Header/>
                <Update_page/>
            </div>
        </div>
    )
}
export default Update;