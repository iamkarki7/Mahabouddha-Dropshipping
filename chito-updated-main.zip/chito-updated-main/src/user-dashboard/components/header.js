import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Cookies from 'js-cookie';
import Tippy from '@tippy.js/react';
import 'tippy.js/dist/tippy.css';
import ReactDOM from 'react-dom';
import Modal from 'react-modal';
import Logo from '../../static/image/logo.png';
import axios from 'axios';

const User_header = ()=>{
    const logout = (e) => {
      const Refresh_Token=Cookies.get('refresh_token');
        axios.post(`https://api.mahaboudhawholesale.com/user/logout/`,{'refresh':Refresh_Token},{
          headers: {
            Authorization: Cookies.get('access_token') ?
              'JWT ' + Cookies.get('access_token') :
              null,
            'Content-Type': 'application/json',
            accept: 'application/json',
          },
        })
        .then((res)=>{
          Cookies.remove('refresh_token');
          Cookies.remove('access_token');
          Cookies.remove('id');
          Cookies.remove('email');
          Cookies.remove('user_role')
          window.location.href = '/';
        })
        .catch((err)=>{
     
        })
    }
    var subtitle;
    const [modalIsOpen,setIsOpen] = React.useState(false);
    function openModal() {
      setIsOpen(true);
    }
  
    function afterOpenModal() {
      // references are now sync'd and can be accessed.
      subtitle.style.color = '#f00';
    }
  
    function closeModal(){
      setIsOpen(false);
    }
    return(
        <nav className="navbar navbar-expand navbar bg-white shadow-sm dashboard-border ">
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav px-lg-0 px-3">
                        <h1 className="fs-24 text-color fw-bolder ms-2 dash-text-color fs-5 fm-15 res-display"> User Dashboard</h1>
                        <button className="btn btn-light d-none res-side-bar btn-sm px-2" onClick={openModal}><i className="fa fa-bars fs-5"></i></button>
                    </ul>
                    <ul className="navbar-nav ms-auto">
                        {/* <Tippy content="Notification"><Link to="/user/notification" className="dash-text-color pt-2 ps-lg-4 pe-lg-3 pe-1" role="button" data-placement="top"><i className="fa fa-bell-o fa-2x fm-22"><span className="position-absolute translate-middle badge border border-light rounded-circle bg-danger notification-panel"><span className="visually-hidden">unread messages</span></span></i></Link></Tippy> */}
                        <li className="nav-item dropdown">
                           <Tippy content="Logout"><a className="nav-link header-res" href="#" type="button" onClick={logout} id="navbarDropdown" role="button" data-toggle="tooltip" data-placement="bottom" title="Logout">
                            <i className="fa fa-sign-out dash-text-color fa-2x pe-4 fm-22"></i>
                            </a></Tippy>
                        </li>
                    </ul>
                </div>
                <div>
          <Modal
            isOpen={modalIsOpen}
            onAfterOpen={afterOpenModal}
            onRequestClose={closeModal}
            contentLabel="Example Modal"
            className="border-0 rounded-0 modal-content2 dash-board-color"
          >
  
            <h2 ref={_subtitle => (subtitle = _subtitle)}><img src={Logo} className="w-100 px-2 py-2 pb-3 border-bottom border-2" alt="logo"/></h2>
            <i className="fa fa-times position-absolute text-dangers" onClick={closeModal}></i>
            <div className="pt-2 px-2">
                <Link to="/user/dashboard" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 dash-active text-decoration side-bar"><i className="fa fa-qrcode fs-5 text-center p-1 px-4"></i><br/>Dashboard</Link>
                <Link to="/bulk/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-shopping-cart fs-5 p-1 px-4"></i><br/>Order </Link>
                <Link to="/my/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-first-order fs-5 p-1 px-4"></i><br/>My Order</Link>
                <Link to="/my/tickets" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-ticket fs-5 p-1 px-4"></i><br/>My Tickets</Link>
                <Link to="/my/profile" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-user-circle fs-5 p-1 px-4"></i><br/>My Profile</Link>
                {/* <Link to="/dashboard/add-variation-options" className="text-white text-start text-center px-2 py-4 text-decoration-none fs-17 d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>My Cancelled Order</Link>
                <Link to="/dashboard/add-variation-value" className="text-white text-start side-padding text-decoration-none fs-17 d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>My Delivered Order</Link> */}
                {/* <Link to="/dashboard/add-data" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>Add Data</Link>
                <Link to="/dashboard/user-information" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-users p-1 px-3"></i>User Information</Link>
                <Link to="#" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-cog p-1 px-3"></i>Settings</Link> */}
            </div>
          </Modal>
        </div>
            </nav>

    )
}
export default User_header;