import React,{useEffect,useState} from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Cookies from 'js-cookie';

const Posts = ({ posts, loading }) => {

  const [status, setStatus] = useState([]);
  useEffect(()=>{
    axios.get(`https://api.mahaboudhawholesale.com/order/status/`)
    .then((res)=>{
        setStatus(res.data);
    })
},[])


    
    
  if (loading) {
    return <h2>Loading...</h2>;
  }
  const setCancel = (e,id) =>
    {
        if(e)
        {
            if (window.confirm(`Would you like to confirm this ${e} request?`)) {
                for(var i=0;i<status.length;i++){
                if(e==status[i].status_name)
                {
                    var status_id = parseInt(status[i].id);
                }
                }
                axios.patch(`https://api.mahaboudhawholesale.com/order/orders/${parseInt(id)}/`,{'status':status_id,'updated_by':parseInt(Cookies.get('id'))},{headers : {Authorization: Cookies.get('access_token') ?'JWT ' + Cookies.get('access_token') :null,'Content-Type':'application/json'}})
                .then(res=>{
                  window.location.reload(true);
                })
            }
              } else {
                var txt = 'You pressed Cancel!';
                window.location.reload(true);
              }
        }
  return (
    <>
         {posts.map(key=>(
                        <tr className="data-information">
                             <th scope="row" className="fs-13 text-dark"><i className='fa fa-circle me-2 text-color'></i>{key.OrderNumber}</th>
                        <td className="fs-13 text-dark">{key.customer_name}</td>
                        <td className="fs-13 text-dark">{key.customer_mobile}</td>
                       
                        <td className="fs-13 text-dark">{key.rider_name.contactno}</td>
                        {key.status.status_name == "Pending"?<td><select className='border-0 new-border px-2 py-1' defaultValue = 'Pending' onChange={(e)=>setCancel(e.target.value,key.id)}>
                            <option value={null} className='text-dark' >Select Status</option>
                            <option  value='Pending' className='text-dark'>Pending</option>
                            <option  value='Cancelled' className='text-dark'>Cancelled</option>
              
                            </select></td>:<td className="fs-13 text-dark">{key.status.status_name}</td>}
                        <td className=" fs-13">
                        <Link className="text-decoration-none back-color text-white px-2 py-1 rounded" to={`/view/my/data/${key.OrderNumber}`}><i className="fa fa-eye text-white fs-13"></i></Link>
                        </td>
                    </tr>
                         ))}
                         </>
  
  );
};

export default Posts;