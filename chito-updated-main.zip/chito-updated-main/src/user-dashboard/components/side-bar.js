import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../../static/image/logo.png';


const User_sidebar = ()=>{
   
    return(
        <div className='dashboard-sidebar-fix'>
        <div className="dash-board-color height-of-sidebar sticky-top res-display fixed-top">
            <div className="col-12 text-center py-4 px-2 border-bottom border-2">
                {/* <h1 className="fa fa-user-circle text-white fa-3x"></h1>
                <p className="text-center text-white fw-bolder mt-2">
                    Xito Logistic
                </p> */}
                <img src ={Logo} className="w-100" alt="logo" />
            </div>
            <div className="pt-4 px-2">
                <Link to="/user/dashboard" active className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 text-decoration side-bar"><i className="fa fa-qrcode fs-5 text-center p-1 px-4"></i><br/>Dashboard</Link>
                <Link to="/bulk/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-shopping-cart fs-5 p-1 px-4"></i><br/>Order</Link>
                <Link to="/my/order" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-first-order fs-5 p-1 px-4"></i><br/>My Orders</Link>
                <Link to="/my/tickets" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-ticket fs-5 p-1 px-4"></i><br/>My Tickets</Link>
                <Link to="/my/profile" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-user-circle fs-5 p-1 px-4"></i><br/>My Profile</Link>
                <a href="https://mahaboudhawholesale.com/collections/all" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-product-hunt fs-5 p-1 px-4"></i><br/>Products</a>
                <a href="https://mahaboudhawholesale.com/pages/delivery-charges-amp-all-logistic-branches" className="text-white text-start text-center px-2 py-2 pb-3 rounded text-decoration-none fs-14 d-block fs-15 mt-2 dash-active-hover text-decoration side-bar"><i className="fa fa-truck fs-5 p-1 px-4"></i><br/>Delivery Charge</a>
                {/* <Link to="/dashboard/add-variation-options" className="text-white text-start text-center px-2 py-4 text-decoration-none fs-17 d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>My Cancelled Order</Link>
                <Link to="/dashboard/add-variation-value" className="text-white text-start side-padding text-decoration-none fs-17 d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>My Delivered Order</Link> */}
                {/* <Link to="/dashboard/add-data" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-plus-square p-1 px-3"></i>Add Data</Link>
                <Link to="/dashboard/user-information" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-users p-1 px-3"></i>User Information</Link>
                <Link to="#" className="text-white d-block fs-15 mt-2 dash-active-hover text-decoration"><i className="fa fa-cog p-1 px-3"></i>Settings</Link> */}
            </div>
        </div>
          
        </div>
    )
}
export default User_sidebar;