import React from 'react';
import Header from './components/header';
import User_sidebar from './components/side-bar';
import Bluk_orderpage from './pages/bluk-order-page';

const Bulk_order = () => {
    return (
        <div className="row m-0">
            <div className="col-lg-1 col-width p-0 fixed-start">
                <User_sidebar />
            </div>
            <div className="col-lg p-0">
                <Header />
                <Bluk_orderpage />
            </div>
        </div>
    )
}
export default Bulk_order;