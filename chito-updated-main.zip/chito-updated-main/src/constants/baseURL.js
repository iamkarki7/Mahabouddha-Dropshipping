import Cookies from "js-cookie";

// export const BASE_URL = "https://api.mahaboudhawholesale.com";
export const BASE_URL = "https://api.mahaboudhawholesale.com"

export const AUTHORIZATION_JSON = { headers: { Authorization: Cookies.get('access_token') ? 'JWT ' + Cookies.get('access_token') : null, 'Content-Type': 'application/json' }}