export const getPaginationPagesCount = (count, pagination) =>{
    let division = Math.floor(count/pagination)
    if(count % pagination != 0)
    {
        return division+1
    }
    else{
        return division
    }
}