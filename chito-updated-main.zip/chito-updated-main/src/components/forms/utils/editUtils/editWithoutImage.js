import { BASE_URL } from "../../../../constant/baseURL";

const editWithoutImage = (noLoop, setNoLoop, editAPI, values, id, context = null) => {

  const formData = new FormData();
  let editValue = {};
  Object.assign(editValue, values)
  editValue['id'] = id;
  editValue['context'] = context;


  if (editValue.edit && noLoop) {


    if (editValue) {

      
      

      editAPI({ 'data': editValue }).then((res) => {


        setNoLoop(false);

      })
        .catch((err) => {

        })
    }
  }
}

export default editWithoutImage;