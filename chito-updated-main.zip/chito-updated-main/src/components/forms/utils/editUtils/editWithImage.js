import BlobToBase64 from "../blobToBase64";

const editWithImage = (noLoop, setNoLoop, editAPI, imageJSON, values, id, context=null) =>{
  
    const formData = new FormData();
    let editValue = {};
    Object.assign(editValue, values)
    editValue['id'] = id;
    if(editValue.edit && noLoop)
    {
      
      if(editValue)
        {   
          
          for (let i=0; i<imageJSON.length; i++)
          {   
            if(editValue[imageJSON[i].imageName] && typeof(editValue[imageJSON[i].imageName]) === 'string' && editValue[imageJSON[i].imageName].split('.').pop() !== 'None')
            {
              
              editValue['context'] = context;
              editValue[imageJSON[i].imageName] = editValue[imageJSON[i].imageName] 
              setNoLoop(false);
            }
            else if(editValue[imageJSON[i].imageName] instanceof Blob)
              {
                
                BlobToBase64(imageJSON[i].imageFile).then(res=>{
                  editValue['context'] = context;
                  editValue[imageJSON[i].imageName] = res;
                  formData.append("data", JSON.stringify(editValue)); 
                  
                  editAPI({'data': editValue}).then((res)=>{
                        setNoLoop(false);
                      })
                  .catch((err)=>{})  
                  })
              }
            else
              {
                editValue['context'] = context
                editValue[imageJSON[i].imageName] = null;
                formData.append("data", JSON.stringify(editValue));
                
                editAPI({'data': editValue}).then((res)=>{
                  setNoLoop(false);
                  })
                .catch((err)=>{})
              }
          }
          
          editAPI({'data': editValue}).then((res)=>{})
            .catch((err)=>{})
        }
    }
}

export default editWithImage;