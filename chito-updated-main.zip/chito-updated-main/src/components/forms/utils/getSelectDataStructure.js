export const getSelectDataStructureWithEntities = (api, idField, fieldName) =>{

    const apiField = api();
    let selectData = []
    
    apiField?.data?.ids?.map((key)=>{
        selectData.push({
            'id': apiField.data.entities[key][idField],
            'title': apiField.data.entities[key][fieldName]})
    })
    return selectData;
}

export const getSelectDataStructureWithOutEntities = (api, fieldName) =>{

    const apiField = api();
    let selectData = []
    
    // apiField.map((key)=>{
    // })
}

