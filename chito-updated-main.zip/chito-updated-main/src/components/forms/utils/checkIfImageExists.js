function checkIfImageExists(url, cdn=false) {
    if(cdn)
    {
      return url.match(/https.*?(?=\s|$)/g)
    }
    return /\.(jpg|jpeg|png|webp|avif|gif|svg)$/.test(url);
  }

export default checkIfImageExists;
