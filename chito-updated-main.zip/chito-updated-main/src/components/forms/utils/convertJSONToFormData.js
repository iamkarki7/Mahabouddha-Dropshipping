export default function convertJSONToFormData(json){
    var formData = new FormData();
    for (var property in json) {
      if (json.hasOwnProperty(property)) {
        if (typeof json[property] === 'object' && json[property].constructor === Array) {
          // Handle array of files
          for (var i = 0; i < json[property].length; i++) {
            formData.append(property + '[' + i + ']', json[property][i]);
          }
        } else if (typeof json[property] === 'object' && json[property] instanceof File) {
          // Handle single file
          formData.append(property, json[property]);
        } else {
          // Handle regular string or object
          formData.set(property, json[property]);
        }
      }
    }
    return formData;
}