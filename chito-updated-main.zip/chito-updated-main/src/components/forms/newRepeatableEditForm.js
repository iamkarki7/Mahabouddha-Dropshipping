import React, { useState, useEffect } from 'react'
import { Grid } from "@mui/material";
import Controls from '../../components/forms/controls/Controls';
import {
    Form,
    useForm1
} from '../../components/forms/useForm';
import useDebounce from '../../components/forms/utils/debounce';
import {OriginalForm, SelectForm} from './originalForm';
import { useSelector } from 'react-redux';


data = {
    original_data : {
        'package_name': '',
        'transport_medium': '',
        'is_lunch': false,
        'is_breakfast': false,
        'is_dinner': false,
        'is_welcome_drinks': false,
        'is_dj': false,
        'is_barbeque': false,
        'is_transport': false,
        'price': 0,
    }
}

const AddBedForm = ({ index, setId, idList, setIsCreate, originalId, repeatableFormData }) => {

    const Data = {}
    useEffect(() => {
        repeatableFormData[0].dataRepeat.map((key) => {
    
                Data[key.name] = key.initialValue;

        })
        repeatableFormData[0].dataMap.map((key) => {
            if (key.show === true) {
                Data[key.name] = key.initialValue;
            }
        })
    }, [repeatableFormData[0]])

    const [initialFValues, setInitialFValues] = useState(Data);

    const [addHotelBed, { data }] = repeatableFormData[0].postFormAPI();
    const [addHotelBedRoom] = repeatableFormData[0].postFormMapAPI();

    const DataMap = {}

    useEffect(() => {
        if (data) {
            setId([...idList, data.id]);
            repeatableFormData[0].dataMap.map((key) => {
                if (key.meta === "original") {
                    DataMap[key.name] = originalId
                }
                else if (key.meta === 'map') {
                    DataMap[key.name] = data.id
                }
                else if (key.meta === 'extra') {
                    DataMap[key.name] = initialFValues[key.name]
                }
            })
            addHotelBedRoom(DataMap)

            setIsCreate(false);
        }
    }, [data])

    const {
        values,
        setValues,
        handleInputChange,
        resetForm,
        valueArray,
    } = useForm1(initialFValues, true);

    useEffect(() => {

        if (index === 0) {
            addHotelBed(initialFValues);
        }

    }, [index])

    return (

        <Grid container >
            <Grid item xs={6}>
                {
                    repeatableFormData[0].dataRepeat.map((key) => (
                        <>
                        {key.ControlType === "select"?
                        <SelectForm allKey={key} values={values} handleInputChange={handleInputChange}/>:
                        <OriginalForm allKey={key} values={values} handleInputChange={handleInputChange}/>
                        }
                        </>
                    ))
                }
                {
                    repeatableFormData[0].dataMap.map((key) => (
                        <>
                        {key.ControlType === "select"?
                        <SelectForm allKey={key} values={values} handleInputChange={handleInputChange}/>:
                        <OriginalForm allKey={key} values={values} handleInputChange={handleInputChange}/>
                        }
                        </>
                    ))
                }                
            </Grid>
        </Grid>
    )
}