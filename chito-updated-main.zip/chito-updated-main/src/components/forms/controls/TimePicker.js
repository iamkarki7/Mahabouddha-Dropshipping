import React, { useState } from 'react';
import TimePicker from 'react-time-picker';
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';


function TimePickerReact(props) {
  const { name, label, value, onChange, error } = props;

    const handleChange = (e) =>{
      let value = e;
        onChange({
          target:{
            name, value
          }
        })
    }

  return (
    <div>
      <label>{label}</label>
      <TimePicker onChange={handleChange} value={value} />
    </div>
  );
}

export default TimePickerReact;