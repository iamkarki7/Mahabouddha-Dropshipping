import React, { useState } from "react";
import TextButton from "../../button/buttonicon";
import RoundButton from "../../button/roundbutton";
import { FaPlus } from "react-icons/fa";
import { useEffect } from "react";
import Controls from "./Controls";
import useDebounce from "../utils/debounce";
import { Box } from "@material-ui/core";
import BlobToBase64 from "../utils/blobToBase64";
import { Grid, Tooltip } from "@mui/material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEdit, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";

const ReusableForms = ({
  isUpdate = false,
  updateLink,
  originalId,
  getApi,
  fieldName,
  mappedData,
  postAPI,
  fieldList,
  deleteAPI,
  initialAdd = [],
  context,
  editApi,
  imageField = {},
}) => {

  const data = getApi(originalId);


  const [thisData, setThisData] = useState([]);
  const [originalData, setOriginalData] = useState({});
  const [valueArray, setValueArray] = useState([]);
  const [addData] = postAPI();
  const [deleteThis] = deleteAPI();
  const [editThis] = editApi();
  const [editorValue, setEditorValue] = useState("");



  const getAllSetValues = (imageField) => {
    Object.keys(imageField).forEach((key) => {
      setValueArray((valueArray) => [
        ...valueArray,
        imageField[key]["imageFieldValue"],
      ]);
    });
  };

  useEffect(() => {
    getAllSetValues(imageField);
  }, [imageField]);

  useEffect(() => { }, [valueArray]);

  useEffect(() => {
    if (data.data) {

      setOriginalData(data.data);
      setThisData(data.data[fieldName]);
    }
  }, [data.data]);

  const addForm = (e) => {
    e.preventDefault();
    const formData = new FormData();
    const data = {};
    data['id'] = originalId;
    context['request'] = 'POST';
    data['context'] = context
    data[fieldName] = [{}];
    initialAdd.forEach((key) => {
      data[fieldName][0][key['key']] = key['value'];
    })
    mappedData.forEach((key) => {
      data[fieldName][0][key.fieldName] = key.default;
    })
    addData(data).then((res) => {

    });
  };

  const imageConfirm = (e, key) => {
    BlobToBase64(imageField[e.target.name]["imageFieldValue"]).then((res) => {
      updateObject(
        key.id,
        { target: { name: e.target.name, value: res } },
        setOriginalData,
        originalData,
        fieldName
      );
    });
  };

  const deleteForm = (e, key) => {

    e.preventDefault();
    let data = {};
    data["id"] = originalId;


    fieldList.forEach((key1) => {
      if (key1 === fieldName) {
        data[key1] = [{ id: key.id }];
      } else {
        data[key1] = [];
      }
    });

    deleteThis(data);
  };

  const [changeImmediate, setChangeImmediate] = useState(false);
  function updateObject(id, e, setData, data, fieldName) {
    const index = data[fieldName].findIndex((item) => item.id === id);
    const newQux = [...data[fieldName]];
    newQux[index] = { ...newQux[index], [e.target.name]: e.target.value };
    setData({ ...data, [fieldName]: [...newQux], context: context });
  }

  const editChange = (e, b, immediateChange) => {
    updateObject(b.id, e, setOriginalData, originalData, fieldName);
    if (immediateChange) {
      if (changeImmediate) {
        setChangeImmediate(false);
      } else {
        setChangeImmediate(true);
      }
    }
  };

  useEffect(() => {
    const formData = new FormData();
    formData.append("data", JSON.stringify(originalData));
    if (originalData["context"] !== undefined) {
      editThis({ data: originalData });
    }
  },
    [useDebounce(originalData[fieldName], 3000), changeImmediate]);


  return (
    <>
      <Grid container spacing={0}>
        <>
          {thisData.map((key) => (
            <Grid item xs={12}>
              <Box
                style={{
                  background: "white",
                  borderRadius: "5px",
                  margin: "1rem",
                  marginTop: "1.5rem",
                }}
                className="hover-to-delete-display"
              >
                <Box style={{ padding: "1rem" }}>
                  {mappedData.map((key1) => (
                    <>
                      {key1["field_form"] === "input" ? (
                        <Box style={{ marginBottom: "20px" }}>
                          <Controls.Input
                            name={key1["field_name"]}
                            defaultValue={key[key1["field_name"]]}
                            label={key1["label"]}
                            onChange={(e) => editChange(e, key)}
                          />
                        </Box>
                      ) : (
                        <></>
                      )}
                      {key1["field_form"] === "time" ? (
                        <Box style={{ marginBottom: "20px" }}>
                          <Controls.TimePickerReact
                            name={key1["field_name"]}
                            defaultValue={key[key1["field_name"]]}
                            label={key1["label"]}
                            value={key[key1["field_name"]]}
                            onChange={(e) => editChange(e, key)}
                          />
                        </Box>
                      ) : (
                        <></>
                      )}
                      {key1["field_form"] === "date" ? (
                        <Box style={{ marginBottom: "20px" }}>
                          <Controls.DatePickerWithYear
                            name={key1["field_name"]}
                            defaultValue={key[key1["field_name"]]}
                            label={key1["label"]}
                            onChange={(e) => editChange(e, key)}
                          />
                        </Box>
                      ) : (
                        <></>
                      )}
                      {key1["field_form"] === "checkbox" ? (
                        <Box style={{ marginBottom: "20px" }}>
                          <Controls.Checkbox
                            name={key1["field_name"]}
                            value={key[key1["field_name"]]}
                            label={key1["label"]}
                            onChange={(e) => editChange(e, key, true)}
                          />
                        </Box>
                      ) : (
                        <></>
                      )}
                      {key1["field_form"] === "select" ? (
                        <>
                          <Grid container spacing={1}>
                            <Grid item xs={10}>
                              <Box style={{ marginBottom: "20px" }}>
                                <Controls.Select
                                  name={key1["field_name"]}
                                  value={key[key1["field_name"]]}
                                  label={key1["label"]}
                                  options={key1.options}
                                  onChange={(e) => editChange(e, key)}
                                />
                              </Box>
                            </Grid>
                            <Grid item xs={2}>
                              <Box style={{ paddingTop: "5px" }}>
                                <Link to={key1['updateLink']} >
                                  <TextButton
                                    buttonText={'Update'}
                                  />
                                </Link>
                              </Box>
                            </Grid>
                          </Grid>
                        </>
                      ) : (
                        <></>
                      )}
                      {key1["field_form"] === "image" ? (
                        <>
                          <Controls.Image
                            name={key1["field_name"]}
                            setFile={
                              imageField[key1["field_name"]][
                              "imageSetFieldValue"
                              ]
                            }
                            aspectRatio={key1['aspect_ratio']}
                          />
                          <Box style={{ marginTop: "10px" }}>
                            <Grid container spacing={1}>
                              <Grid item xs={4}>
                                <TextButton
                                  onClick={(e) => imageConfirm(e, key)}
                                  name={key1["field_name"]}
                                  buttonText="Confrim Image"
                                />
                              </Grid>
                              <Grid item xs={4}>
                                <button
                                  onClick={(e) => deleteForm(e, key)}
                                  className="delete-column-design"
                                >Delete Column</button>
                              </Grid>
                            </Grid>
                          </Box>
                        </>
                      ) : (
                        <></>
                      )}

                    </>
                  ))}
                  <Grid item xs={3}>
                    {isUpdate ?
                      <Link to={`${updateLink}/${key.id}`}>
                        <TextButton
                          // onClick={(e) => imageConfirm(e, key)}
                          // name={key1["field_name"]}
                          buttonText={'Update'}
                        /></Link> : <></>
                    }
                  </Grid>
                </Box>
              </Box>
            </Grid>
          ))}
        </>
      </Grid>
      <Box style={{ marginTop: "1.2rem" }}>
        <RoundButton
          classname="new-button-design"
          buttonIcon={FaPlus}
          buttonText={"Add"}
          handleClick={(e) => addForm(e)}
        />
      </Box>
    </>
  );
};

export default ReusableForms;
