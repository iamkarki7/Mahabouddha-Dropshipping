import React from "react";
import SearchBar from "material-ui-search-bar";


const Search = (props) =>{
    

    const {onChange, name } = props;
return(
        <SearchBar
            style={{
                    height: "60px",
                    borderRadius: "5px",
                    }}
            onChange={onChange}
            name={name}        
            />
            
    )
}

export default Search;