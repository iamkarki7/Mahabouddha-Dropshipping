import React from "react";


const InputText = ({ label, value, Type, name,onChange,placeholder }) => {
    return (
        <div>
            <label className="label-text-design">{label}</label>
            <input type={Type} name={name} value={value} onChange={onChange} placeholder={placeholder} className="input-design-form" required="" autocomplete="off" />
        </div>
    )
}

export default InputText;