import Input from "./input";
// import RadioGroup from "./RadioGroup";
// import Select from "./Select";
// import Checkbox from "./CheckBox";
// import DatePickers from "./DatePicker";
import Button from "./Button";
// import MultiSelect from "./MultiSelect";
import Search from "./searchBar";
import Image from "./image";
// import DateTimePicker from "./DateTimePicker";
// import File from "./file";
// import NumberInput from "./integerInput";
// import MultipleDatePicker from "./multipleDatePicker";
// import SingleCalendar from "./SingleCalendar";
// import PDFViewer from "./reactPDFViewer";
// import DatePickerWithYear from "./DatePickerWithVariableYear";
// import DateRangePickerComponent from "./DateRangePickerWala";
// import MultiCalendar from "./MultiCalendar";
// import MultiMonth from "./MultiMonth";
// import SingleMonth from "./SingleMonth";
// import ReusableForms from "./ReusableForms";
// import ReusableFormsSelect from "./ReusableFormSelect";
// import Password from "./password";
// import InputText from "./inputText";
// import SearchInput from "./searchInput";
// import SearchSelect from "./searchSelect";
// import TimePickerReact from "./TimePicker";
// import Editor from "./Editor";
// import SortingSelectOption from "./sortingSelectOption";
import GoogleAutoCompleteInput from "./googleAutoComplete";
import SearchAutoComplete from "./searchAutoComplete";


const Controls = {
    Input,
    // RadioGroup,
    // Select,
    // Checkbox,
    // DatePickers,
    Button,
    SearchAutoComplete,
    // MultiSelect,
    Search,
    Image,
    // DateTimePicker,
    // File,
    // NumberInput,
    // MultipleDatePicker,
    // SingleCalendar,
    // PDFViewer,
    // DatePickerWithYear,
    // DateRangePickerComponent,
    // NumberInput,
    // MultiCalendar,
    // MultiMonth,
    // SingleMonth,
    // ReusableForms,
    // ReusableFormsSelect,
    // Password,
    // InputText,
    // SearchInput,
    // SearchSelect,
    // TimePickerReact,
    // Editor,
    // SortingSelectOption,
    GoogleAutoCompleteInput,
}

export default Controls;