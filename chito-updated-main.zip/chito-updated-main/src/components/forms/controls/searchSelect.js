import React from "react";


const SearchSelect = ({ label, name, options, onChange,classname }) => {
    return (
        <div className={classname}>
            <div>{label}</div>
            <select name={name} id={name} onChange={onChange} className="dropdown_item_select search_input">
                {
                    options.map((key) => (
                        <option value={key.id}>{key.name}</option>
                    ))
                }
            </select>
        </div>
    )
}

export default SearchSelect;