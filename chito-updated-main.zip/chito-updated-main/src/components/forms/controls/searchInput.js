import React from "react";



const SearchInput = ({ Type, onChange, value, name, label, placeholder, classname }) => {
    return (
        <div className={classname}>
            <div>{label}</div>
            <input type={Type} onChange={onChange} value={value} name={name} placeholder={placeholder} className="destination search_input" required="required" />
        </div>
    )
}

export default SearchInput;