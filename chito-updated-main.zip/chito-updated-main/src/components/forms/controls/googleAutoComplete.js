import React from "react";
import ReactGoogleAutocomplete from "react-google-autocomplete";
import { GOOGLE_API } from "../../../constants/googleAPIKey";

const GoogleAutoCompleteInput = ({ onPlaceSelected, className, label, defaultValue }) => {
    const handlePlaceSelected = (place) => {
        if (onPlaceSelected) {
            onPlaceSelected(place);
        }
    };

    return (
        <div className={className}>
            <div>{label}</div>
            <ReactGoogleAutocomplete
                apiKey={GOOGLE_API}
                onPlaceSelected={handlePlaceSelected}
                className="destination search_input"
                defaultValue={defaultValue}
            />
        </div>
    );
};

export default GoogleAutoCompleteInput;