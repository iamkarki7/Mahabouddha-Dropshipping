import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';



const Editor = (props)=>{
    const { name, label, value, onChange, defaultValue} = props;

    const handleChange = (e) =>{
        let value = e;
        onChange({
            target: {
                name, value
            }
        })

    }
    return(
        <>
        <label className='label-text-design'>{label}*</label>
        <ReactQuill
            theme="snow"
            value={value}
            defaultValue={defaultValue}
            name={name}
            onChange={handleChange} />
    </> 
    )
}

export default Editor;