import React from 'react'
import { TextField } from '@material-ui/core';

export default function Input(props) {

    const { name, label, value,error=null, onChange, defaultValue } = props;
    return (
        <TextField
            variant="outlined"
            label={label}
            name={name}
            value={value}
            onChange={onChange}
            defaultValue={defaultValue}
            style={{
                borderBlockColor: 'white',
                width:'100%',
            }}
            className="input-height"
            {...(error && {error:true,helperText:error})}
        />
    )
}
