import React, { useState } from "react";
import {
    FormControl,
    InputLabel,
    FormHelperText,
} from "@material-ui/core";
import { Autocomplete, TextField } from "@mui/material";
import { useEffect } from "react";

export default function SearchAutoComplete(props) {
    const { name, label, value, error = null, onChange, options } = props;



    const [defaultValue, setDefaultValue] = useState("");
    useEffect(() => {
        setDefaultValue(options.find((option) => option?.id === value));
    }, [options, value])

    const convertToDefEventPara = (name, value) => ({
        target: {
            name,
            value,
        },
    });
    const handleClick = (e, value) => {
        onChange(convertToDefEventPara(name, value?.id))
    }
    return (
        <FormControl variant="outlined" {...(error && { error: true })} style={{ width: "100%" }}>

            <Autocomplete
                disablePortal
                label={label}
                name={name}
                value={defaultValue}
                defaultValue={defaultValue}
                id="combo-box-demo"
                onChange={handleClick}
                getOptionLabel={(options) => options.title}
                options={options}
                sx={{ width: '100%' }}
                renderInput={(params) => <TextField {...params} label={label} />}
            />
            {error && <FormHelperText>{error}</FormHelperText>}
        </FormControl>
    );
}

