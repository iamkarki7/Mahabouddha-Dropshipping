import React from "react";

const SortingSelectOption = ({ placeholder, options, onChange,value }) => {
    return (
        <select className="select-option-sorting" onChange={onChange} value={value}>
            {/* <option>Please Select {placeholder}</option> */}
            {
                options.map((data, index) => (
                    <option value={data.value} key={index}>{data.label}</option>
                ))
            }
        </select>
    )
}

export default SortingSelectOption;