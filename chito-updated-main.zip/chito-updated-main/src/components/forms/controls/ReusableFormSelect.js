import React, { useState } from "react";
import TextButton from "../../button/buttonicon";
import RoundButton from "../../button/roundbutton";
import { FaPlus } from "react-icons/fa";
import { useEffect } from "react";
import Controls from "./Controls";
import { useForm1 } from "../useForm";
import useDebounce from "../utils/debounce";
import { Box } from "@material-ui/core";
import {
  CSSTransition,
  TransitionGroup,
} from 'react-transition-group';

const ReusableFormsSelect = ({
  originalId,
  getApi,
  fieldName,
  mappedData,
  postAPI,
  defaultValue,
  deleteAPI,
  fieldList,
  context,
  defaultValueList=false
}) => {
  const data = getApi(originalId);
  const [thisData, setThisData] = useState([]);
  const [showSelect, setShowSelect] = useState(false);
  const [addData] = postAPI();
  const [deleteThis] = deleteAPI();
  const [originalData, setOriginalData] = useState({});

  
  
  let options = [];
  if (defaultValueList)
  {
    options = defaultValue
  }
  else
  {
    const allValue = defaultValue();
    if (allValue.status === "fulfilled") {
      allValue.data.ids.map((key) => {
        options.push({ id: key, title: allValue.data.entities[key].room_name });
      });
    }
  }

  useEffect(() => {
    if (data.data) {
      setOriginalData(data.data);
      setThisData(data.data[fieldName]);
    }
  }, [data.data]);

  const addSelectData = (e) => {
    
    e.preventDefault();
    const data = {
      id: originalId,
      [fieldName]: [
        {
          id: e.target.value,
        },
      ],
    };
    addData(data).then((res)=>{
      
    });
    setShowSelect(false);
  };

  const addForm = (e) => {
    e.preventDefault();
    setShowSelect(true);
  };

  function updateObject(id, e, setData, data, fieldName) {
    const index = data[fieldName].findIndex(item => item.id === id);
    const newQux = [...data[fieldName]];
    newQux[index] = { ...newQux[index], [e.target.name]: e.target.value };
  
    setData({...data, [fieldName]: [...newQux], context: context})
  }

  const deleteForm = (e, key) =>{
    e.preventDefault();
    let data = {};
    data['id'] = originalId;
    fieldList.forEach((key1)=>{
        if(key1 === fieldName)
        {
            data[key1] = [{'id': key.id}];
        }
        else{
        data[key1] = [];
        }
    })
    deleteThis(data);
  }
  

  const thisEdit = (e, key) =>{
    updateObject(key.id, e, setOriginalData, originalData, fieldName)
    
  }
  return (
    <>
      <>
        {thisData.map((key) => (
          <>
          <Box style={{background:'white',padding:'2rem',marginBottom: '1rem',borderRadius: "5px"}}>
            <TransitionGroup>
             
            {mappedData.map((key1) => (
               <CSSTransition
               key={key1}
               timeout={500}
               classNames="item">
              <>
                <Controls.Select
                  name={key1["field_name"]}
                  value={key[key1["field_name"]]}
                  label={key1["label_name"]}
                  options={options}
                  onChange={(e)=>thisEdit(e, key)}
                />
              </>
              </CSSTransition>
            ))}
       
            </TransitionGroup>
          </Box>
               <RoundButton
               classname=""
               buttonText={"Delete"}
               handleClick={(e)=>deleteForm(e, key)}
               />
               </>

        ))}
        {showSelect === true ? (
          <>
            {mappedData.map((key1) => (
              <>
                <Controls.Select
                  name={key1["field_name"]}
                  label={key1["label_name"]}
                  options={options}
                  onChange={(e) => addSelectData(e)}
                />
              </>
            ))}
          </>
        ) : (
          <></>
        )}
      </><br/>
      <RoundButton
        classname="add-btn-design"
        buttonIcon={FaPlus}
        buttonText={"Add"}
        handleClick={(e) => addForm(e)}
      />
    </>
  );
};

export default ReusableFormsSelect;