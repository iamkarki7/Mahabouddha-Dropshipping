import  React, {useEffect, useRef, useState} from 'react'
// import useGooglePlaceAutoComplete from '../../googleServices/googleAutoCompleteServices'
import useGooglePlaceAutoComplete from '../../services/googleServices/googleAutoCompleteServices';
import Geocode from "react-geocode";
import { GOOGLE_API } from '../../constants/googleAPIKey';


const GoogleAutoCompleteComponent = ({valueList, value, onChange}) => {
    const [address, setAddress] = useState({});
    const [latitude, setLatitude] = useState(0.0);
    const [longitude, setLongitude] = useState(0.0);
    Geocode.setApiKey(GOOGLE_API);
    Geocode.setLanguage("en");
    Geocode.setRegion("np");
    const address1Ref = useRef();
    useEffect(()=>{

      onChange({...address, latitude, longitude}, valueList)
    },[address, latitude, longitude])

    const googleAutoCompleteSvc = useGooglePlaceAutoComplete();
    let autoComplete = "";
    const handleAddressSelect = async () => {
        let addressObj = await googleAutoCompleteSvc.getFullAddress(autoComplete);
        
        const words = addressObj?.address1?.split(" ");
        const result = words.slice(1).join(" ");
        addressObj['address1'] = result
        setAddress(addressObj);
        Geocode.fromAddress(result).then(
          (response) => {
            const { lat, lng } = response.results[0].geometry.location;
            
            
            
            setLatitude(lat);
            setLongitude(lng);
            
          },
          (error) => {
            console.error(error);
          }
        );
    };

    
    useEffect(() => {
        async function loadGoogleMaps() {
            // initialize the Google Place Autocomplete widget and bind it to an input element.
            // eslint-disable-next-line
            autoComplete = await googleAutoCompleteSvc.initAutoComplete(address1Ref.current, handleAddressSelect);
        }
        loadGoogleMaps();
    }, []);
  return (
      <div className="form-field-container">
        {/* <label className='label-text-design'>Address 1 (Required)*</label> */}
        <input
            id="address1"
            type="text"
            className="form-field"
            placeholder={value}
            ref={address1Ref}

        />
      </div>
  )
}

export default GoogleAutoCompleteComponent;