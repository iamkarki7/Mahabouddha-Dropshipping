import React, { useEffect, useState } from 'react';
import { BrowserRouter, Route, Switch, HashRouter, useHistory } from 'react-router-dom';
import Contact from '../templates/contact';
import Home from '../templates/home';
import Login from '../templates/login';
import Sign from '../templates/signup';
import User from '../user-dashboard/user-dashboard';
import Place_order from '../user-dashboard/my-order';
import Bulk_order from '../user-dashboard/bluk-order';
import Update from '../user-dashboard/update';
import Admin from '../admin-dashboard/admin';
import Admin_dashboard from '../admin-dashboard/dashboard';
import New_Order from '../admin-dashboard/neworder';
import Pending_order from '../admin-dashboard/pendingorder';
import Completed_order from '../admin-dashboard/completedorder';
import Today_order from '../admin-dashboard/todayorder';
import Rider_information from '../admin-dashboard/riderinformation';
import Rider_update from '../admin-dashboard/riderupdate';
import Path_update from '../admin-dashboard/pathupdate';
import User_information from '../admin-dashboard/userinformation';
import Rider_dashboard from '../rider-dashboard/dashboard';
import Rider_path from '../admin-dashboard/riderpath';
import All_order from '../rider-dashboard/allorder';
import Rider_route from '../rider-dashboard/riderroute';
import Order_update from '../admin-dashboard/orderupdate';
import Error_page from '../templates/components/error';
import User_profile from '../user-dashboard/user_profile';
import Password from '../templates/password';
import View from '../user-dashboard/view';
import Cookies from 'js-cookie';
import View_admin from '../admin-dashboard/viewadmin';
import My_tickets from '../user-dashboard/myticket';
import Payment_pages from '../user-dashboard/paymentreq';
import User_main from '../user-dashboard/usermain';
import Admin_tickets from '../admin-dashboard/admintickets';

import DashboardLocations from '../admin-dashboard/pages/Location/locationDashboard';
import LocationPricePage from '../admin-dashboard/pages/Location/LocationNewPage';
import LocationEditPage from '../admin-dashboard/pages/Location/locationEditPage';

import DashboardProducts from '../admin-dashboard/pages/Products/productDashboard';
import ProductAdd from '../admin-dashboard/pages/Products/ProductAddPage';
import ProductEdit from '../admin-dashboard/pages/Products/ProductEditPage';

import DashboardCategories from '../admin-dashboard/pages/Categories/categoriesDashboard';
import CategoriesAdd from '../admin-dashboard/pages/Categories/categoriesNewPage';
import CategoriesEdit from '../admin-dashboard/pages/Categories/categoriesEditPage';

import DashboardPricingCriteria from '../admin-dashboard/pages/PricingCriterias/pricingCriteriaDashboard';
import PricingCriteriaAdd from '../admin-dashboard/pages/PricingCriterias/pricingCriteriaNewPage';
import PricingCriteriaEdit from '../admin-dashboard/pages/PricingCriterias/pricingCriteriaEditPage';
import Authentication from './authentication';


const Router = () => {
    const history = useHistory();
    const [isAuth, setIsAuth] = useState(false);

    const Access_token = Cookies.get('access_token');
    const Refresh_token = Cookies.get('refresh_token');
    const ID = Cookies.get('id');
    const TOKEN_KEY = { Access_token, Refresh_token, ID };

    useEffect(() => {
        if (TOKEN_KEY['Access_token'] && TOKEN_KEY['Refresh_token'] && TOKEN_KEY['id']) {
            setIsAuth(true);
        }
        else {
            setIsAuth(false);
        }
    }, [TOKEN_KEY])

    return (
        <BrowserRouter>
            {/* <HashRouter history={history}> */}
            <Switch>
                <Route path='/home' exact component={Home}></Route>
                <Route path='/contact' exact component={Contact}></Route>
                <Route path='/forgot-password/reset-password/' component={Password}></Route>
                {/* user dashboard */}
                <Authentication path="/user/dashboard" component={User} allowedRoles={['user']} />
                {/* <Route path="/user/dashboard" component={Authentication(User, ['user'])} /> */}
                <Authentication path='/my/order' exact component={Place_order} allowedRoles={['user']}></Authentication>
                <Authentication path='/bulk/order' component={Bulk_order} allowedRoles={['user']} ></Authentication>
                <Authentication path='/my/order/update/:OrderNumber' component={Update} allowedRoles={['user']}></Authentication>
                <Route path="/view/my/data/:OrderNumber" component={View} allowedRoles={['user']}></Route>
                <Authentication path='/my/tickets' component={My_tickets} allowedRoles={['user']}></Authentication>
                <Authentication path='/my/profile' exact component={User_main} allowedRoles={['user']}></Authentication>
                <Authentication path='/my/profile/update' exact component={User_profile} allowedRoles={['user']}></Authentication>
                <Authentication path='/admin/dashboard' component={Admin_dashboard} allowedRoles={['admin']}></Authentication>
                <Authentication path="/new/order" component={New_Order} allowedRoles={['admin']} />
                <Authentication path="/order/update/:OrderNumber" component={Order_update} allowedRoles={['admin']} ></Authentication>
                <Authentication path="/admin/view/my/data/:OrderNumber" component={View_admin} allowedRoles={['admin']}></Authentication>
                <Authentication path='/rider/update/:id' exact component={Rider_update} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/all/tickets" component={Admin_tickets} allowedRoles={['admin']}></Authentication>
                <Authentication path="/rider/information" component={Rider_information} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/rider/path" component={Rider_path}  allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/location-price" component={DashboardLocations} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/new/location-price" component={LocationPricePage} allowedRoles={['admin']}></Authentication>
                <Authentication path="/dashboard/location-price/edit/:id" component={LocationEditPage} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/categories" component={DashboardCategories} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/new/categories" component={CategoriesAdd} allowedRoles={['admin']}></Authentication>
                <Authentication path="/dashboard/categories/edit/:id" component={CategoriesEdit} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/pricing-criterias" component={DashboardPricingCriteria} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/products" component={DashboardProducts} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/new/products" component={ProductAdd} allowedRoles={['admin']}></Authentication>
                <Authentication path="/admin/new/pricing-criterias" component={PricingCriteriaAdd} allowedRoles={['admin']}></Authentication>
                <Authentication path="/dashboard/pricing-criterias/edit/:id" component={PricingCriteriaEdit} allowedRoles={['admin']}></Authentication>
                <Route path='/admin/login' component={Admin} ></Route>
                {/* <Route path="/pending/order" component={Pending_order}></Route> */}
                {/* <Route path="/completed/order" component={Completed_order}></Route> */}
                {/* <Route path="/today/order" component={Today_order}></Route> */}
                <Authentication path="/user/information" component={User_information} allowedRoles={['admin']}></Authentication>
                <Route path="/rider/dashboard" component={Rider_dashboard}></Route>
                <Route path="/rider/all/order" component={All_order}></Route>
                <Route path="/rider/route" component={Rider_route}></Route>
                <Route path='/my/path/update/:route_code' exact component={Path_update}></Route>
                <Authentication path="/payment/request" component={Payment_pages} allowedRoles={['user']}></Authentication>
                <Route path="/dashboard/products/edit/:id" component={ProductEdit}></Route>
                {isAuth !== true ?
                    <>
                        <Route path='/' exact component={Login}></Route>
                        <Route path='/sign-up' exact component={Sign}></Route>
                    </> : null
                }
                <Route path="*" component={Error_page}></Route>
            </Switch>
            {/* </HashRouter> */}
        </BrowserRouter>
    )
}
export default Router;