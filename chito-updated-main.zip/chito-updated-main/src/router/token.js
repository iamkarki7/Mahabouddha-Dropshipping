import Cookies from 'js-cookie';
const Access_token = Cookies.get('access_token');
const Refresh_token = Cookies.get('refresh_token');
const TOKEN_KEY = {Access_token,Refresh_token};



const isLogin = () => {
    if (TOKEN_KEY) {
        return true;
    }else{
        TOKEN_KEY = false;
    }

    return false;
}
export default isLogin;