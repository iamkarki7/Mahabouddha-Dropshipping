import React from "react";
import Cookies from 'js-cookie';
import { Route, Redirect } from 'react-router-dom';

const Authentication = ({ path, component: Component, allowedRoles, ...rest }) => {
    const userRole = Cookies.get('user_role');

    // Check if the user has the required role
    if (!allowedRoles.includes(userRole)) {
      return <Redirect to='/' />;
    }

    // Render the component if the user has the required role
    return <Route path={path} render={props => <Component {...props} {...rest} />} />;
};

export default Authentication;