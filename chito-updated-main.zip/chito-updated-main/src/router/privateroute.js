import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import isLogin from './token';
import Cookies from 'js-cookie';


const PrivateRoute = ({component: Component, ...rest}) => {
    const Access_token = Cookies.get('access_token');
const Refresh_token = Cookies.get('refresh_token');
const TOKEN_KEY = {Access_token,Refresh_token};
    return (

        // Show the component only when the user is logged in
        // Otherwise, redirect the user to /signin page
        <Route {...rest} render={props => (
             isLogin(TOKEN_KEY) ?
                <Component {...props} />
            : <Redirect to="/login" />
        )} />
    );
};

export default PrivateRoute;